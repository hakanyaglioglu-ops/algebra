# ALGEBRA — Android

Telefonda çalışan sesli/yazılı asistan: uygulama açar, sesi/feneri kontrol eder, sayaç ve alarm kurar,
hava durumu söyler, basit şekillerden **3D model** tasarlar ve **holografik görüntüleyicide** dokunarak
döndürmenizi, taşımanızı, büyütüp küçültmenizi sağlar. Modeli 3D yazıcı için STL olarak kaydeder.

## APK nasıl alınır?

### Yol 1 — GitHub ile (bilgisayara bir şey kurmadan)
1. github.com'da ücretsiz hesapla yeni bir depo (repository) açın.
2. "uploading an existing file" bağlantısına tıklayın ve **bu klasörün İÇİNDEKİ her şeyi** sürükleyin
   (gizli `.github` klasörü dahil). `.github` yüklenmezse: "Add file > Create new file", ad olarak
   `.github/workflows/build-apk.yml` yazıp bu projedeki aynı adlı dosyanın içeriğini yapıştırın.
3. "Commit changes" deyin. Üstteki **Actions** sekmesinde "APK derle" çalışır (birkaç dakika).
4. Bitince çalışmanın sayfasında alttaki **Artifacts > algebra-apk** dosyasını indirin, zip'ten `app-debug.apk` çıkar.
5. APK'yı telefona aktarıp açın; "bilinmeyen kaynaklardan yükleme" iznini verin.

### Yol 2 — Android Studio
Klasörü Android Studio ile açın (Gradle eşitlenmesini bekleyin), telefonu USB hata ayıklamayla bağlayıp ▶ Run
deyin ya da Build > Build APK(s).

## Yapay zeka ayarı
Sağ üstteki **⚙ Ayarlar** bölümünden seçin; her seçenek için anahtar, model ve adres ayrı saklanır:

| Seçenek | Anahtar | Not |
|---|---|---|
| Pollinations | gerekmez | Varsayılan. Ücretsiz ama kararsız olabilir, gizli bilgi yazmayın. |
| Claude | gerekir (console.anthropic.com) | En güvenilir araç kullanımı. Kullandıkça ücretlenir. |
| OpenAI uyumlu | gerekir | Varsayılan Google Gemini (aistudio.google.com'dan ücretsiz anahtar). Groq, OpenRouter, Ollama için adres ve model yazın. |
| Yapay zekasız | gerekmez | Sadece kalıp komutlar: "Chrome'u aç", "sesi kıs", "10 dakika sonra hatırlat", "40 küp yap"... |

Anahtarlar yalnızca telefonda, uygulamanın özel alanında tutulur.

## Kullanım örnekleri
- "YouTube'u aç", "sesi artır", "feneri aç", "yarım saat sonra su içmeyi hatırlat", "yarın 07:30'a alarm kur"
- "İstanbul'da hava nasıl?"
- "60 mm uzunluğunda basit bir robot kol tasarla" → model açılır; 1 parmakla döndürün, 2 parmakla taşıyıp çimdikleyin.
- "Modeli kaydet" veya görüntüleyicideki **STL kaydet** → İndirilenler/ALGEBRA klasörü → Cura/PrusaSlicer.

## Sınırlar
- Mikrofon düğmesine basarak konuşursunuz; "Hey Algebra" ile sürekli dinleme yok (pil ve izin kısıtları).
- Hologram, kamera ve el takibi olmadan, dokunmatik ekranla çalışır.
- Modeller basit şekillerden kurulur ve birleştirilmez; baskıdan önce dilimleyicide kontrol edin.
- Uygulama açma yalnızca yüklü uygulamaları ada göre bulur; aramayı telefon sizin onayınızla yapar.
- Kod bu ortamda derlenemedi; ilk derlemede küçük hata çıkarsa hata metnini iletin.
