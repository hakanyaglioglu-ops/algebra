# A1 — Android

Telefonda çalışan sesli/yazılı asistan: uygulama açar, sesi/feneri kontrol eder, sayaç ve alarm kurar,
hava durumu söyler, basit şekillerden **3D model** tasarlar ve **holografik görüntüleyicide** dokunarak
döndürmenizi, taşımanızı, büyütüp küçültmenizi sağlar. Modeli 3D yazıcı için STL olarak kaydeder.

## APK nasıl alınır?

### Yol 1 — GitHub ile (bilgisayara bir şey kurmadan)
1. github.com'da ücretsiz hesapla yeni bir depo (repository) açın.
2. "uploading an existing file" bağlantısına tıklayın ve **bu klasörün İÇİNDEKİ her şeyi** sürükleyin
   (gizli `.github` klasörü dahil). `.github` yüklenmezse: "Add file > Create new file", ad olarak
   `.github/workflows/build-apk.yml` yazıp bu projedeki aynı adlı dosyanın içeriğini yapıştırın.
3. "Commit changes" deyin. Üstteki **Actions** sekmesinde "APK derle" çalışır (birkaç dakika).
4. Bitince çalışmanın sayfasında alttaki **Artifacts > algebra-apk** dosyasını indirin, zip'ten `app-debug.apk` çıkar.
5. APK'yı telefona aktarıp açın; "bilinmeyen kaynaklardan yükleme" iznini verin.

### Yol 2 — Android Studio
Klasörü Android Studio ile açın (Gradle eşitlenmesini bekleyin), telefonu USB hata ayıklamayla bağlayıp ▶ Run
deyin ya da Build > Build APK(s).

## Yapay zeka ayarı
Sağ üstteki **⚙ Ayarlar** bölümünden seçin; her seçenek için anahtar, model ve adres ayrı saklanır:

| Seçenek | Anahtar | Not |
|---|---|---|
| Pollinations | gerekmez | Varsayılan. Ücretsiz ama kararsız olabilir, gizli bilgi yazmayın. |
| Claude | gerekir (console.anthropic.com) | En güvenilir araç kullanımı. Kullandıkça ücretlenir. |
| OpenAI uyumlu | gerekir | Varsayılan Google Gemini (aistudio.google.com'dan ücretsiz anahtar). Groq, OpenRouter, Ollama için adres ve model yazın. |
| Yapay zekasız | gerekmez | Sadece kalıp komutlar: "Chrome'u aç", "sesi kıs", "10 dakika sonra hatırlat", "40 küp yap"... |

Anahtarlar yalnızca telefonda, uygulamanın özel alanında tutulur.

## Kullanım örnekleri
- "YouTube'u aç", "sesi artır", "feneri aç", "yarım saat sonra su içmeyi hatırlat", "yarın 07:30'a alarm kur"
- "İstanbul'da hava nasıl?"
- "60 mm uzunluğunda basit bir robot kol tasarla" → model açılır; 1 parmakla döndürün, 2 parmakla taşıyıp çimdikleyin.
- "Modeli kaydet" veya görüntüleyicideki **STL kaydet** → İndirilenler/A1 klasörü → Cura/PrusaSlicer.

## Sınırlar
- Mikrofon düğmesine basarak konuşursunuz; "Hey A1" ile sürekli dinleme yok (pil ve izin kısıtları).
- Hologram, kamera ve el takibi olmadan, dokunmatik ekranla çalışır.
- Modeller basit şekillerden kurulur ve birleştirilmez; baskıdan önce dilimleyicide kontrol edin.
- Uygulama açma yalnızca yüklü uygulamaları ada göre bulur; aramayı telefon sizin onayınızla yapar.
- Kod bu ortamda derlenemedi; ilk derlemede küçük hata çıkarsa hata metnini iletin.

## Samsung Galaxy A32 notları
- **Android sürümü:** Ayarlar > Telefon hakkında > Yazılım bilgileri. Uygulama Android 10 ve üstünde çalışır (A32 buna uygundur).
- **Geliştirici modu (USB ile kurulum için):** Yazılım bilgileri > **Derleme numarası**na 7 kez dokunun, ardından Ayarlar > Geliştirici seçenekleri > **USB hata ayıklama** açın. Telefonu USB ile bağlayınca çıkan "Bu bilgisayara güven" uyarısını onaylayın.
- **APK dosyasıyla kurulum:** Dosyayı açarken Samsung "bilinmeyen uygulama" izni ister; açılan ekrandan o uygulamaya (Dosyalarım/Chrome) izin verin. Google Play Protect uyarısı çıkarsa "Yine de yükle" deyin (kendi derlediğiniz bir uygulamadır).
- **Ses:** Konuşma tanıma için telefonda Google uygulaması ve internet gerekir. Mikrofon düğmesi çalışmazsa düğmeye **uzun basın**, Google'ın hazır konuşma penceresi açılır.
- **Türkçe sesli yanıt:** Duyulmuyorsa Ayarlar > Genel yönetim > Dil > Metinden sese bölümünden Türkçe sesi indirin.
- **Pil:** Uygulama arka planda dinlemez; ileride "A1" ile uyandırma eklenirse Ayarlar > Pil > Arka plan kullanım sınırları'ndan uygulamayı kısıtlamanın dışında tutmanız gerekir.

## Telefonda çalışan yapay zeka (internetsiz)
Ayarlar'da **"Telefonda (çevrimdışı, kendi kendine çalışır)"** seçeneği, telefonun işlemcisi ve belleğiyle çalışır
(Google LiteRT-LM). Hesap, anahtar ve sınır yoktur; yalnızca bir kez model dosyası gerekir.

1. Telefonun tarayıcısında **huggingface.co/litert-community** sayfasına girin; Gemma 3 1B (IT) gibi küçük bir
   modelin **.litertlm** dosyasını indirin (yaklaşık 0,5-1 GB; boyutu sayfada yazar). Gemma için ücretsiz
   Hugging Face hesabı açıp lisansı kabul etmeniz gerekebilir.
2. A1'de **⚙ Ayarlar > Telefonda (çevrimdışı...)** seçin, **Model dosyası seç**e dokunup indirdiğiniz dosyayı seçin.
   Dosya uygulamaya kopyalanır (birkaç dakika sürebilir; telefonda dosya boyutunun iki katı boş yer olsun).
3. **Kaydet**'e basın. İlk cevap model yüklenirken yavaş gelir.

Dürüst notlar: küçük modeller yavaş ve basittir (A32'de saniyede birkaç kelime, A56'da daha rahat), Türkçeleri sınırlıdır
ve robot/3D tasarımı gibi karmaşık işleri Claude gibi başaramaz. Uygulama açma, sesi kısma, sayaç, "40 küp yap" gibi
komutlar model beklemeden anında çalışır. Konuşma tanıma ise Google'ın servisini kullanır; internetsiz için Google
uygulamasından Türkçe çevrimdışı dil paketini indirmeniz gerekir.

## Tasarım şablonları ve hafıza ("öğrenme")
Telefonda yapay zeka gerçekten eğitilemez; bunun yerine A1 şunları yapar:
- **Hazır şablonlar** (doğru oranlı, anında): robot, robot kol, tekerlekli robot (rover), tutucu (gripper), drone, dişli.
  Örnek: "20 cm robot yap", "robot kol tasarla", "12 dişli dişli yap", "tekerlekli robot yap".
  Küçük çevrimdışı model bile bunları hatasız üretir, çünkü şablonlar kodun içindedir.
- **Düzenleme:** "iki kat büyüt", "yarıya küçült", "1,5 kat büyüt".
- **Hafıza:** Beğendiğiniz tasarımı **"tasarımı kaydet robotum"** diye kaydedin, sonra **"robotum tasarımını aç"** deyin.
  Claude/Gemini gibi bulut yapay zekalar kayıtlı tasarımları benzer isteklerde örnek olarak kullanır (az örnekle öğrenme).
  **"tasarımlarım"** deyince listeyi söyler.
- Özel nesneler (şablonda olmayanlar) için bulut yapay zeka (Claude, Gemini) şekilleri kendisi birleştirir; küçük çevrimdışı model bunu güvenilir yapamaz.
- Modelleri **"modeli kaydet"** ile STL olarak İndirilenler/A1'e kaydedip Cura/PrusaSlicer'da dilimleyebilirsiniz.

## Tasarımları öğrenme (robot, 3D)
Telefondaki küçük modelin kendisi eğitilemez; A1 şu şekilde "öğrenir":
- **Hazır şablonlar:** "robot yap", "robot kol yap 15 cm", "tekerlekli robot yap", "drone yap", "tutucu yap", "12 dişli yap".
- **Kaydetme:** Bir tasarımı beğenirseniz "bunu dev robot olarak kaydet" deyin. Telefonda saklanır.
- **Geri çağırma:** Sonra "dev robot yap" demeniz yeterli. Kayıtlı tasarımlar şablonlardan önce gelir.
- **Değiştirme:** "iki kat büyüt", "yarı yarıya küçült", "1,5 kat büyüt".
- **Akıllı yapay zekalarda (Claude, Gemini...):** Kayıtlı tasarımlarınız benzer isteklerde örnek olarak verilir; böylece zamanla sizin tarzınıza yaklaşır.
- Listeyi görmek için: "tasarımlarım neler".

## Kütüphane: A1'in öğrendikleri (taşınabilir)
A1 öğrendiklerini telefonda tek bir küçük dosyada (JSON) saklar; model küçük kalır, bilgi kütüphanede büyür.
- **Ne kaydedilir:** `bilgi` (siz öğretirsiniz), `çıkarım` ve `yorum` (A1'in konuşmalardan çıkardıkları), tasarımlarınız.
- **Öğretme:** "öğren: balkon ışığı akşam 7'de yanar", "unutma ...", "hatırla ...".
- **Çıkarım:** "çıkarım yap" derseniz son konuşmadan kalıcı bir çıkarım ve yorum yazar. Claude/Gemini seçiliyken
  her 5 konuşmada bir otomatik de yapılır (Ayarlar'da kapatılabilir). Pollinations'ta (ücretsiz sınır) ve
  telefonda çalışan modelde (işlemci yükü) otomatik yapılmaz, sadece "çıkarım yap" ile.
- **Kullanım:** Sorunuza benzeyen en fazla 3 not, modele otomatik eklenir (anahtar kelime araması; ağır bir veritabanı yok).
- **Durum:** "neler öğrendin" veya "kütüphane".
- **Dışa aktarma:** Ayarlar > **Kütüphaneyi dışa aktar** ya da "kütüphaneyi dışa aktar" → `İndirilenler/A1/a1_kutuphane_TARİH.json`.
  Telefonu USB ile bağlayıp veya Samsung "Dosyalarım > Paylaş" ile bu dosyayı alabilirsiniz.
- **Başka Android cihaza taşıma:** O cihaza aynı APK'yı kurun, dosyayı cihaza kopyalayın, Ayarlar >
  **Kütüphaneyi içe aktar** ile seçin. Notlar ve tasarımlar birleştirilir, aynı not iki kez eklenmez.
- **Gizlilik:** Dosya konuşmalarınızdan çıkan notlar içerir ve İndirilenler klasöründe diğer uygulamalara açıktır.
  Taşıdıktan sonra silin.

## A32'de hafif çalışma
- Model dosyasını en küçük seçin (0,5-1 GB sınıfı, int4). Daha büyük model A32'nin 4 GB belleğinde zorlanır.
- Yerel model ilk soruda yüklenir; telefonun belleği azalırsa uygulama modeli kendiliğinden kapatır, sonraki soruda yeniden yükler.
- APK yalnızca 64-bit ARM (arm64-v8a) içindir. Taşıyacağınız "Android bilgisayar" x86 işlemcili ise (ör. Android-x86/BlissOS) söyleyin, x86_64 desteği ekleriz.

## Ana ekran: ilişki haritası
Ana ekran metin yerine siyah fon üzerinde yeşil bir **atom çekirdeği** ve etrafında dönen **bağlantı haritasıdır**:
- Her düğüm kütüphanedeki bir not (bilgi / çıkarım / yorum) veya kayıtlı bir tasarımdır. Ortak kelime ya da etiket
  paylaşan notlar birbirine çizgiyle bağlanır, çizgiler üzerinde yeşil darbeler akar.
- A1 düşünürken ağ parlar ve darbeler hızlanır; cevap gelince çekirdekten bir dalga yayılır. Öğrendikçe ağ büyür.
- Bir düğüme dokunursanız notun metni altta görünür. Ekrana boş yere dokunmak dalga başlatır.
- Cevaplar altta kısa bir yazı olarak görünür; tüm sohbet geçmişi için üstteki **☰ Metin** düğmesine basın.
- Bu ekran sürekli animasyon çizer; pil harcar. Uygulama arka plana geçince durur.

## İnsan gibi öğrenme (temel kanunlar)
A1 kütüphaneyi bilgi çöplüğüne çevirmez; yalnızca **temel kanun/ilke/denklemleri** (matematik, fizik, kimya, biyoloji, tıp) tutar.
Komutlar (çalışması için Ayarlar'dan bir yapay zeka seçili ve internet açık olmalı):
- `çalış Newton'un hareket yasaları` : bir konuyu kaynaktan (Vikipedi) okuyup özünü çıkarır.
- `kendi kendine çalış` (veya `kendi kendine çalış 5`) : müfredattan, en az dolu alandan başlayarak sırayla çalışır; her konuda haber verir.
- `çalışmayı bırak` : turu durdurur.
- `kanunlarım` : alan alan kaç kanun bildiğini söyler.
- `kanunlardan çıkarım türet` : kanunları birleştirip yeni, zorunlu bir sonuç arar.

Nasıl öğrenir: 1) önce bildiklerini hatırlar, 2) kaynağı okur, 3) metni kopyalamadan tek cümlelik kanunu çıkarır,
4) kanunun kaynaktan **aynen kanıt alıntısı** olmalıdır, yoksa uydurma sayılıp atılır, 5) tarih/isim/anekdot içeren veya çok kısa
maddeler elenir, 6) aynı kanun tekrar görülürse kopya eklenmez, güveni artar, 7) yeni kanun eskilerle birleştirilip çıkarım yazılır.
Haritada kanunlar büyük beyaz düğümlerdir. Çıkarımlar, dayandığı kanunların etiketleriyle onlara bağlanır.

## Yatay ekran: ağ solda, paneller sağda
Telefonu yan çevirince sol tarafta hareketli bağlantı ağı (süzülen noktalar, yakın olanlar ince çizgiyle bağlı; parlak etiketli noktalar
kütüphane notları/kanunları), sağ tarafta bilgi panelleri görünür: A1 çekirdek, kütüphane, ses ve yetenek kutuları; Bağlantılar,
Yetenekler, Program (canlı saat ve "N dk sonra" durumu) ve "A1 ile konuş" (dinlerken çubuklar hareket eder).
Dikey ekranda yalnızca ağ görünür. Renk için 🎨 düğmesi.

Panel içeriğini siz belirlersiniz:
- Sesli/yazılı: `bağlantılara Gmail ekle`, `yeteneklerden sayaç çıkar`, `programa 18:00 gün sonu özeti ekle`,
  `bağlantılarda Gmail yerine Drive`, `Gmail kapalı` / `Gmail bağlı`, `yeni panel Notlar`, `notlar paneli sil`.
- Ayarlar > **Panelleri düzenle**: panel seç, satır ekle/düzenle/sil.
(Program paneli bir not defteridir; saatlerde otomatik iş çalıştırmaz.)

## Ses Türkçe değilse
Uygulama Türkçe ses bulamazsa diğer kurulu ses motorlarını (Samsung/Google) dener. Hiçbirinde yoksa İngilizce okumasın diye susar
ve sağdaki SES kutusunda "Türkçe yok ✗" yazar. Ayarlar > **Türkçe ses ayarını aç** ile telefonun Metinden sese ekranına gidip
Türkçe ses verisini indirin, uygulamayı kapatıp açın.

## Araştırma
`araştır <konu>` veya `çalış <konu>`: Vikipedi'yi okur, kısa özet verir, temel kanun varsa kütüphaneye ekler. Eklemezse nedenini söyler
(kaynak yok / model biçimi bozdu / kanıt bulunamadı). Küçük cihaz içi modeller bu işte zayıf kalabilir; Claude veya Gemini seçin.
