plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // A32 ve A56 64-bit ARM; APK küçük kalsın
        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // Kütüphane daha yeni Kotlin ile derlenmiş olabilir
        freeCompilerArgs += "-Xskip-metadata-version-check"
    }
}

dependencies {
    // Telefonda çalışan yerel yapay zeka (Google LiteRT-LM)
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
}
