package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject

/** Bir eksenin (aktüatörün) hesaplanan statik tork ihtiyacı. qty: kaç adet (sol+sağ = 2). */
class Joint(val name: String, val group: String, val qty: Int, val torqueNm: Double)

/** Katalogdaki aktüatör. rated: sürekli, peak: tepe tork (N·m). Değerler yaklaşıktır; satın almadan önce doğrulayın. */
class Actuator(val name: String, val ratedNm: Double, val peakNm: Double, val massKg: Double, val priceUsd: Double, val busV: Int)

/**
 * Parametrik insansı robot: boy (mm), hedef kütle (kg) ve taşıma yükünden (kg) oranlı bir iskelet,
 * statik tork hesabı ve Cad'in anladığı parça listesi üretir.
 * Oranlar yaklaşık antropometrik değerlerdir (Drillis-Contini uzunluk, Winter kütle oranları).
 * Bu bir ön tasarımdır: dinamik benzetim, sonlu elemanlar ve gerçek doğrulama yerine geçmez.
 */
class Humanoid(val heightMm: Double, val massKg: Double, val payloadKg: Double) {
    private val g = 9.81
    private val hm = heightMm / 1000.0

    // uzuv uzunlukları (m)
    val lThigh = 0.245 * hm
    val lShank = 0.246 * hm
    val lFoot = 0.152 * hm
    val lUpperArm = 0.186 * hm
    val lForearm = 0.146 * hm
    val lHand = 0.108 * hm
    val lTorso = 0.288 * hm
    val lHead = 0.130 * hm

    // uzuv kütleleri (kg), tek taraf
    val mThigh = 0.100 * massKg
    val mShank = 0.0465 * massKg
    val mFoot = 0.0145 * massKg
    val mUpperArm = 0.028 * massKg
    val mForearm = 0.016 * massKg
    val mHand = 0.006 * massKg
    val mTrunk = 0.497 * massKg
    val mHead = 0.081 * massKg

    val dof = 30

    companion object {
        /** Fiyata göre artan sıralı katalog (yaklaşık, ~2024-25 liste değerleri). */
        val catalog = listOf(
            Actuator("Hobi servo MG996R sınıfı", 0.5, 1.08, 0.055, 6.0, 6),
            Actuator("Dijital servo 35 kg·cm sınıfı", 1.7, 3.4, 0.068, 30.0, 8),
            Actuator("Dynamixel XL430-W250", 0.75, 1.5, 0.057, 50.0, 12),
            Actuator("Dynamixel XM430-W350", 2.0, 4.1, 0.082, 270.0, 12),
            Actuator("CubeMars AK70-10 (BLDC+redüktör)", 8.3, 24.8, 0.521, 430.0, 24),
            Actuator("Dynamixel XH540-W270", 5.3, 10.6, 0.165, 450.0, 24),
            Actuator("CubeMars AK80-9 (BLDC+redüktör)", 9.0, 18.0, 0.485, 540.0, 24),
            Actuator("CubeMars AK10-9 (BLDC+redüktör)", 18.0, 53.0, 0.960, 720.0, 24),
            Actuator("Özel BLDC + harmonik sürücü (~60 N·m sınıfı)", 60.0, 150.0, 1.800, 1400.0, 48)
        )

        /** Gereken statik torka dinamik emniyet katsayısıyla uygun en ucuz aktüatör (yoksa en güçlüsü). */
        fun pick(requiredNm: Double): Actuator =
            catalog.firstOrNull { it.peakNm >= requiredNm && it.ratedNm >= requiredNm * 0.5 } ?: catalog.last()
    }

    /** Statik en kötü durum torkları. Dinamik yük için raporda ayrıca emniyet katsayısı uygulanır. */
    fun joints(): List<Joint> {
        val payArm = payloadKg / 2.0   // iki elle taşıma: kol başına yarısı
        val shoulder = g * (
            mUpperArm * lUpperArm / 2 + mForearm * (lUpperArm + lForearm / 2) +
                mHand * (lUpperArm + lForearm + lHand / 2) + payArm * (lUpperArm + lForearm + lHand)
            )
        val elbow = g * (mForearm * lForearm / 2 + mHand * (lForearm + lHand / 2) + payArm * (lForearm + lHand))
        val wrist = g * (mHand * lHand / 2 + payArm * lHand)

        val legMass = mThigh + mShank + mFoot
        val wSupport = (massKg + payloadKg - legMass) * g                 // tek ayak üstünde taşınan ağırlık
        val wUpper = (massKg + payloadKg - 2 * legMass) * g               // kalçanın üstündeki ağırlık
        // 60° diz bükümünde, ağırlık çizgisi ayak bileğinden geçer: yatay kol ≈ uzuv boyu × sin(30°)
        val knee = wSupport * lShank * 0.5
        val hipPitch = wUpper * lThigh * 0.5
        val anklePitch = wSupport * 0.25 * lFoot
        val hipRoll = wSupport * 0.05 * hm
        val ankleRoll = wSupport * 0.03 * hm
        val waistPitch = g * ((mTrunk * 0.5 + mHead + 2 * (mUpperArm + mForearm + mHand) + payloadKg) * 0.5 * lTorso * 0.35)
        val neckPitch = g * mHead * 0.5 * lHead * 0.6

        fun j(n: String, grp: String, q: Int, t: Double) = Joint(n, grp, q, maxOf(t, 0.05))
        return listOf(
            j("Omuz pitch", "Kol", 2, shoulder),
            j("Omuz roll", "Kol", 2, shoulder),
            j("Omuz yaw", "Kol", 2, shoulder * 0.3),
            j("Dirsek", "Kol", 2, elbow),
            j("Bilek pitch", "Kol", 2, wrist),
            j("Bilek roll", "Kol", 2, wrist * 0.5),
            j("El kavrama", "Kol", 2, 0.3 + payArm * g * 0.02),
            j("Kalça yaw", "Bacak", 2, hipPitch * 0.2),
            j("Kalça roll", "Bacak", 2, hipRoll),
            j("Kalça pitch", "Bacak", 2, hipPitch),
            j("Diz", "Bacak", 2, knee),
            j("Ayak bileği pitch", "Bacak", 2, anklePitch),
            j("Ayak bileği roll", "Bacak", 2, ankleRoll),
            j("Bel yaw", "Gövde", 1, waistPitch * 0.4),
            j("Bel pitch", "Gövde", 1, waistPitch),
            j("Boyun yaw", "Baş", 1, neckPitch * 0.4),
            j("Boyun pitch", "Baş", 1, neckPitch)
        )
    }

    // ---------------- geometri (mm, Z yukarı, robot -Y yönüne bakar) ----------------

    private fun p(name: String, label: String, shape: String, size: JSONObject, x: Double, y: Double, z: Double) =
        JSONObject().put("name", name).put("label", label).put("shape", shape).put("size", size)
            .put("position", JSONArray(listOf(x, y, z))).put("rotation_deg", JSONArray(listOf(0.0, 0.0, 0.0)))

    private fun bx(n: String, l: String, w: Double, d: Double, h: Double, x: Double, y: Double, z: Double) =
        p(n, l, "box", JSONObject().put("x", w).put("y", d).put("z", h), x, y, z)

    private fun cy(n: String, l: String, r: Double, h: Double, x: Double, y: Double, z: Double) =
        p(n, l, "cylinder", JSONObject().put("radius", r).put("height", h), x, y, z)

    private fun sp(n: String, l: String, r: Double, x: Double, y: Double, z: Double) =
        p(n, l, "sphere", JSONObject().put("radius", r), x, y, z)

    /** Cad.build'in anladığı, adlandırılmış parça listesi (29 parça). */
    fun parts(): JSONArray {
        val h = heightMm
        val ankleZ = 0.039 * h
        val kneeZ = ankleZ + 0.246 * h
        val hipZ = kneeZ + 0.245 * h
        val shZ = 0.818 * h
        val l = ArrayList<JSONObject>()

        for ((s, side) in listOf(-1.0 to "sol", 1.0 to "sag")) {
            val sd = if (s < 0) "sol" else "sağ"
            val hx = s * 0.057 * h
            l += bx("ayak_$side", "Ayak $sd", 0.06 * h, 0.152 * h, 0.03 * h, hx, -0.03 * h, 0.015 * h)
            l += sp("bilek_$side", "Ayak bileği $sd", 0.022 * h, hx, 0.0, ankleZ)
            l += cy("incik_$side", "İncik $sd", 0.022 * h, 0.246 * h * 0.9, hx, 0.0, (ankleZ + kneeZ) / 2)
            l += sp("diz_$side", "Diz $sd", 0.027 * h, hx, 0.0, kneeZ)
            l += cy("uyluk_$side", "Uyluk $sd", 0.027 * h, 0.245 * h * 0.9, hx, 0.0, (kneeZ + hipZ) / 2)
            l += sp("kalca_$side", "Kalça eklemi $sd", 0.03 * h, hx, 0.0, hipZ)
        }
        l += bx("legen", "Leğen", 0.20 * h, 0.09 * h, 0.05 * h, 0.0, 0.0, hipZ + 0.01 * h)
        l += bx("govde", "Gövde", 0.24 * h, 0.12 * h, 0.27 * h, 0.0, 0.0, hipZ + 0.17 * h)
        l += bx("pil_kutusu", "Pil ve denetleyici kutusu", 0.14 * h, 0.045 * h, 0.15 * h, 0.0, 0.0825 * h, hipZ + 0.17 * h)
        for ((s, side) in listOf(-1.0 to "sol", 1.0 to "sag")) {
            val sd = if (s < 0) "sol" else "sağ"
            val ax = s * 0.15 * h
            l += sp("omuz_$side", "Omuz $sd", 0.03 * h, ax, 0.0, shZ - 0.01 * h)
            l += cy("ust_kol_$side", "Üst kol $sd", 0.02 * h, 0.186 * h * 0.9, ax, 0.0, shZ - 0.186 * h / 2)
            l += sp("dirsek_$side", "Dirsek $sd", 0.022 * h, ax, 0.0, shZ - 0.186 * h)
            l += cy("on_kol_$side", "Ön kol $sd", 0.018 * h, 0.146 * h * 0.9, ax, 0.0, shZ - 0.186 * h - 0.146 * h / 2)
            l += bx("el_$side", "El $sd", 0.035 * h, 0.05 * h, 0.108 * h, ax, 0.0, shZ - 0.186 * h - 0.146 * h - 0.108 * h / 2)
        }
        l += cy("boyun", "Boyun", 0.02 * h, 0.05 * h, 0.0, 0.0, 0.85 * h)
        l += bx("kafa", "Kafa", 0.10 * h, 0.10 * h, 0.125 * h, 0.0, 0.0, 0.9375 * h)
        l += sp("kamera_sol", "Kamera sol", 0.012 * h, -0.025 * h, -0.052 * h, 0.945 * h)
        l += sp("kamera_sag", "Kamera sağ", 0.012 * h, 0.025 * h, -0.052 * h, 0.945 * h)
        return JSONArray(l)
    }
}
