package com.jarvis.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A1'in kalıcı kütüphanesi: öğretilen bilgiler, modelin çıkarımları ve yorumları.
 *
 * Bilerek küçük ve hafif tutuldu: düz bir JSON dosyası + anahtar kelime araması.
 * Ağır bir vektör veritabanı yok; yüzlerce not birkaç yüz KB tutar ve A32'de bile anında aranır.
 * Böylece çekirdek model küçük kalır, bilgi kütüphanede büyür.
 * Dışa aktarılıp başka bir Android cihazdaki A1'e içe aktarılabilir.
 */
class Library(ctx: Context) {

    class Entry(
        val kind: String,        // bilgi | çıkarım | yorum
        val text: String,
        val tags: List<String>,
        val source: String,      // kullanıcı | claude | openai | ondevice ...
        val time: Long,
        var uses: Int,
        val field: String = "",   // matematik | fizik | kimya | biyoloji | tıp (kanunlar için)
        var conf: Int = 1          // kaç kez doğrulandı/pekişti
    )

    private val file = File(ctx.filesDir, "library.json")
    private val tr = Locale("tr", "TR")
    private val entries = ArrayList<Entry>()
    private var loaded = false
    private val maxEntries = 1500

    private val stop = setOf(
        "nedir", "nasıl", "için", "ile", "veya", "gibi", "bana", "sana", "şunu", "bunu",
        "olan", "daha", "çok", "değil", "ama", "fakat", "biraz"
    )

    /** Kelimeleri ilk 5 harfe indirger (Türkçe ekleri kabaca yok sayar). */
    private fun stems(text: String): Set<String> =
        text.lowercase(tr).split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 3 && it !in stop }
            .map { it.take(5) }
            .toSet()

    private fun toJson(e: Entry) = JSONObject()
        .put("kind", e.kind).put("text", e.text).put("tags", JSONArray(e.tags))
        .put("source", e.source).put("time", e.time).put("uses", e.uses)
        .put("field", e.field).put("conf", e.conf)

    private fun fromJson(o: JSONObject): Entry {
        val tg = ArrayList<String>()
        o.optJSONArray("tags")?.let { for (j in 0 until it.length()) tg.add(it.optString(j)) }
        return Entry(
            o.optString("kind", "bilgi"), o.getString("text"), tg,
            o.optString("source", ""), o.optLong("time", System.currentTimeMillis()), o.optInt("uses"),
            o.optString("field", ""), o.optInt("conf", 1)
        )
    }

    private fun load() {
        if (loaded) return
        loaded = true
        try {
            val arr = JSONObject(file.readText()).getJSONArray("entries")
            for (i in 0 until arr.length()) entries.add(fromJson(arr.getJSONObject(i)))
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val arr = JSONArray()
        for (e in entries) arr.put(toJson(e))
        file.writeText(JSONObject().put("entries", arr).toString())
    }

    @Synchronized
    fun add(kind: String, text: String, tags: List<String> = emptyList(), source: String = "kullanıcı"): Boolean =
        addEntry(
            Entry(
                kind, text.trim().take(600),
                tags.map { it.trim().lowercase(tr) }.filter { it.isNotEmpty() }.take(6),
                source, System.currentTimeMillis(), 0
            )
        )

    /** Çok benzer bir not varsa eklemez (false döner). */
    private fun addEntry(e: Entry): Boolean {
        load()
        if (e.text.length < 4) return false
        val s = stems(e.text)
        for (o in entries) {
            val os = stems(o.text)
            val union = (s + os).size
            if (union > 0 && s.intersect(os).size.toDouble() / union >= 0.8) return false
        }
        return insert(e)
    }

    private fun insert(e: Entry): Boolean {
        entries.add(e)
        while (entries.size > maxEntries) {
            // önce kanun olmayanlardan, en az kullanılan ve en eski notu at
            val victim = entries.minWithOrNull(
                compareBy<Entry>({ if (it.kind == "kanun") 1 else 0 }, { it.uses + it.conf }, { it.time })
            ) ?: break
            entries.remove(victim)
        }
        save()
        return true
    }

    // ---------------- temel kanunlar (kalite kapılı) ----------------

    val fields = listOf("matematik", "fizik", "kimya", "biyoloji", "tıp")
    private val yearRe = Regex("\\b(1[0-9]{3}|20[0-9]{2})\\b")

    /** Tarih/anekdot/boş laf gibi görünenleri baştan eler. */
    private fun worthy(t: String): Boolean {
        if (t.length !in 20..300) return false
        if (t.contains("http") || t.contains("www.")) return false
        if (yearRe.containsMatchIn(t)) return false
        return t.split(Regex("\\s+")).size >= 4
    }

    /**
     * Kanun veya türetilmiş çıkarım ekler. 1 = eklendi, 2 = zaten biliyordu (doğrulandı, pekişti),
     * 0 = reddedildi (önemsiz, tekrar veya çok benzer).
     */
    @Synchronized
    fun addLaw(kind: String, text: String, field: String, tags: List<String>, source: String): Int {
        load()
        val t = text.trim().trim('"', ' ')
        if (!worthy(t)) return 0
        val s = stems(t)
        if (s.size < 3) return 0
        for (o in entries) {
            val os = stems(o.text)
            val union = (s + os).size
            if (union > 0 && s.intersect(os).size.toDouble() / union >= 0.6) {
                if (kind == "kanun" && o.kind == "kanun") { o.conf++; save(); return 2 }
                return 0
            }
        }
        val e = Entry(
            kind, t.take(300), tags.map { it.trim().lowercase(tr) }.filter { it.isNotEmpty() }.take(4),
            source, System.currentTimeMillis(), 0, field, 1
        )
        return if (insert(e)) 1 else 0
    }

    /** Konuyla ilgili kanun ve çıkarımlar (kullanım sayacını artırmaz). */
    @Synchronized
    fun lawsFor(text: String, k: Int = 3): List<Entry> {
        load()
        val q = stems(text)
        if (q.isEmpty()) return emptyList()
        return entries.filter { it.kind == "kanun" || it.kind == "çıkarım" }
            .map { it to q.intersect(stems(it.text + " " + it.tags.joinToString(" "))).size }
            .filter { it.second >= 1 }
            .sortedByDescending { it.second * 10 + it.first.conf }
            .take(k).map { it.first }
    }

    @Synchronized
    fun count(): Int { load(); return entries.size }

    @Synchronized
    fun laws(): List<Entry> { load(); return entries.filter { it.kind == "kanun" } }

    @Synchronized
    fun lawCounts(): Map<String, Int> {
        load()
        val m = LinkedHashMap<String, Int>()
        for (f in fields) m[f] = 0
        for (e in entries) if (e.kind == "kanun" && m.containsKey(e.field)) m[e.field] = m.getValue(e.field) + 1
        return m
    }

    @Synchronized
    fun search(query: String, k: Int = 3): List<Entry> {
        load()
        val q = stems(query)
        if (q.isEmpty()) return emptyList()
        val need = if (q.size >= 3) 2 else 1
        val result = entries
            .map { e -> e to q.intersect(stems(e.text + " " + e.tags.joinToString(" "))).size }
            .filter { it.second >= need }
            .sortedWith(compareByDescending<Pair<Entry, Int>> { it.second + (if (it.first.kind == "kanun") 1 else 0) }.thenByDescending { it.first.time })
            .take(k)
            .map { it.first }
        result.forEach { it.uses++ }
        return result
    }

    /** İlgili notları modele verilecek kısa bir metne çevirir (yoksa boş). */
    fun contextFor(text: String): String {
        val r = search(text, 3)
        if (r.isEmpty()) return ""
        val sb = StringBuilder("Hafızandaki ilgili notlar (işine yararsa kullan, emin değilsen söyle):\n")
        for (e in r) sb.append("- [").append(e.kind).append("] ").append(e.text.take(300)).append("\n")
        return sb.toString()
    }

    @Synchronized
    fun stats(): String {
        load()
        if (entries.isEmpty()) return "Kütüphanem şimdilik boş."
        val c = entries.groupingBy { it.kind }.eachCount()
        val last = entries.maxByOrNull { it.time }!!
        return "Kütüphanemde ${entries.size} not var (kanun ${c["kanun"] ?: 0}, bilgi ${c["bilgi"] ?: 0}, çıkarım ${c["çıkarım"] ?: 0}, " +
            "yorum ${c["yorum"] ?: 0}). Son öğrendiğim: ${last.text.take(120)}"
    }

    // ---------------- ilişki haritası için ----------------

    /** Haritada gösterilecek notlar: yeni ve çok kullanılanlar önde. */
    @Synchronized
    fun forGraph(max: Int = 40): List<Entry> {
        load()
        return entries.sortedByDescending { it.time + (it.uses + it.conf * 2) * 3_600_000L + (if (it.kind == "kanun") 2_592_000_000L else 0L) }.take(max)
    }

    /** Ortak kelime veya etiket paylaşan notların çiftlerini (indeks) döndürür. */
    fun edgesFor(list: List<Entry>): List<IntArray> {
        val st = list.map { stems(it.text + " " + it.tags.joinToString(" ")) }
        val out = ArrayList<IntArray>()
        for (i in list.indices) {
            for (j in i + 1 until list.size) {
                val shared = st[i].intersect(st[j]).size
                val sameTag = list[i].tags.intersect(list[j].tags.toSet()).isNotEmpty()
                if (shared >= 2 || sameTag) out.add(intArrayOf(i, j))
                if (out.size >= 400) return out
            }
        }
        return out
    }

    // ---------------- dışa / içe aktarma ----------------

    @Synchronized
    fun exportJson(designs: JSONObject): JSONObject {
        load()
        val arr = JSONArray()
        for (e in entries) arr.put(toJson(e))
        return JSONObject()
            .put("format", "a1-kutuphane")
            .put("version", 1)
            .put("created", System.currentTimeMillis())
            .put("device", Build.MODEL ?: "")
            .put("entries", arr)
            .put("designs", designs)
    }

    /** Kütüphaneyi İndirilenler/A1 klasörüne yazar, yolu döndürür. */
    fun exportToDownloads(ctx: Context, designs: JSONObject): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val name = "a1_kutuphane_$stamp.json"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/A1")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Dosya oluşturulamadı.")
        ctx.contentResolver.openOutputStream(uri)?.use {
            it.write(exportJson(designs).toString(2).toByteArray(Charsets.UTF_8))
        } ?: throw IOException("Dosya yazılamadı.")
        return "İndirilenler/A1/$name"
    }

    /** [eklenen not, atlanan not] döndürür. Aynı notlar iki kez eklenmez. */
    @Synchronized
    fun importJson(o: JSONObject): IntArray {
        if (o.optString("format") != "a1-kutuphane") throw IOException("Bu bir A1 kütüphane dosyası değil.")
        load()
        val arr = o.optJSONArray("entries") ?: JSONArray()
        var added = 0
        var skipped = 0
        for (i in 0 until arr.length()) {
            val j = arr.optJSONObject(i) ?: continue
            val e = try { fromJson(j) } catch (_: Exception) { continue }
            if (addEntry(e)) added++ else skipped++
        }
        return intArrayOf(added, skipped)
    }
}
