package com.jarvis.app

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File

/**
 * Telefonun kendi işlemcisi ve belleğiyle çalışan yerel yapay zeka (Google LiteRT-LM).
 * İnternet gerekmez; model dosyası (.litertlm) bir kez telefona kopyalanır.
 * Bu sınıf kütüphaneye dokunan tek yerdir.
 */
class OnDeviceLlm(private val ctx: Context) {

    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var firstTurn = true

    private val rules = """
        Sen A1'sin: kullanıcının Android telefonunda, internetsiz çalışan kısa ve nazik bir asistansın.
        Türkçe cevap ver. Cevapların en fazla 1-3 cümle olsun, düz metin yaz, emoji ve madde işareti kullanma.
        Bilmediğin bir şeyi uydurma, bilmediğini söyle.
        İnternetten öğrenmeni isterlerse "araştır <konu>" demelerini söyle.
    """.trimIndent()

    fun modelFile() = File(ctx.filesDir, "model.litertlm")

    /** Önce kalıp komutlara bakar (hızlı ve güvenilir); eşleşmezse yerel modelle sohbet eder. */
    @Synchronized
    fun reply(text: String, skills: Skills): String {
        LocalCommands.tryHandle(text, skills)?.let { return it }

        val f = modelFile()
        if (!f.exists()) {
            return "Önce Ayarlar > Telefonda (çevrimdışı) bölümünden model dosyasını (.litertlm) seçin. Şimdilik sadece kalıp komutları anlıyorum."
        }
        try {
            if (engine == null) {
                val eng = Engine(EngineConfig(modelPath = f.absolutePath, backend = Backend.CPU()))
                eng.initialize() // ilk seferde yavaş olabilir
                engine = eng
            }
            val conv = conversation ?: engine!!.createConversation().also {
                conversation = it
                firstTurn = true
            }
            val note = skills.library.contextFor(text)
            val body = if (note.isEmpty()) text else note + "\nSoru: " + text
            val prompt = if (firstTurn) {
                firstTurn = false
                rules + "\n\nKullanıcı: " + body
            } else {
                body
            }
            val out = conv.sendMessage(prompt).toString().trim()
            return out.ifEmpty { "Tamamdır." }
        } catch (oom: OutOfMemoryError) {
            closeAll()
            return "Bellek yetmedi. Daha küçük bir model deneyin veya arka plandaki uygulamaları kapatın."
        } catch (t: Throwable) {
            return "Yerel model çalışmadı: ${t.message}"
        }
    }

    /** Sohbet geçmişini bozmadan tek seferlik bir istek (çıkarım için). */
    @Synchronized
    fun oneShot(prompt: String): String {
        val f = modelFile()
        if (!f.exists()) throw java.io.IOException("Yerel model dosyası yüklü değil.")
        if (engine == null) {
            val eng = Engine(EngineConfig(modelPath = f.absolutePath, backend = Backend.CPU()))
            eng.initialize()
            engine = eng
        }
        val conv = engine!!.createConversation()
        try {
            return conv.sendMessage(prompt).toString().trim()
        } finally {
            try { conv.close() } catch (_: Throwable) {}
        }
    }

    @Synchronized
    fun resetConversation() {
        try { conversation?.close() } catch (_: Throwable) {}
        conversation = null
        firstTurn = true
    }

    @Synchronized
    fun closeAll() {
        resetConversation()
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
    }
}
