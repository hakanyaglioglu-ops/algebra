package com.jarvis.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class ViewerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mesh = ModelStore.mesh
        if (mesh == null) {
            finish()
            return
        }
        val d = resources.displayMetrics.density
        val view = ModelView(this)
        view.setMesh(mesh)

        val e = mesh.extents()
        val title = TextView(this).apply {
            text = "${ModelStore.name}  ·  %.0f x %.0f x %.0f mm\n1 parmak: döndür   2 parmak: taşı / büyüt / küçült".format(e[0], e[1], e[2])
            setTextColor(Color.parseColor("#7FDBFF"))
            textSize = 12f
            setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
            setBackgroundColor(Color.parseColor("#050B14"))
        }

        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#050B14"))
            addView(btn("Sıfırla") { view.reset() })
            addView(btn("STL kaydet") {
                try {
                    val path = Cad.saveToDownloads(this@ViewerActivity, mesh, ModelStore.name)
                    Toast.makeText(this@ViewerActivity, "Kaydedildi: $path", Toast.LENGTH_LONG).show()
                } catch (ex: Exception) {
                    Toast.makeText(this@ViewerActivity, "Kaydedilemedi: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            })
            addView(btn("Kapat") { finish() })
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#050B14"))
            addView(title)
            addView(view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(bar)
        }
        setContentView(root)
    }
}
