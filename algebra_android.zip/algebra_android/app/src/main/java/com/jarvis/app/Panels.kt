package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Panel satırı. ok: null ise durum işareti yok; true/false ise ✓/✗. Program panelinde metin "HH:mm Başlık". */
class Row(var text: String, var ok: Boolean? = null)

/** kind: baglanti | yetenek | program | liste */
class Panel(var title: String, var kind: String, val rows: ArrayList<Row> = ArrayList())

/**
 * Yatay ekranın sağındaki bilgi panelleri. İçerik kullanıcıya aittir:
 * sesli/yazılı komutla ("bağlantılara Gmail ekle", "programa 18:00 gün sonu ekle",
 * "yeteneklerden sayaç çıkar", "Gmail yerine Drive") veya Ayarlar > Panelleri düzenle ile değişir.
 */
class Panels(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("a1_panels", Context.MODE_PRIVATE)
    private val tr = Locale("tr", "TR")
    private val list = ArrayList<Panel>()

    init { load() }

    // ---------------- saklama ----------------

    private fun load() {
        val raw = prefs.getString("data", null)
        if (raw == null) { defaults(); return }
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val p = Panel(o.getString("title"), o.optString("kind", "liste"))
                val rs = o.optJSONArray("rows") ?: JSONArray()
                for (j in 0 until rs.length()) {
                    val r = rs.getJSONObject(j)
                    p.rows.add(Row(r.getString("text"), if (r.has("ok")) r.getBoolean("ok") else null))
                }
                list.add(p)
            }
        } catch (_: Exception) {
            list.clear()
            defaults()
        }
        if (list.isEmpty()) defaults()
    }

    private fun save() {
        val arr = JSONArray()
        for (p in list) {
            val rs = JSONArray()
            for (r in p.rows) {
                val o = JSONObject().put("text", r.text)
                if (r.ok != null) o.put("ok", r.ok!!)
                rs.put(o)
            }
            arr.put(JSONObject().put("title", p.title).put("kind", p.kind).put("rows", rs))
        }
        prefs.edit().putString("data", arr.toString()).apply()
    }

    private fun defaults() {
        list.clear()
        list.add(Panel("Bağlantılar", "baglanti", arrayListOf(Row("İnternet", true), Row("Vikipedi", true), Row("Hava durumu", true))))
        list.add(Panel("Yetenekler", "yetenek", arrayListOf(Row("Sohbet"), Row("Kanun öğrenme"), Row("3D model"), Row("Sayaç ve alarm"))))
        list.add(Panel("Program", "program", arrayListOf(Row("09:00 Günün özeti"), Row("13:00 Ders çalış"), Row("21:00 Gün sonu"))))
        save()
    }

    /** Çizim için kopya (arayüz iş parçacığı güvenle okur). */
    @Synchronized
    fun snapshot(): List<Panel> = list.map { p -> Panel(p.title, p.kind, ArrayList(p.rows.map { Row(it.text, it.ok) })) }

    @Synchronized
    fun skillCount(): Int = list.firstOrNull { it.kind == "yetenek" }?.rows?.size ?: 0

    // ---------------- düzenleme (arayüz) ----------------

    @Synchronized
    fun addRow(pi: Int, text: String) {
        val p = list.getOrNull(pi) ?: return
        addTo(p, text)
        save()
    }

    @Synchronized
    fun setRow(pi: Int, ri: Int, text: String, ok: Boolean?) {
        val r = list.getOrNull(pi)?.rows?.getOrNull(ri) ?: return
        r.text = text.trim().ifEmpty { r.text }
        r.ok = ok
        save()
    }

    @Synchronized
    fun removeRow(pi: Int, ri: Int) {
        list.getOrNull(pi)?.rows?.let { if (ri in it.indices) it.removeAt(ri) }
        save()
    }

    @Synchronized
    fun addPanel(title: String) {
        if (title.isBlank()) return
        list.add(Panel(title.trim().take(24), "liste"))
        save()
    }

    @Synchronized
    fun removePanel(pi: Int) {
        if (pi in list.indices) list.removeAt(pi)
        save()
    }

    @Synchronized
    fun resetDefaults() { defaults() }

    private fun addTo(p: Panel, raw: String) {
        var t = raw.trim().take(60)
        if (t.isEmpty()) return
        val tm = Regex("^(\\d{1,2})[:.](\\d{2})\\s*(.*)$").find(t)
        if (p.kind == "program" && tm != null) {
            val hh = tm.groupValues[1].toInt().coerceIn(0, 23)
            val mm = tm.groupValues[2].toInt().coerceIn(0, 59)
            t = String.format("%02d:%02d %s", hh, mm, tm.groupValues[3].trim()).trim()
        }
        p.rows.add(Row(t, if (p.kind == "baglanti") true else null))
        if (p.kind == "program") p.rows.sortBy { it.text }
    }

    // ---------------- komutlar ----------------

    private fun norm(s: String) = s.lowercase(tr).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    private fun cap(s: String) = s.trim().replaceFirstChar { it.titlecase(tr) }

    private fun findPanel(tok: String): Panel? {
        val t = norm(tok)
        if (t.length < 3) return null
        for (p in list) {
            val stems = ArrayList<String>()
            stems.add(norm(p.title.split(" ")[0]).take(5))
            when (p.kind) {
                "baglanti" -> stems.add("bağla")
                "yetenek" -> { stems.add("yeten"); stems.add("beceri") }
                "program" -> { stems.add("progr"); stems.add("takvi"); stems.add("zaman"); stems.add("plan") }
            }
            if (stems.any { it.length >= 3 && t.startsWith(it) }) return p
        }
        return null
    }

    private fun matches(row: Row, item: String): Boolean {
        val r = norm(row.text)
        val words = norm(item).split(" ").filter { it.length >= 3 }
        if (words.isEmpty()) return false
        return words.all { r.contains(it.take(5)) }
    }

    /** Panel komutu değilse null döner. */
    @Synchronized
    fun command(low: String): String? {
        val l = low.trim().trimEnd('.', '!', '?')

        Regex("^yeni panel\\s+(.+)$").find(l)?.let {
            val title = cap(it.groupValues[1]).take(24)
            list.add(Panel(title, "liste")); save()
            return "\"$title\" paneli oluşturuldu. İçine \"${title.lowercase(tr)} ... ekle\" diyerek satır ekleyebilirsiniz."
        }
        Regex("^(.+?)\\s+panel(?:ini|i)?\\s+(?:sil|kaldır)$").find(l)?.let {
            val p = findPanel(it.groupValues[1]) ?: return "Böyle bir panel bulamadım."
            list.remove(p); save()
            return "\"${p.title}\" panelini kaldırdım."
        }

        val parts = l.split(Regex("\\s+"), 2)
        if (parts.size < 2) return null
        val p = findPanel(parts[0]) ?: return null
        val rest = parts[1]

        Regex("^(.+?)\\s+yerine\\s+(.+?)(?:\\s+(?:yaz|koy|olsun|ekle))?$").find(rest)?.let {
            val row = p.rows.firstOrNull { r -> matches(r, it.groupValues[1]) }
                ?: return "${p.title} panelinde \"${it.groupValues[1]}\" bulamadım."
            row.text = cap(it.groupValues[2]); save()
            return "${p.title} güncellendi: ${row.text}."
        }
        Regex("^(.+?)\\s+(?:ekle|ekler misin|ekleyin|ekleyelim)$").find(rest)?.let {
            addTo(p, cap(it.groupValues[1])); save()
            return "${p.title} paneline eklendi: ${cap(it.groupValues[1])}."
        }
        Regex("^(.+?)\\s+(?:çıkar|çıkarır mısın|sil|kaldır)$").find(rest)?.let {
            val row = p.rows.firstOrNull { r -> matches(r, it.groupValues[1]) }
                ?: return "${p.title} panelinde \"${it.groupValues[1]}\" bulamadım."
            p.rows.remove(row); save()
            return "${p.title} panelinden çıkardım: ${row.text}."
        }
        Regex("^(.+?)\\s+(bağlı değil|bağlı|kapalı|açık|çalışmıyor|çalışıyor)$").find(rest)?.let {
            val row = p.rows.firstOrNull { r -> matches(r, it.groupValues[1]) } ?: return null
            row.ok = it.groupValues[2] in setOf("bağlı", "açık", "çalışıyor"); save()
            return "${row.text}: ${if (row.ok == true) "açık" else "kapalı"} olarak işaretledim."
        }
        return null
    }
}
