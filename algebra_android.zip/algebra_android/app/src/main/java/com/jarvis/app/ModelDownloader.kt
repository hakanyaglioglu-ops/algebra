package com.jarvis.app

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** .litertlm model dosyasını internetten telefona indirir (yönlendirmeleri elle izler; anahtar yalnızca ilk sunucuya gider). */
object ModelDownloader {

    @Volatile var cancelled = false

    fun download(url: String, token: String, dest: File, progress: (Long, Long) -> Unit) {
        cancelled = false
        var cur = url
        var firstHost: String? = null
        var conn: HttpURLConnection? = null
        for (hop in 0 until 6) {
            val u = URL(cur)
            if (firstHost == null) firstHost = u.host
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "A1-Android/1.0")
            if (token.isNotBlank() && u.host == firstHost) c.setRequestProperty("Authorization", "Bearer $token")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("Yönlendirme adresi yok.")
                cur = URL(u, loc).toString()
                c.disconnect()
                continue
            }
            if (code == 401 || code == 403) throw IOException("HTTP $code: erişim reddedildi. Gemma gibi modeller için Hugging Face'te lisansı kabul edip erişim anahtarı (token) girin.")
            if (code !in 200..299) throw IOException("HTTP $code")
            conn = c
            break
        }
        val c = conn ?: throw IOException("Çok fazla yönlendirme.")
        val total = c.contentLengthLong
        val tmp = File(dest.parentFile, dest.name + ".part")
        try {
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(1 shl 16)
                    var got = 0L
                    var lastReport = 0L
                    while (true) {
                        if (cancelled) throw IOException("İndirme iptal edildi.")
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        if (got - lastReport >= (2L shl 20)) { lastReport = got; progress(got, total) }
                    }
                }
            }
            if (tmp.length() < (1L shl 20)) throw IOException("İndirilen dosya çok küçük; adres bir model dosyasına işaret etmiyor olabilir.")
            dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Model kaydedilemedi.")
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            c.disconnect()
        }
    }
}
