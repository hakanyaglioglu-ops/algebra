package com.jarvis.app

import android.graphics.Color

/** Renk paleti: ayarlardaki renk seçici ve sesli komutlar ("yazı rengini mavi yap") aynı listeyi kullanır. */
class NamedColor(val label: String, val color: Int, val aliases: List<String>)

object Palette {
    val colors = listOf(
        NamedColor("Beyaz", Color.parseColor("#FFFFFF"), listOf("beyaz")),
        NamedColor("Siyah", Color.parseColor("#000000"), listOf("siyah")),
        NamedColor("Koyu gri", Color.parseColor("#202124"), listOf("koyu gri", "antrasit")),
        NamedColor("Gri", Color.parseColor("#9AA0A6"), listOf("gri")),
        NamedColor("Kırmızı", Color.parseColor("#FF2A3D"), listOf("kırmızı")),
        NamedColor("Turuncu", Color.parseColor("#FF8A00"), listOf("turuncu")),
        NamedColor("Sarı", Color.parseColor("#FFE600"), listOf("sarı")),
        NamedColor("Altın", Color.parseColor("#D4AF37"), listOf("altın")),
        NamedColor("Yeşil", Color.parseColor("#22C55E"), listOf("yeşil")),
        NamedColor("Fosfor yeşil", Color.parseColor("#39FF14"), listOf("fosfor yeşil", "neon yeşil")),
        NamedColor("Camgöbeği", Color.parseColor("#22D3EE"), listOf("camgöbeği", "turkuaz", "cyan")),
        NamedColor("Açık mavi", Color.parseColor("#7DD3FC"), listOf("açık mavi", "buz mavisi")),
        NamedColor("Mavi", Color.parseColor("#1E9BFF"), listOf("mavi")),
        NamedColor("Lacivert", Color.parseColor("#0B1F6B"), listOf("lacivert")),
        NamedColor("Mor", Color.parseColor("#B44CFF"), listOf("mor")),
        NamedColor("Pembe", Color.parseColor("#FF3DA8"), listOf("pembe")),
        NamedColor("Kahverengi", Color.parseColor("#8B5A2B"), listOf("kahverengi"))
    )

    private val aliasPairs: List<Pair<String, Int>> = colors
        .flatMap { c -> c.aliases.map { it to c.color } }
        .sortedByDescending { it.first.length }

    /** Cümlenin içinde bir renk adı veya #RRGGBB varsa rengi döndürür (en uzun ad önce eşleşir). */
    fun find(text: String): Int? {
        Regex("#([0-9a-fA-F]{6})").find(text)?.let { return Color.parseColor("#" + it.groupValues[1]) }
        for ((alias, col) in aliasPairs) {
            if (Regex("(?<![\\p{L}])" + Regex.escape(alias)).containsMatchIn(text)) return col
        }
        return null
    }

    fun nameOf(color: Int): String =
        colors.firstOrNull { it.color == color }?.label ?: String.format("#%06X", color and 0xFFFFFF)
}
