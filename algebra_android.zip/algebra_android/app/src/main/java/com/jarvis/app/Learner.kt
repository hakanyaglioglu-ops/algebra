package com.jarvis.app

import android.content.Context
import android.os.StatFs
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * A1'in insan gibi öğrenme biçimi:
 *  1. Hatırla  : konuyla ilgili bildiği kanunları önce kendi hafızasından çıkarır (yeni bilgiyi eskiye bağlar).
 *  2. Oku      : kaynağı (Vikipedi) kendisi toplar.
 *  3. Özünü al : metni kopyalamaz; yalnızca temel kanun/ilke/denklemi tek cümleyle çıkarır.
 *  4. Sına     : kanunun kaynaktan aynen bir kanıt alıntısı olmalı; yoksa uydurma sayılır ve atılır.
 *  5. Pekiştir : aynı kanunu yeniden görürse kopya eklemez, güven puanını artırır.
 *  6. Çıkarım  : yeni kanunu eskilerle birleştirip zorunlu olarak çıkan yeni sonucu yazar.
 * Tarih, isim, anekdot ve tanım gibi "boş bilgi" kütüphaneye girmez.
 */
class Learner(
    ctx: Context,
    private val lib: Library,
    private val ask: (String, String) -> String,
    private val say: (String) -> Unit
) {
    private val tr = Locale("tr", "TR")
    private val appCtx = ctx.applicationContext
    private val prefs = ctx.getSharedPreferences("a1_learner", Context.MODE_PRIVATE)

    companion object {
        /** Verinin tutulduğu bölümde boş alan (MB). Okunamazsa çok büyük sayı döner. */
        fun freeMb(ctx: Context): Long = try {
            StatFs(ctx.filesDir.path).availableBytes / 1048576L
        } catch (_: Exception) { Long.MAX_VALUE }

        const val MIN_FREE_MB = 1024L
    }

    @Volatile private var running = false
    @Volatile private var cancel = false
    @Volatile private var fetchErr = ""

    /** Temel bilimlerin kök konuları; A1 en az çalışılmış alandan sırayla ilerler. */
    private val curriculum: Map<String, List<String>> = linkedMapOf(
        "matematik" to listOf(
            "Pisagor teoremi", "Türev", "İntegral", "Asal sayı", "Olasılık", "Logaritma", "Trigonometri",
            "Doğrusal cebir", "Küme kuramı", "Aritmetik dizi", "Kombinatorik", "Limit (matematik)", "Fonksiyon (matematik)",
            "Matris (matematik)", "Vektör", "Karmaşık sayı", "İstatistik", "Geometri", "Cebir", "Denklem",
            "Diferansiyel denklem", "Grup (matematik)", "Fibonacci dizisi", "Kalkülüs", "Bayes teoremi",
            "Merkezi limit teoremi", "Euler formülü"
        ),
        "fizik" to listOf(
            "Newton'un hareket yasaları", "Enerjinin korunumu", "Termodinamiğin yasaları", "Evrensel çekim yasası",
            "Ohm yasası", "Coulomb yasası", "Özel görelilik", "Dalga", "Basınç", "Momentumun korunumu", "Işığın kırılması",
            "Elektrik alan", "Manyetik alan", "Maxwell denklemleri", "Kuantum mekaniği", "Belirsizlik ilkesi", "Entropi",
            "Genel görelilik", "İş (fizik)", "Sürtünme", "Radyoaktivite", "Kepler yasaları", "Bernoulli ilkesi",
            "Arşimet prensibi", "Doppler etkisi"
        ),
        "kimya" to listOf(
            "Kütlenin korunumu yasası", "Mol", "Kimyasal bağ", "Asit ve baz", "İdeal gaz yasası", "Tepkime hızı",
            "Yükseltgenme ve indirgenme", "Le Chatelier ilkesi", "Periyodik tablo", "Avogadro yasası", "Atom",
            "Elektron dizilimi", "İyonik bağ", "Kovalent bağ", "Çözünürlük", "pH", "Kimyasal denge", "Termokimya",
            "Hess yasası", "Organik kimya", "Elektroliz", "Katalizör", "Titrasyon", "Oktet kuralı", "Boyle yasası", "Charles yasası"
        ),
        "biyoloji" to listOf(
            "Doğal seçilim", "Hücre", "DNA", "Fotosentez", "Hücresel solunum", "Mendel kalıtım yasaları", "Enzim",
            "Homeostazi", "Ekosistem", "Protein sentezi", "Mitoz", "Mayoz", "Gen", "Mutasyon", "Besin zinciri", "Kromozom",
            "Ribozom", "Adenozin trifosfat", "Ozmoz", "Difüzyon", "Biyoçeşitlilik", "Simbiyoz", "Hardy-Weinberg ilkesi", "Genetik kod"
        ),
        "tıp" to listOf(
            "Bağışıklık sistemi", "Dolaşım sistemi", "Enfeksiyon", "Hormon", "Sinir sistemi", "Metabolizma",
            "Farmakokinetik", "Solunum sistemi", "Enflamasyon", "Antibiyotik direnci", "Kan basıncı", "Kalp", "Böbrek",
            "Karaciğer", "Diyabet", "Aşı", "Virüs", "Bakteri", "Kanser", "İnsülin", "Antikor", "Farmakodinamik",
            "Doz-yanıt ilişkisi", "Kan pıhtılaşması"
        ),
        // "Türkçe başlık|English title": önce Türkçe, bulunamazsa İngilizce Vikipedi'de aranır
        "robotik" to listOf(
            "Robotik|Robotics", "İnsansı robot|Humanoid robot", "Robot kinematiği|Robot kinematics", "Ters kinematik|Inverse kinematics",
            "Denavit-Hartenberg parametreleri|Denavit–Hartenberg parameters", "Jacobien matrisi|Jacobian matrix and determinant",
            "Lagrange mekaniği|Lagrangian mechanics", "Sıfır moment noktası|Zero moment point", "Ters sarkaç|Inverted pendulum",
            "Bacaklı robot|Legged robot", "Hareket planlaması|Motion planning", "Eşzamanlı konumlandırma ve haritalama|Simultaneous localization and mapping",
            "Kalman filtresi|Kalman filter", "PID denetleyici|Proportional–integral–derivative controller", "Kontrol teorisi|Control theory",
            "Model öngörülü kontrol|Model predictive control", "Pekiştirmeli öğrenme|Reinforcement learning", "Empedans kontrolü|Impedance control",
            "Serbestlik derecesi|Degrees of freedom (mechanics)", "Robot Operating System|Robot Operating System"
        ),
        "elektronik" to listOf(
            "Fırçasız DC motor|Brushless DC electric motor", "Servo motor|Servomotor", "Adım motoru|Stepper motor",
            "Darbe genişlik modülasyonu|Pulse-width modulation", "Alan yönelimli kontrol|Vector control (motor)", "Lityum polimer pil|Lithium polymer battery",
            "Eylemsizlik ölçüm birimi|Inertial measurement unit", "Algılayıcı|Sensor", "CAN veri yolu|CAN bus", "Mikrodenetleyici|Microcontroller",
            "Motor sürücüsü|Motor controller", "Dönüş kodlayıcı|Rotary encoder", "Yük hücresi|Load cell", "Anahtarlamalı güç kaynağı|Switched-mode power supply"
        ),
        "mekanik" to listOf(
            "Dişli çark|Gear train", "Harmonik sürücü|Strain wave gearing", "Planet dişli|Epicyclic gearing", "Rulman|Bearing (mechanical)",
            "Gerilme (mekanik)|Stress (mechanics)", "Eğilme|Bending", "Yorulma (malzeme)|Fatigue (material)", "Alüminyum alaşımı|Aluminium alloy",
            "Karbon fiber|Carbon fiber reinforced polymer", "3B baskı|3D printing", "Sonlu elemanlar yöntemi|Finite element method",
            "Güvenlik katsayısı|Factor of safety", "Eylemsizlik momenti|Moment of inertia", "Titreşim|Vibration", "Isı transferi|Heat transfer",
            "Mühendislik toleransı|Engineering tolerance"
        ),
        "yazılım" to listOf(
            "Gerçek zamanlı bilgi işlem|Real-time computing", "Bilgisayarla görme|Computer vision", "Derin öğrenme|Deep learning",
            "Yapay sinir ağı|Artificial neural network", "Doğal dil işleme|Natural language processing", "Konuşma tanıma|Speech recognition",
            "Konuşma sentezi|Speech synthesis", "Sürüm denetim sistemi|Version control", "Sonlu durum makinesi|Finite-state machine",
            "Davranış ağacı|Behavior tree (artificial intelligence, robotics and control)", "Fizik motoru|Physics engine"
        )
    )

    private val distillSystem = """
        Sen titiz bir bilim öğrencisisin. Verilen metinden yalnızca TEMEL KANUN, İLKE, DENKLEM veya nedensel kuralları öğren.
        Tarih, kişi adı, tanım listesi, anekdot, örnek ve ayrıntı YAZMA. Metni kopyalama: özünü kendi cümlenle,
        genel geçer ve tek cümle olarak yaz (gerekirse formülle). En fazla 3 satır yaz.
        İlk satır şöyle olsun: ÖZET: konunun en fazla 2 cümlelik Türkçe özeti.
        Sonra kanun satırlarını yaz. Metinde temel bir kanun yoksa yalnızca ÖZET satırını yaz, kanun uydurma.
        Her kanun satırı tam şu biçimde olsun:
        KANUN: cümle | ALAN: matematik veya fizik veya kimya veya biyoloji veya tıp veya robotik veya elektronik veya mekanik veya yazılım | ETİKET: en fazla 3 kelime, virgüllü | KANIT: metinden, metnin kendi dilinde AYNEN kısa bir alıntı
    """.trimIndent()

    private val inferSystem = """
        Aşağıda numaralı temel kanunlar var. Yalnızca bunlara dayanarak, mantıksal olarak ZORUNLU çıkan yeni bir sonucu yaz.
        Alanlar arası bağ kurabilirsin. Kanunların tekrarı, genel laf veya tahmin olmasın.
        Böyle bir sonuç yoksa yalnızca YOK yaz. Aksi halde şu iki satırı yaz:
        ÇIKARIM: tek cümle
        ETİKET: en fazla 3 kelime, virgüllü
    """.trimIndent()

    // ---------------- komutlar ----------------

    /** Çalışma komutu değilse null döner. */
    fun command(low: String): String? {
        val l = low.trim()
        return try {
            when {
                Regex("^çalışmay[ıi]\\s+(?:bırak|durdur|kes)").containsMatchIn(l) -> {
                    if (running) { cancel = true; "Tamam, mevcut konudan sonra çalışmayı bırakıyorum." } else "Zaten çalışmıyorum."
                }
                Regex("^(?:temel\\s+)?kanunlar(?:ım)?\\??$|hangi kanunları|kaç kanun").containsMatchIn(l) -> lawReport()
                Regex("^(?:kanunlardan\\s+)?(?:yeni\\s+)?çıkarım\\s+türet").containsMatchIn(l) -> ponder()
                Regex("^(matematik|fizik|kimya|biyoloji|tıp|tip)\\s+kütüphane\\w*\\??$").find(l) != null -> {
                    fieldReport(normField(Regex("^(\\S+)").find(l)!!.groupValues[1]) ?: "")
                }
                Regex("(?:kendi kendine|temel bilimleri?|sürekli|durmadan)\\s+çalış|çalışmaya başla").containsMatchIn(l) -> {
                    val n = Regex("(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: 200
                    autoStudy(n.coerceIn(1, 500))
                }
                Regex("robot").containsMatchIn(l) && Regex("öğren|çalış|araştır").containsMatchIn(l) &&
                    Regex("\\b(için|bütün|tüm|hepsini|bilgileri|bilgilerini|konuları)\\b").containsMatchIn(l) -> {
                    autoStudy(300, setOf("robotik", "elektronik", "mekanik", "yazılım", "fizik", "matematik"))
                        .replace("Temel bilimlerden", "İnsansı robot için gereken konulardan (robotik, elektronik, mekanik, yazılım, fizik, matematik)")
                }
                Regex("internet|netten|\\bnet\\b|webden|vikipedi|online|çevrimiçi").containsMatchIn(l) &&
                    Regex("öğren|araştır|çalış|incele|oku").containsMatchIn(l) -> {
                    // "internetten öğren", "newton yasalarını internetten araştır" gibi doğal cümleler
                    val fill = setOf(
                        "internetten", "internet", "internetteki", "netten", "net", "webden", "web", "vikipediden", "vikipedi",
                        "online", "çevrimiçi", "öğren", "öğrenmeni", "öğrenmeye", "araştır", "araştırıp", "araştırarak", "çalış",
                        "incele", "oku", "ve", "bana", "bunu", "şunu", "lütfen", "hakkında", "konusunu", "konusu", "bir", "şeyi",
                        "şey", "kendin", "kendi", "kendine", "için", "bilgi", "bilgileri", "bilgiyi", "topla", "toplayıp", "başla"
                    )
                    val topic = l.replace(Regex("['’]\\p{L}*"), "").split(Regex("\\s+"))
                        .filter { it !in fill }.joinToString(" ").trim()
                    if (topic.length >= 3) study(topic)
                    else "Konu söylemediniz; temel bilimleri sırayla araştırıyorum. Belirli konu için \"internetten öğren <konu>\" deyin.\n" + autoStudy(200)
                }
                else -> {
                    val m = Regex("^(?:çalış|araştır|incele)\\s*[:,]?\\s+(.{3,})$").find(l)
                        ?: Regex("^(.{3,}?)\\s+(?:konusunu\\s+|hakkında\\s+)?araştır(?:\\s+ve\\s+öğren)?$").find(l)
                        ?: return null
                    study(m.groupValues[1].trim())
                }
            }
        } catch (e: Exception) {
            "Çalışamadım: ${e.message}"
        }
    }

    private fun lawReport(): String {
        val c = lib.lawCounts()
        val total = c.values.sum()
        if (total == 0) return "Henüz temel kanun öğrenmedim. \"çalış Newton'un hareket yasaları\" veya \"kendi kendine çalış\" diyebilirsiniz."
        val sb = StringBuilder("Temel kanun sayım: $total (")
        sb.append(c.entries.joinToString(", ") { "${it.key} ${it.value}" }).append(").")
        val top = lib.laws().sortedByDescending { it.conf }.take(2)
        for (e in top) sb.append("\n- ").append(e.text)
        return sb.toString()
    }

    // ---------------- çalışma ----------------

    private fun lowDiskMsg(mb: Long) =
        "Disk uyarısı: boş alan ${mb} MB, 1 GB'ın altına indi. Araştırmayı durdurdum. Yer açtıktan sonra \"kendi kendine çalış\" deyin; kaldığım yerden devam ederim."

    /** Müfredattan sırayla en fazla n konu çalışır; boş disk 1 GB'ın altına inerse durur ve haber verir. */
    private fun autoStudy(n: Int, only: Set<String>? = null): String {
        if (running) return "Zaten çalışıyorum. Durdurmak için \"çalışmayı bırak\" deyin."
        val free = freeMb(appCtx)
        if (free < MIN_FREE_MB) return lowDiskMsg(free)
        running = true
        cancel = false
        Thread {
            var done = 0
            try {
                for (i in 0 until n) {
                    if (cancel) break
                    val f = freeMb(appCtx)
                    if (f < MIN_FREE_MB) { say(lowDiskMsg(f)); return@Thread }
                    val next = nextTopic(only)
                    if (next == null) { say("Müfredattaki temel konuların hepsini bitirdim."); break }
                    say("(${i + 1}) Çalışıyorum: ${next.second} [${next.first}]")
                    say(study(next.second, next.first))
                    done++
                    Thread.sleep(1500)
                }
                say((if (cancel) "Çalışmayı bıraktım." else "Çalışma turu bitti.") + " $done konu çalışıldı.\n" + libSummary())
            } catch (e: Exception) {
                say("Çalışmayı yarıda bıraktım: ${e.message}\n" + libSummary())
            } finally {
                running = false
            }
        }.start()
        return "Temel bilimlerden sırayla çalışacağım (en fazla $n konu). Her konu bitince haber veririm; durdurmak için \"çalışmayı bırak\" deyin. " +
            "Boş disk 1 GB'ın altına inerse kendim dururum. Şu an boş alan: ${if (free == Long.MAX_VALUE) "bilinmiyor" else "$free MB"}."
    }

    private fun libSummary(): String {
        val ls = lib.lawCounts()
        val ss = lib.summaryCounts()
        return "Kütüphane: " + lib.fields.joinToString(", ") { "$it ${ss[it]} özet/${ls[it]} kanun" }
    }

    private fun fieldReport(field: String): String {
        if (field.isEmpty()) return "Hangi alan?"
        val sums = lib.latest("özet", field, 3)
        val nS = lib.summaryCounts()[field] ?: 0
        val nL = lib.lawCounts()[field] ?: 0
        if (nS == 0 && nL == 0) return "${field.replaceFirstChar { it.titlecase(tr) }} kütüphanem henüz boş. \"kendi kendine çalış\" diyerek başlatabilirsiniz."
        val sb = StringBuilder("${field.replaceFirstChar { it.titlecase(tr) }} kütüphanem: $nS özet, $nL kanun.")
        for (e in sums) sb.append("\n- ").append(e.tags.firstOrNull() ?: "").append(": ").append(e.text.take(110))
        return sb.toString()
    }

    private fun nextTopic(only: Set<String>? = null): Pair<String, String>? {
        val done = prefs.getStringSet("done", emptySet())!!.toSet()
        val remaining = curriculum.filter { e -> (only == null || e.key in only) && e.value.any { it !in done } }
        if (remaining.isEmpty()) return null
        val f = remaining.keys.minByOrNull { k -> curriculum.getValue(k).count { it in done } }!!
        return f to curriculum.getValue(f).first { it !in done }
    }

    private fun markDone(topic: String) {
        val done = prefs.getStringSet("done", emptySet())!!.toSet()
        prefs.edit().putStringSet("done", done + topic).apply()
    }

    private class Law(val text: String, val field: String, val tags: List<String>, val proof: String)

    /** Tek bir konuyu çalışır. Model/ağ hatasında istisna fırlatır (konu "çalışıldı" sayılmaz). */
    fun study(topicRaw: String, field: String = ""): String {
        val topic = topicRaw.substringBefore("|")
        fetchErr = ""
        val free = freeMb(appCtx)
        if (free < MIN_FREE_MB) return lowDiskMsg(free)
        val src = fetch(topicRaw) ?: return "\"$topic\" için kaynak bulamadım." +
            (if (fetchErr.isNotEmpty()) " Neden: $fetchErr" else " (Vikipedi'de bu başlık yok ya da internet kapalı.)")
        val title = src.first
        val text = src.second
        say("Kaynak bulundu: $title. Özünü çıkarıyorum...")

        // 1) hatırla
        val known = lib.lawsFor(topic, 4).joinToString("\n") { "- " + it.text }
        val prompt = (if (known.isEmpty()) "" else "Bildiklerin (yenisini bunlara bağla, tekrar etme):\n$known\n\n") +
            "Konu: $topic\nMetin:\n$text"

        // 2-3) oku ve özünü al
        val out = ask(distillSystem, prompt)
        markDone(topicRaw)
        val laws = parse(out, field)
        val summary = out.lines().map { it.trim() }
            .firstOrNull { it.uppercase(tr).startsWith("ÖZET:") || it.uppercase(tr).startsWith("OZET:") }
            ?.substringAfter(":")?.trim().orEmpty()

        // 4-5) sına ve kaydet
        val added = ArrayList<String>()
        var confirmed = 0
        var rejected = 0
        for (l in laws) {
            if (!grounded(l.proof, text)) { rejected++; continue }
            when (lib.addLaw("kanun", l.text, l.field, l.tags, "vikipedi:$title")) {
                1 -> added.add(l.text)
                2 -> confirmed++
                else -> rejected++
            }
        }

        // özet kütüphanesi: konu başına tek kısa özet, alan bilinirse
        val sf = field.ifEmpty { laws.groupBy { it.field }.maxByOrNull { it.value.size }?.key ?: "" }
        val summaryStored = sf.isNotEmpty() && summary.isNotEmpty() &&
            lib.addSummary(sf, topic, summary, "vikipedi:$title")

        // 6) çıkarım
        val inferred = ArrayList<String>()
        for (l in lib.laws().filter { it.text in added }.take(2)) {
            infer(l.text, l.field)?.let { inferred.add(it) }
        }

        if (added.isEmpty() && confirmed == 0 && inferred.isEmpty() && !summaryStored) {
            val why = when {
                out.isBlank() -> "model boş cevap verdi"
                laws.isEmpty() && !out.uppercase(tr).contains("KANUN:") && summary.isEmpty() ->
                    "model beklenen biçimde cevap vermedi (ilk satır: \"${out.trim().take(100)}\"). Daha güçlü bir model seçmeyi deneyin"
                laws.isEmpty() -> "metinde temel bir kanun/ilke yok"
                rejected > 0 -> "$rejected madde kaynakta kanıtı bulunmadığı veya önemsiz olduğu için elendi"
                else -> "yeni bir şey çıkmadı"
            }
            return "\"$title\" konusunu okudum, kütüphaneye boş bilgi eklemedim: $why." +
                (if (summary.isNotEmpty()) "\nÖğrendiğim özet: $summary" else "")
        }
        val sb = StringBuilder("Çalıştım: $title.")
        if (summary.isNotEmpty()) sb.append("\nÖzet").append(if (summaryStored) " ($sf özet kütüphanesine eklendi): " else ": ").append(summary)
        if (added.isNotEmpty()) {
            sb.append("\nYeni kanun (${added.size}):")
            for (a in added) sb.append("\n- ").append(a)
        }
        if (confirmed > 0) sb.append("\nZaten bildiğim $confirmed kanun pekişti.")
        for (i in inferred) sb.append("\nÇıkarım: ").append(i)
        if (rejected > 0) sb.append("\n($rejected madde kaynağa dayanmadığı veya önemsiz olduğu için elendi.)")
        return sb.toString()
    }

    /** Kütüphanedeki rastgele bir kanunu ilgili kanunlarla birleştirip yeni sonuç türetir. */
    private fun ponder(): String {
        val all = lib.laws()
        if (all.size < 2) return "Çıkarım için en az iki kanun gerekir. Önce \"çalış ...\" diyerek öğretin."
        for (l in all.shuffled().take(6)) {
            infer(l.text, l.field)?.let { return "Yeni çıkarım: $it" }
        }
        return "Mevcut kanunlardan zorunlu çıkan yeni bir sonuç bulamadım; kütüphaneye bir şey eklemedim."
    }

    private fun infer(law: String, field: String): String? {
        val rel = lib.lawsFor(law, 4).filter { it.text != law && it.kind == "kanun" }.take(3)
        if (rel.isEmpty()) return null
        val list = listOf(law) + rel.map { it.text }
        val out = ask(inferSystem, list.withIndex().joinToString("\n") { "${it.index + 1}. ${it.value}" })
        var c = ""
        var tg = ""
        for (line in out.lines()) {
            val l = line.trim()
            val u = l.uppercase(tr)
            if (u.startsWith("ÇIKARIM:") || u.startsWith("CIKARIM:")) c = l.substringAfter(":").trim()
            if (u.startsWith("ETİKET:") || u.startsWith("ETIKET:")) tg = l.substringAfter(":").trim()
        }
        if (c.isBlank() || c.lowercase(tr).trim('.', ' ') == "yok") return null
        val tags = tg.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2) +
            rel.flatMap { it.tags }.distinct().take(2)
        return if (lib.addLaw("çıkarım", c, field, tags, "çıkarım") == 1) c else null
    }

    // ---------------- yardımcılar ----------------

    private fun parse(out: String, fallbackField: String): List<Law> {
        val res = ArrayList<Law>()
        for (raw in out.lines()) {
            val line = raw.trim().trimStart('-', '*', '•', ' ')
            if (!line.uppercase(tr).startsWith("KANUN:")) continue
            val map = HashMap<String, String>()
            for (part in line.split("|")) {
                val k = part.substringBefore(":").trim().uppercase(tr)
                if (part.contains(":")) map[k] = part.substringAfter(":").trim()
            }
            val text = map["KANUN"] ?: continue
            val f = normField(map["ALAN"] ?: fallbackField) ?: normField(fallbackField) ?: continue
            val tags = (map["ETİKET"] ?: map["ETIKET"] ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
            res.add(Law(text, f, tags, map["KANIT"] ?: ""))
            if (res.size >= 3) break
        }
        return res
    }

    private fun normField(s: String): String? {
        val x = s.lowercase(tr).trim()
        return when {
            x.startsWith("mat") -> "matematik"
            x.startsWith("fiz") -> "fizik"
            x.startsWith("kim") -> "kimya"
            x.startsWith("biyo") -> "biyoloji"
            x == "tıp" || x == "tip" || x.startsWith("tıb") || x.startsWith("tib") -> "tıp"
            x.startsWith("robo") -> "robotik"
            x.startsWith("elek") -> "elektronik"
            x.startsWith("mekan") || x.startsWith("makine") || x.startsWith("malzeme") -> "mekanik"
            x.startsWith("yaz") || x.startsWith("bilgisayar") -> "yazılım"
            else -> null
        }
    }

    private fun norm(s: String) = s.lowercase(tr).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** Kanıt alıntısı kaynak metinde gerçekten geçiyor mu? (uydurmaya karşı). */
    private fun grounded(proof: String, src: String): Boolean {
        val p = norm(proof)
        if (p.length < 15) return false
        val s = norm(src)
        if (s.contains(p)) return true
        val pw = p.split(" ").filter { it.length >= 3 }
        if (pw.size < 3) return false
        val sw = s.split(" ").toSet()
        return pw.count { it in sw }.toDouble() / pw.size >= 0.7
    }

    /** Vikipedi: önce Türkçe, yoksa İngilizce. (başlık, giriş metni) döndürür. */
    private fun fetch(topicRaw: String): Pair<String, String>? {
        val trT = topicRaw.substringBefore("|")
        val enT = if (topicRaw.contains("|")) topicRaw.substringAfter("|") else trT
        for (lang in listOf("tr", "en")) {
            try {
                val topic = if (lang == "tr") trT else enT
                val q = URLEncoder.encode(topic, "UTF-8")
                val s = JSONObject(Http.get("https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&srlimit=1&format=json"))
                val hits = s.getJSONObject("query").getJSONArray("search")
                if (hits.length() == 0) continue
                val title = hits.getJSONObject(0).getString("title")
                val t = URLEncoder.encode(title, "UTF-8")
                val r = JSONObject(Http.get("https://$lang.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1&redirects=1&titles=$t&format=json"))
                val pages = r.getJSONObject("query").getJSONObject("pages")
                val page = pages.getJSONObject(pages.keys().next())
                val ex = page.optString("extract", "").trim()
                if (ex.length > 200) return Pair("$lang:$title", ex.take(3500))
            } catch (e: java.io.IOException) {
                fetchErr = "$lang.wikipedia.org erişilemedi (${e.message?.take(80)})"
            } catch (_: org.json.JSONException) {
            }
        }
        return null
    }
}
