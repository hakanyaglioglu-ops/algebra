package com.jarvis.app

import android.content.Context
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * A1'in insan gibi öğrenme biçimi:
 *  1. Hatırla  : konuyla ilgili bildiği kanunları önce kendi hafızasından çıkarır (yeni bilgiyi eskiye bağlar).
 *  2. Oku      : kaynağı (Vikipedi) kendisi toplar.
 *  3. Özünü al : metni kopyalamaz; yalnızca temel kanun/ilke/denklemi tek cümleyle çıkarır.
 *  4. Sına     : kanunun kaynaktan aynen bir kanıt alıntısı olmalı; yoksa uydurma sayılır ve atılır.
 *  5. Pekiştir : aynı kanunu yeniden görürse kopya eklemez, güven puanını artırır.
 *  6. Çıkarım  : yeni kanunu eskilerle birleştirip zorunlu olarak çıkan yeni sonucu yazar.
 * Tarih, isim, anekdot ve tanım gibi "boş bilgi" kütüphaneye girmez.
 */
class Learner(
    ctx: Context,
    private val lib: Library,
    private val ask: (String, String) -> String,
    private val say: (String) -> Unit
) {
    private val tr = Locale("tr", "TR")
    private val prefs = ctx.getSharedPreferences("a1_learner", Context.MODE_PRIVATE)

    @Volatile private var running = false
    @Volatile private var cancel = false
    @Volatile private var fetchErr = ""

    /** Temel bilimlerin kök konuları; A1 kütüphanesi en az dolu alandan sırayla çalışır. */
    private val curriculum: Map<String, List<String>> = linkedMapOf(
        "matematik" to listOf(
            "Pisagor teoremi", "Türev", "İntegral", "Asal sayı", "Olasılık", "Logaritma",
            "Trigonometri", "Doğrusal cebir", "Küme kuramı", "Aritmetik dizi", "Kombinatorik", "Limit (matematik)"
        ),
        "fizik" to listOf(
            "Newton'un hareket yasaları", "Enerjinin korunumu", "Termodinamiğin yasaları", "Evrensel çekim yasası",
            "Ohm yasası", "Coulomb yasası", "Özel görelilik", "Dalga", "Basınç", "Momentumun korunumu", "Işığın kırılması"
        ),
        "kimya" to listOf(
            "Kütlenin korunumu yasası", "Mol", "Kimyasal bağ", "Asit ve baz", "İdeal gaz yasası", "Tepkime hızı",
            "Yükseltgenme ve indirgenme", "Le Chatelier ilkesi", "Periyodik tablo", "Avogadro yasası"
        ),
        "biyoloji" to listOf(
            "Doğal seçilim", "Hücre", "DNA", "Fotosentez", "Hücresel solunum", "Mendel kalıtım yasaları",
            "Enzim", "Homeostazi", "Ekosistem", "Protein sentezi"
        ),
        "tıp" to listOf(
            "Bağışıklık sistemi", "Dolaşım sistemi", "Enfeksiyon", "Hormon", "Sinir sistemi", "Metabolizma",
            "Farmakokinetik", "Solunum sistemi", "Enflamasyon", "Antibiyotik direnci"
        )
    )

    private val distillSystem = """
        Sen titiz bir bilim öğrencisisin. Verilen metinden yalnızca TEMEL KANUN, İLKE, DENKLEM veya nedensel kuralları öğren.
        Tarih, kişi adı, tanım listesi, anekdot, örnek ve ayrıntı YAZMA. Metni kopyalama: özünü kendi cümlenle,
        genel geçer ve tek cümle olarak yaz (gerekirse formülle). En fazla 3 satır yaz.
        İlk satır şöyle olsun: ÖZET: konunun en fazla 2 cümlelik Türkçe özeti.
        Sonra kanun satırlarını yaz. Metinde temel bir kanun yoksa yalnızca ÖZET satırını yaz, kanun uydurma.
        Her kanun satırı tam şu biçimde olsun:
        KANUN: cümle | ALAN: matematik veya fizik veya kimya veya biyoloji veya tıp | ETİKET: en fazla 3 kelime, virgüllü | KANIT: metinden, metnin kendi dilinde AYNEN kısa bir alıntı
    """.trimIndent()

    private val inferSystem = """
        Aşağıda numaralı temel kanunlar var. Yalnızca bunlara dayanarak, mantıksal olarak ZORUNLU çıkan yeni bir sonucu yaz.
        Alanlar arası bağ kurabilirsin. Kanunların tekrarı, genel laf veya tahmin olmasın.
        Böyle bir sonuç yoksa yalnızca YOK yaz. Aksi halde şu iki satırı yaz:
        ÇIKARIM: tek cümle
        ETİKET: en fazla 3 kelime, virgüllü
    """.trimIndent()

    // ---------------- komutlar ----------------

    /** Çalışma komutu değilse null döner. */
    fun command(low: String): String? {
        val l = low.trim()
        return try {
            when {
                Regex("^çalışmay[ıi]\\s+(?:bırak|durdur|kes)").containsMatchIn(l) -> {
                    if (running) { cancel = true; "Tamam, mevcut konudan sonra çalışmayı bırakıyorum." } else "Zaten çalışmıyorum."
                }
                Regex("^(?:temel\\s+)?kanunlar(?:ım)?\\??$|hangi kanunları|kaç kanun").containsMatchIn(l) -> lawReport()
                Regex("^(?:kanunlardan\\s+)?(?:yeni\\s+)?çıkarım\\s+türet").containsMatchIn(l) -> ponder()
                Regex("(?:kendi kendine|temel bilimleri?)\\s+çalış|çalışmaya başla").containsMatchIn(l) -> {
                    val n = Regex("(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: 3
                    autoStudy(n.coerceIn(1, 10))
                }
                else -> {
                    val m = Regex("^(?:çalış|araştır|incele)\\s*[:,]?\\s+(.{3,})$").find(l)
                        ?: Regex("^(.{3,}?)\\s+(?:konusunu\\s+|hakkında\\s+)?araştır(?:\\s+ve\\s+öğren)?$").find(l)
                        ?: return null
                    study(m.groupValues[1].trim())
                }
            }
        } catch (e: Exception) {
            "Çalışamadım: ${e.message}"
        }
    }

    private fun lawReport(): String {
        val c = lib.lawCounts()
        val total = c.values.sum()
        if (total == 0) return "Henüz temel kanun öğrenmedim. \"çalış Newton'un hareket yasaları\" veya \"kendi kendine çalış\" diyebilirsiniz."
        val sb = StringBuilder("Temel kanun sayım: $total (")
        sb.append(c.entries.joinToString(", ") { "${it.key} ${it.value}" }).append(").")
        val top = lib.laws().sortedByDescending { it.conf }.take(2)
        for (e in top) sb.append("\n- ").append(e.text)
        return sb.toString()
    }

    // ---------------- çalışma ----------------

    /** Müfredattan sırayla n konu çalışır; arka planda ilerler, durum mesajı gönderir. */
    private fun autoStudy(n: Int): String {
        if (running) return "Zaten çalışıyorum. Durdurmak için \"çalışmayı bırak\" deyin."
        running = true
        cancel = false
        Thread {
            try {
                for (i in 0 until n) {
                    if (cancel) break
                    val next = nextTopic()
                    if (next == null) { say("Müfredattaki temel konuları bitirdim."); break }
                    say("Çalışıyorum: ${next.second} (${next.first})")
                    say(study(next.second, next.first))
                }
                say(if (cancel) "Çalışmayı bıraktım." else "Çalışma turu bitti.")
            } catch (e: Exception) {
                say("Çalışmayı yarıda bıraktım: ${e.message}")
            } finally {
                running = false
            }
        }.start()
        return "Temel bilimlerden $n konuyu sırayla çalışacağım; her biri bitince haber veririm."
    }

    private fun nextTopic(): Pair<String, String>? {
        val done = prefs.getStringSet("done", emptySet())!!.toSet()
        for (f in lib.lawCounts().entries.sortedBy { it.value }.map { it.key }) {
            val t = curriculum[f]?.firstOrNull { it !in done }
            if (t != null) return f to t
        }
        return null
    }

    private fun markDone(topic: String) {
        val done = prefs.getStringSet("done", emptySet())!!.toSet()
        prefs.edit().putStringSet("done", done + topic).apply()
    }

    private class Law(val text: String, val field: String, val tags: List<String>, val proof: String)

    /** Tek bir konuyu çalışır. Model/ağ hatasında istisna fırlatır (konu "çalışıldı" sayılmaz). */
    fun study(topic: String, field: String = ""): String {
        fetchErr = ""
        val src = fetch(topic) ?: return "\"$topic\" için kaynak bulamadım." +
            (if (fetchErr.isNotEmpty()) " Neden: $fetchErr" else " (Vikipedi'de bu başlık yok ya da internet kapalı.)")
        val title = src.first
        val text = src.second
        say("Kaynak bulundu: $title. Özünü çıkarıyorum...")

        // 1) hatırla
        val known = lib.lawsFor(topic, 4).joinToString("\n") { "- " + it.text }
        val prompt = (if (known.isEmpty()) "" else "Bildiklerin (yenisini bunlara bağla, tekrar etme):\n$known\n\n") +
            "Konu: $topic\nMetin:\n$text"

        // 2-3) oku ve özünü al
        val out = ask(distillSystem, prompt)
        markDone(topic)
        val laws = parse(out, field)
        val summary = out.lines().map { it.trim() }
            .firstOrNull { it.uppercase(tr).startsWith("ÖZET:") || it.uppercase(tr).startsWith("OZET:") }
            ?.substringAfter(":")?.trim().orEmpty()

        // 4-5) sına ve kaydet
        val added = ArrayList<String>()
        var confirmed = 0
        var rejected = 0
        for (l in laws) {
            if (!grounded(l.proof, text)) { rejected++; continue }
            when (lib.addLaw("kanun", l.text, l.field, l.tags, "vikipedi:$title")) {
                1 -> added.add(l.text)
                2 -> confirmed++
                else -> rejected++
            }
        }

        // 6) çıkarım
        val inferred = ArrayList<String>()
        for (l in lib.laws().filter { it.text in added }.take(2)) {
            infer(l.text, l.field)?.let { inferred.add(it) }
        }

        if (added.isEmpty() && confirmed == 0 && inferred.isEmpty()) {
            val why = when {
                out.isBlank() -> "model boş cevap verdi"
                laws.isEmpty() && !out.uppercase(tr).contains("KANUN:") && summary.isEmpty() ->
                    "model beklenen biçimde cevap vermedi (ilk satır: \"${out.trim().take(100)}\"). Daha güçlü bir model seçmeyi deneyin"
                laws.isEmpty() -> "metinde temel bir kanun/ilke yok"
                rejected > 0 -> "$rejected madde kaynakta kanıtı bulunmadığı veya önemsiz olduğu için elendi"
                else -> "yeni bir şey çıkmadı"
            }
            return "\"$title\" konusunu okudum, kütüphaneye boş bilgi eklemedim: $why." +
                (if (summary.isNotEmpty()) "\nÖğrendiğim özet: $summary" else "")
        }
        val sb = StringBuilder("Çalıştım: $title.")
        if (summary.isNotEmpty()) sb.append("\nÖzet: ").append(summary)
        if (added.isNotEmpty()) {
            sb.append("\nYeni kanun (${added.size}):")
            for (a in added) sb.append("\n- ").append(a)
        }
        if (confirmed > 0) sb.append("\nZaten bildiğim $confirmed kanun pekişti.")
        for (i in inferred) sb.append("\nÇıkarım: ").append(i)
        if (rejected > 0) sb.append("\n($rejected madde kaynağa dayanmadığı veya önemsiz olduğu için elendi.)")
        return sb.toString()
    }

    /** Kütüphanedeki rastgele bir kanunu ilgili kanunlarla birleştirip yeni sonuç türetir. */
    private fun ponder(): String {
        val all = lib.laws()
        if (all.size < 2) return "Çıkarım için en az iki kanun gerekir. Önce \"çalış ...\" diyerek öğretin."
        for (l in all.shuffled().take(6)) {
            infer(l.text, l.field)?.let { return "Yeni çıkarım: $it" }
        }
        return "Mevcut kanunlardan zorunlu çıkan yeni bir sonuç bulamadım; kütüphaneye bir şey eklemedim."
    }

    private fun infer(law: String, field: String): String? {
        val rel = lib.lawsFor(law, 4).filter { it.text != law && it.kind == "kanun" }.take(3)
        if (rel.isEmpty()) return null
        val list = listOf(law) + rel.map { it.text }
        val out = ask(inferSystem, list.withIndex().joinToString("\n") { "${it.index + 1}. ${it.value}" })
        var c = ""
        var tg = ""
        for (line in out.lines()) {
            val l = line.trim()
            val u = l.uppercase(tr)
            if (u.startsWith("ÇIKARIM:") || u.startsWith("CIKARIM:")) c = l.substringAfter(":").trim()
            if (u.startsWith("ETİKET:") || u.startsWith("ETIKET:")) tg = l.substringAfter(":").trim()
        }
        if (c.isBlank() || c.lowercase(tr).trim('.', ' ') == "yok") return null
        val tags = tg.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2) +
            rel.flatMap { it.tags }.distinct().take(2)
        return if (lib.addLaw("çıkarım", c, field, tags, "çıkarım") == 1) c else null
    }

    // ---------------- yardımcılar ----------------

    private fun parse(out: String, fallbackField: String): List<Law> {
        val res = ArrayList<Law>()
        for (raw in out.lines()) {
            val line = raw.trim().trimStart('-', '*', '•', ' ')
            if (!line.uppercase(tr).startsWith("KANUN:")) continue
            val map = HashMap<String, String>()
            for (part in line.split("|")) {
                val k = part.substringBefore(":").trim().uppercase(tr)
                if (part.contains(":")) map[k] = part.substringAfter(":").trim()
            }
            val text = map["KANUN"] ?: continue
            val f = normField(map["ALAN"] ?: fallbackField) ?: normField(fallbackField) ?: continue
            val tags = (map["ETİKET"] ?: map["ETIKET"] ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
            res.add(Law(text, f, tags, map["KANIT"] ?: ""))
            if (res.size >= 3) break
        }
        return res
    }

    private fun normField(s: String): String? {
        val x = s.lowercase(tr).trim()
        return when {
            x.startsWith("mat") -> "matematik"
            x.startsWith("fiz") -> "fizik"
            x.startsWith("kim") -> "kimya"
            x.startsWith("biyo") -> "biyoloji"
            x == "tıp" || x == "tip" || x.startsWith("tıb") || x.startsWith("tib") -> "tıp"
            else -> null
        }
    }

    private fun norm(s: String) = s.lowercase(tr).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** Kanıt alıntısı kaynak metinde gerçekten geçiyor mu? (uydurmaya karşı). */
    private fun grounded(proof: String, src: String): Boolean {
        val p = norm(proof)
        if (p.length < 15) return false
        val s = norm(src)
        if (s.contains(p)) return true
        val pw = p.split(" ").filter { it.length >= 3 }
        if (pw.size < 3) return false
        val sw = s.split(" ").toSet()
        return pw.count { it in sw }.toDouble() / pw.size >= 0.7
    }

    /** Vikipedi: önce Türkçe, yoksa İngilizce. (başlık, giriş metni) döndürür. */
    private fun fetch(topic: String): Pair<String, String>? {
        for (lang in listOf("tr", "en")) {
            try {
                val q = URLEncoder.encode(topic, "UTF-8")
                val s = JSONObject(Http.get("https://$lang.wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&srlimit=1&format=json"))
                val hits = s.getJSONObject("query").getJSONArray("search")
                if (hits.length() == 0) continue
                val title = hits.getJSONObject(0).getString("title")
                val t = URLEncoder.encode(title, "UTF-8")
                val r = JSONObject(Http.get("https://$lang.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1&redirects=1&titles=$t&format=json"))
                val pages = r.getJSONObject("query").getJSONObject("pages")
                val page = pages.getJSONObject(pages.keys().next())
                val ex = page.optString("extract", "").trim()
                if (ex.length > 200) return Pair("$lang:$title", ex.take(3500))
            } catch (e: java.io.IOException) {
                fetchErr = "$lang.wikipedia.org erişilemedi (${e.message?.take(80)})"
            } catch (_: org.json.JSONException) {
            }
        }
        return null
    }
}
