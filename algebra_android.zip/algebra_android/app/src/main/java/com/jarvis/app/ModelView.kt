package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Holografik tel kafes görüntüleyici.
 * 1 parmak: döndür · 2 parmak: taşı ve büyüt/küçült (çimdik).
 */
class ModelView(ctx: Context) : View(ctx) {

    private var nv = FloatArray(0)
    private var edges = IntArray(0)
    private var proj = FloatArray(0)
    private var lines = FloatArray(0)

    private var yaw = 0.6f
    private var pitch = 0.35f
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var touching = false

    // dokunma durumu
    private var lx = 0f; private var ly = 0f; private var lSpread = 0f; private var lCount = 0
    private var mx = 0f; private var my = 0f; private var mSpread = 0f; private var mCount = 0

    private val density = ctx.resources.displayMetrics.density
    private val bgColor = Color.parseColor("#050B14")
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 0, 229, 255); strokeWidth = 7f * density; strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 229, 255); strokeWidth = 1.6f * density
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(170, 0, 229, 255); strokeWidth = 1.5f * density
    }
    private val rect = RectF()

    fun setMesh(m: Mesh) {
        val b = m.bounds()
        val cx = (b[0] + b[3]) / 2; val cy = (b[1] + b[4]) / 2; val cz = (b[2] + b[5]) / 2
        val ext = max(0.0001f, max(b[3] - b[0], max(b[4] - b[1], b[5] - b[2])))
        nv = FloatArray(m.verts.size)
        var i = 0
        while (i < m.verts.size) {
            nv[i] = (m.verts[i] - cx) / ext
            nv[i + 1] = (m.verts[i + 1] - cy) / ext
            nv[i + 2] = (m.verts[i + 2] - cz) / ext
            i += 3
        }
        edges = m.edges
        proj = FloatArray(nv.size / 3 * 2)
        lines = FloatArray(edges.size / 2 * 4)
        reset()
    }

    fun reset() {
        yaw = 0.6f; pitch = 0.35f; zoom = 1f; panX = 0f; panY = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(bgColor)
        if (nv.isEmpty()) return

        if (!touching) yaw += 0.006f
        val w = width.toFloat()
        val h = height.toFloat()
        val base = min(w, h) * 0.7f * zoom
        val ox = w / 2f + panX
        val oy = h / 2f + panY

        // hologram tabanı
        val t = SystemClock.uptimeMillis()
        val rx = base * 0.75f
        val ry = rx * 0.22f
        val gy = oy + base * 0.6f
        rect.set(ox - rx, gy - ry, ox + rx, gy + ry)
        canvas.drawArc(rect, (t / 10 % 360).toFloat(), 250f, false, ring)
        rect.set(ox - rx * 0.7f, gy - ry * 0.7f, ox + rx * 0.7f, gy + ry * 0.7f)
        canvas.drawArc(rect, (360 - t / 7 % 360).toFloat(), 200f, false, ring)

        // izdüşüm
        val cyaw = cos(yaw); val syaw = sin(yaw)
        val cp = cos(pitch); val sp = sin(pitch)
        var vi = 0
        var pi = 0
        while (vi < nv.size) {
            val x = nv[vi]; val y = nv[vi + 1]; val z = nv[vi + 2]
            val x1 = x * cyaw - y * syaw
            val y1 = x * syaw + y * cyaw
            val y2 = y1 * cp - z * sp
            val z2 = y1 * sp + z * cp
            val k = 3f / (3f + y2)
            proj[pi] = ox + x1 * k * base
            proj[pi + 1] = oy - z2 * k * base
            vi += 3
            pi += 2
        }
        var li = 0
        var ei = 0
        while (ei < edges.size) {
            val a = edges[ei] * 2
            val b = edges[ei + 1] * 2
            lines[li] = proj[a]; lines[li + 1] = proj[a + 1]
            lines[li + 2] = proj[b]; lines[li + 3] = proj[b + 1]
            li += 4
            ei += 2
        }
        canvas.drawLines(lines, glow)
        canvas.drawLines(lines, line)
        postInvalidateOnAnimation()
    }

    // ---------------- dokunma ----------------

    private fun measure(e: MotionEvent, skip: Int) {
        var sx = 0f; var sy = 0f; var c = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            sx += e.getX(i); sy += e.getY(i); c++
        }
        if (c == 0) { mCount = 0; return }
        mx = sx / c; my = sy / c; mCount = c
        var d = 0f
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            d += hypot(e.getX(i) - mx, e.getY(i) - my)
        }
        mSpread = d / c
    }

    private fun sync() { lx = mx; ly = my; lSpread = mSpread; lCount = mCount }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { touching = true; measure(e, -1); sync() }
            MotionEvent.ACTION_POINTER_DOWN -> { measure(e, -1); sync() }
            MotionEvent.ACTION_POINTER_UP -> { measure(e, e.actionIndex); sync() }
            MotionEvent.ACTION_MOVE -> {
                measure(e, -1)
                if (mCount == lCount && mCount > 0) {
                    if (mCount == 1) {
                        yaw += (mx - lx) * 0.01f
                        pitch = (pitch + (my - ly) * 0.01f).coerceIn(-1.5f, 1.5f)
                    } else {
                        panX += mx - lx
                        panY += my - ly
                        if (lSpread > 10f) zoom = (zoom * mSpread / lSpread).coerceIn(0.2f, 6f)
                    }
                }
                sync()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }
}
