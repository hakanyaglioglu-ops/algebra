package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Hazır, doğru oranlı tasarım şablonları. Ölçüler mm, Z yukarı.
 * Küçük yapay zekalar bile "robot yap" diyerek bunları güvenle üretebilir.
 */
object Designs {

    val names = listOf("robot", "robot_arm", "rover", "gripper", "drone", "gear")

    private fun part(
        shape: String, size: JSONObject, px: Double, py: Double, pz: Double,
        rx: Double, ry: Double, rz: Double
    ): JSONObject = JSONObject().put("shape", shape).put("size", size)
        .put("position", JSONArray(listOf(px, py, pz)))
        .put("rotation_deg", JSONArray(listOf(rx, ry, rz)))

    private fun box(
        x: Double, y: Double, z: Double, px: Double, py: Double, pz: Double,
        rx: Double = 0.0, ry: Double = 0.0, rz: Double = 0.0
    ) = part("box", JSONObject().put("x", x).put("y", y).put("z", z), px, py, pz, rx, ry, rz)

    private fun cyl(
        r: Double, h: Double, px: Double, py: Double, pz: Double,
        rx: Double = 0.0, ry: Double = 0.0, rz: Double = 0.0
    ) = part("cylinder", JSONObject().put("radius", r).put("height", h), px, py, pz, rx, ry, rz)

    private fun sph(r: Double, px: Double, py: Double, pz: Double) =
        part("sphere", JSONObject().put("radius", r), px, py, pz, 0.0, 0.0, 0.0)

    // ---------------- şablonlar ----------------

    private fun robot(): JSONArray {
        val l = ArrayList<JSONObject>()
        l += box(30.0, 18.0, 38.0, 0.0, 0.0, 55.0)      // gövde
        l += box(24.0, 16.0, 6.0, 0.0, 0.0, 35.0)       // kalça
        l += box(22.0, 18.0, 18.0, 0.0, 0.0, 84.0)      // kafa
        l += sph(2.2, -5.0, -9.5, 86.0)                 // gözler
        l += sph(2.2, 5.0, -9.5, 86.0)
        l += cyl(1.2, 8.0, 0.0, 0.0, 97.0)              // anten
        l += sph(2.5, 0.0, 0.0, 102.0)
        for (sx in listOf(-1.0, 1.0)) {
            l += sph(5.0, sx * 21.0, 0.0, 72.0)         // omuz
            l += cyl(3.8, 24.0, sx * 21.0, 0.0, 58.0)   // üst kol
            l += cyl(3.2, 20.0, sx * 21.0, 0.0, 36.0)   // alt kol
            l += sph(4.0, sx * 21.0, 0.0, 24.0)         // el
            l += cyl(5.0, 32.0, sx * 8.0, 0.0, 19.0)    // bacak
            l += box(12.0, 20.0, 4.0, sx * 8.0, -3.0, 2.0) // ayak
        }
        return JSONArray(l)
    }

    private fun robotArm(): JSONArray {
        val l = ArrayList<JSONObject>()
        l += cyl(25.0, 10.0, 0.0, 0.0, 5.0)             // taban
        l += cyl(15.0, 14.0, 0.0, 0.0, 17.0)            // dönen gövde
        l += box(12.0, 26.0, 16.0, 0.0, 0.0, 30.0)      // omuz bloğu
        l += cyl(8.0, 30.0, 0.0, 0.0, 38.0, rx = 90.0)  // omuz mafsalı
        l += box(9.0, 9.0, 52.0, 0.0, 0.0, 64.0)        // alt kol
        l += cyl(7.0, 22.0, 0.0, 0.0, 90.0, rx = 90.0)  // dirsek mafsalı
        // üst kol ve tutucu: Y ekseni etrafında 60° eğik, dirsekten başlar
        val dx = sin(Math.toRadians(60.0))
        val dz = cos(Math.toRadians(60.0))
        fun px(dist: Double) = dx * dist
        fun pz(dist: Double) = 90.0 + dz * dist
        l += box(8.0, 8.0, 44.0, px(22.0), 0.0, pz(22.0), ry = 60.0)         // üst kol
        l += cyl(5.0, 12.0, px(44.0), 0.0, pz(44.0), rx = 90.0)              // bilek
        l += box(8.0, 18.0, 8.0, px(53.0), 0.0, pz(53.0), ry = 60.0)         // avuç
        l += box(4.0, 3.0, 18.0, px(66.0), -6.0, pz(66.0), ry = 60.0)        // parmaklar
        l += box(4.0, 3.0, 18.0, px(66.0), 6.0, pz(66.0), ry = 60.0)
        return JSONArray(l)
    }

    private fun rover(): JSONArray {
        val l = ArrayList<JSONObject>()
        l += box(80.0, 50.0, 12.0, 0.0, 0.0, 16.0)      // şasi
        l += box(40.0, 34.0, 14.0, -8.0, 0.0, 29.0)     // kabin
        for (sx in listOf(-28.0, 28.0)) for (sy in listOf(-30.0, 30.0)) {
            l += cyl(12.0, 8.0, sx, sy, 12.0, rx = 90.0) // tekerlekler
        }
        l += sph(5.0, 38.0, 0.0, 26.0)                  // sensör / kamera
        l += cyl(1.0, 18.0, -25.0, 0.0, 45.0)           // anten
        l += sph(2.0, -25.0, 0.0, 55.0)
        return JSONArray(l)
    }

    private fun gripper(): JSONArray {
        val l = ArrayList<JSONObject>()
        l += box(44.0, 30.0, 10.0, 0.0, 0.0, 5.0)       // taban
        l += box(30.0, 24.0, 22.0, 0.0, 0.0, 21.0)      // servo gövdesi
        l += box(60.0, 10.0, 6.0, 0.0, 0.0, 35.0)       // ray
        for (sx in listOf(-1.0, 1.0)) {
            l += box(8.0, 10.0, 34.0, sx * 24.0, 0.0, 55.0) // parmak
            l += box(10.0, 10.0, 8.0, sx * 19.0, 0.0, 68.0) // parmak ucu
        }
        return JSONArray(l)
    }

    private fun drone(): JSONArray {
        val l = ArrayList<JSONObject>()
        l += box(40.0, 40.0, 12.0, 0.0, 0.0, 20.0)      // gövde
        l += box(70.0, 6.0, 4.0, 0.0, 0.0, 20.0, rz = 45.0)   // kollar
        l += box(70.0, 6.0, 4.0, 0.0, 0.0, 20.0, rz = -45.0)
        val c = 24.7
        for (sx in listOf(-c, c)) for (sy in listOf(-c, c)) {
            l += cyl(7.0, 10.0, sx, sy, 23.0)           // motor
            l += cyl(20.0, 1.5, sx, sy, 30.0)           // pervane
        }
        for (sx in listOf(-14.0, 14.0)) for (sy in listOf(-14.0, 14.0)) {
            l += cyl(1.5, 14.0, sx, sy, 7.0)            // iniş ayakları
        }
        return JSONArray(l)
    }

    private fun gear(teeth: Int): JSONArray {
        val n = teeth.coerceIn(6, 40)
        val r = 20.0
        val h = 8.0
        val l = ArrayList<JSONObject>()
        l += cyl(r, h, 0.0, 0.0, h / 2)                 // gövde
        l += cyl(6.0, h + 6.0, 0.0, 0.0, (h + 6.0) / 2) // göbek
        val w = 2 * PI * r / n * 0.45
        for (i in 0 until n) {
            val a = 2 * PI * i / n
            l += box(4.0, w, h, r * cos(a), r * sin(a), h / 2, rz = Math.toDegrees(a))
        }
        return JSONArray(l)
    }

    /** Şablonu üretir; size ≈ en büyük boyut (mm). Bilinmeyen şablonda null. */
    fun build(template: String, size: Double?, teeth: Int): JSONArray? {
        val (parts, base) = when (template) {
            "robot", "humanoid" -> robot() to 105.0
            "robot_arm", "arm" -> robotArm() to 130.0
            "rover" -> rover() to 80.0
            "gripper" -> gripper() to 72.0
            "drone" -> drone() to 90.0
            "gear" -> gear(teeth) to 47.0
            else -> return null
        }
        val s = if (size != null && size > 0) size / base else 1.0
        return if (s == 1.0) parts else scaleParts(parts, s)
    }

    /** Tüm ölçüleri ve konumları s kadar büyütür/küçültür; dönüşler aynı kalır. */
    fun scaleParts(a: JSONArray, s: Double): JSONArray {
        val out = JSONArray()
        for (i in 0 until a.length()) {
            val p = a.getJSONObject(i)
            val sz = p.optJSONObject("size") ?: JSONObject()
            val nsz = JSONObject()
            for (k in sz.keys()) nsz.put(k, sz.getDouble(k) * s)
            val pos = p.optJSONArray("position")
            val npos = JSONArray()
            for (j in 0 until 3) npos.put((pos?.optDouble(j, 0.0) ?: 0.0) * s)
            out.put(
                JSONObject().put("shape", p.getString("shape")).put("size", nsz).put("position", npos)
                    .put("rotation_deg", p.optJSONArray("rotation_deg") ?: JSONArray(listOf(0.0, 0.0, 0.0)))
            )
        }
        return out
    }
}

/** Kullanıcının beğendiği tasarımları telefonda saklar ve benzer isteklerde örnek olarak sunar. */
class DesignMemory(ctx: Context) {
    private val file = File(ctx.filesDir, "designs.json")
    private val tr = Locale("tr", "TR")

    private fun db(): JSONObject = try {
        JSONObject(file.readText())
    } catch (_: Exception) {
        JSONObject()
    }

    fun names(): List<String> = db().keys().asSequence().toList()

    fun save(name: String, parts: JSONArray) {
        val o = db()
        o.put(name.trim().lowercase(tr), JSONObject().put("parts", parts).put("time", System.currentTimeMillis()))
        file.writeText(o.toString())
    }

    fun get(name: String): JSONArray? {
        val o = db()
        val k = name.trim().lowercase(tr)
        val key = if (o.has(k)) k else o.keys().asSequence().firstOrNull { it.contains(k) || k.contains(it) }
        return key?.let { o.getJSONObject(it).getJSONArray("parts") }
    }

    /** Tüm kayıtlı tasarımları (dışa aktarma için) döndürür. */
    fun exportAll(): JSONObject = db()

    /** Başka bir cihazdan gelen tasarımları birleştirir; aynı adda daha yeni olan kalır. */
    fun importAll(o: JSONObject): Int {
        val d = db()
        var n = 0
        for (k in o.keys().asSequence().toList()) {
            val incoming = o.optJSONObject(k) ?: continue
            val cur = d.optJSONObject(k)
            if (cur == null || incoming.optLong("time") > cur.optLong("time")) {
                d.put(k, incoming)
                n++
            }
        }
        if (n > 0) file.writeText(d.toString())
        return n
    }

    /** İsteğe benzeyen kayıtlı tasarımları yapay zekaya örnek olarak verilecek metne çevirir. */
    fun examplesFor(text: String, max: Int = 2): String {
        val words = text.lowercase(tr).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }
        val d = db()
        val best = d.keys().asSequence()
            .map { k -> k to words.count { w -> k.contains(w) } }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(max)
            .toList()
        if (best.isEmpty()) return ""
        val sb = StringBuilder(
            "\n\nKullanıcının daha önce onayladığı tasarımlar (benzer istekte örnek al, gerekirse ölçek veya parça değiştir):\n"
        )
        for ((k, _) in best) {
            val parts = d.getJSONObject(k).getJSONArray("parts").toString()
            if (parts.length <= 3000) sb.append("- $k: $parts\n")
        }
        return sb.toString()
    }
}
