package com.jarvis.app

/**
 * Sesli (veya yazılı) ayar komutları. Yapay zekaya gitmeden önce çalışır; eşleşirse cevap metnini döndürür.
 * Örnekler: "yazı rengini mavi yap", "arka planı siyah yap", "dünyayı göster", "yapay zekayı Claude yap".
 */
class VoiceControl(private val s: Settings, private val host: Host) {

    interface Host {
        fun colorsChanged()
        fun setMode(m: Int)
        fun openSettings()
        fun listenContinuous(on: Boolean)
        fun voiceChanged()
        fun providerChanged()
    }

    private val tr = java.util.Locale("tr", "TR")

    private fun has(low: String, vararg words: String) = words.any { low.contains(it) }

    private fun providerOf(low: String): String? = when {
        has(low, "claude", "klod") -> Providers.CLAUDE
        has(low, "chatgpt", "chat gpt", "çet", "openai", "open ai") -> Providers.CHATGPT
        has(low, "gemini", "cemini", "jemini") -> Providers.GEMINI
        has(low, "deepseek", "deep seek", "dipsik", "dip sik") -> Providers.DEEPSEEK
        has(low, "pollinations", "polinasyon", "ücretsiz") -> Providers.POLLINATIONS
        has(low, "kendi yapay", "telefondaki", "telefonda", "yerel", "çevrimdışı", "varsayılan") -> Providers.ONDEVICE
        has(low, "yapay zekasız", "yapay zeka kullanma") -> Providers.OFFLINE
        else -> null
    }

    fun handle(raw: String): String? {
        val low = raw.lowercase(tr).trim()
        if (low.isEmpty()) return null

        // ---- renkler ----
        val col = Palette.find(low)
        if (col != null && has(low, "renk", "yap", "olsun", "değiştir", "boya")) {
            val bg = has(low, "arka plan", "arkaplan", "zemin", "fon")
            val ring = has(low, "halka", "daire", "çember", "dünya rengi", "ağ rengi")
            return when {
                bg -> { s.bgColor = col; host.colorsChanged(); "Arka plan ${Palette.nameOf(col).lowercase(tr)} oldu." }
                ring -> { s.ringColor = col; host.colorsChanged(); "Halka rengi ${Palette.nameOf(col).lowercase(tr)} oldu." }
                has(low, "yazı", "yazıyı", "metin", "isim", "ismi", "harf") -> {
                    s.textColor = col; host.colorsChanged(); "Yazı rengi ${Palette.nameOf(col).lowercase(tr)} oldu."
                }
                else -> null
            }
        }

        // ---- ekran durumu ----
        if (has(low, "yazıya dön", "ismi göster", "ana ekran", "alfa yazısı", "yazıyı göster", "başa dön")) {
            host.setMode(BrainView.MODE_TEXT); return "Tamam."
        }
        if (has(low, "dünyayı", "dünyaya", "dünya göster", "dünya modu", "globe", "küre")) {
            host.setMode(BrainView.MODE_GLOBE); return "Dünya açıldı."
        }
        if (has(low, "ağa geç", "ağı göster", "ağı aç", "bağlantı ağı", "network", "ağ modu")) {
            host.setMode(BrainView.MODE_NET); return "Ağ açıldı."
        }

        // ---- yapay zeka seçimi ----
        val verb = has(low, "geç", "seç", "kullan", "yap", "değiştir", "olsun")
        val pv = providerOf(low)
        if (verb && pv != null && (has(low, "yapay zek", "model", "motor", "kullan") || low.split(" ").size <= 4)) {
            if (Providers.needsKey(pv) && s.key(pv).isBlank()) {
                host.openSettings()
                return "${Providers.label(pv)} için önce API anahtarı girmeniz gerekiyor. Ayarları açtım."
            }
            s.provider = pv
            host.providerChanged()
            return "Yapay zeka olarak ${Providers.label(pv)} seçildi."
        }

        // ---- ses ----
        if (has(low, "sesli okumayı kapat", "sessiz ol", "konuşmayı kapat", "sesi kapat", "konuşma")  && has(low, "kapat", "sessiz")) {
            s.speak = false; return "Sesli okuma kapandı."
        }
        if (has(low, "sesli okumayı aç", "konuşmayı aç", "sesi aç", "konuşmaya başla")) {
            s.speak = true; host.voiceChanged(); return "Sesli okuma açıldı."
        }
        if (has(low, "ses tonu", "sesin tonu", "tonunu", "perde")) {
            val down = has(low, "düşür", "kalın", "azalt", "alçalt")
            val up = has(low, "yükselt", "incelt", "artır", "yüksel")
            if (down || up) {
                s.pitch = (s.pitch + if (up) 0.1f else -0.1f).coerceIn(0.5f, 1.5f)
                host.voiceChanged()
                return "Ses tonu yüzde ${(s.pitch * 100).toInt()}."
            }
        }
        if (has(low, "hızlı konuş", "daha hızlı", "hızını artır")) {
            s.rate = (s.rate + 0.1f).coerceIn(0.5f, 1.6f); host.voiceChanged(); return "Konuşma hızı yüzde ${(s.rate * 100).toInt()}."
        }
        if (has(low, "yavaş konuş", "daha yavaş", "hızını azalt", "hızını düşür")) {
            s.rate = (s.rate - 0.1f).coerceIn(0.5f, 1.6f); host.voiceChanged(); return "Konuşma hızı yüzde ${(s.rate * 100).toInt()}."
        }
        if (has(low, "ses ayarlarını sıfırla", "sesi sıfırla")) {
            s.pitch = 0.85f; s.rate = 0.95f; host.voiceChanged(); return "Ses ayarları sıfırlandı."
        }
        if (has(low, "türkçe konuş")) { s.lang = "tr"; return "Türkçe konuşacağım." }
        if (has(low, "ingilizce konuş", "english")) { s.lang = "en"; return "I will speak English." }
        if (has(low, "dili otomatik", "otomatik dil", "iki dilde")) { s.lang = "auto"; return "Dili cevaba göre seçeceğim." }

        // ---- dinleme / ayarlar ----
        if (has(low, "sürekli dinle", "dinlemeye devam", "dinlemeyi sürdür")) { host.listenContinuous(true); return "Sürekli dinliyorum." }
        if (has(low, "dinlemeyi bırak", "dinlemeyi kapat", "dinlemeyi durdur", "sürekli dinlemeyi kapat")) {
            host.listenContinuous(false); return "Dinlemeyi bıraktım."
        }
        if (has(low, "ayarları aç", "ayarlar", "ayar menüsü")) { host.openSettings(); return "Ayarlar açıldı." }
        return null
    }
}
