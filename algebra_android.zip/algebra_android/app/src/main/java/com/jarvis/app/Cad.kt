package com.jarvis.app

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Üretilen 3D model. Birimler milimetre, Z yukarı. */
class Mesh(
    val verts: FloatArray,   // x,y,z düz dizi
    val tris: IntArray,      // üçgen köşe indeksleri (3'lü)
    val edges: IntArray,     // görüntüleyici için tel kafes çizgileri (2'li)
    val volumeMm3: Double    // parçaların hacim toplamı (üst üste binmeler iki kez sayılır)
) {
    /** [minX,minY,minZ,maxX,maxY,maxZ] */
    fun bounds(): FloatArray {
        val b = floatArrayOf(
            Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE,
            -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE
        )
        var i = 0
        while (i < verts.size) {
            for (k in 0..2) {
                val v = verts[i + k]
                if (v < b[k]) b[k] = v
                if (v > b[k + 3]) b[k + 3] = v
            }
            i += 3
        }
        return b
    }

    fun extents(): FloatArray {
        val b = bounds()
        return floatArrayOf(b[3] - b[0], b[4] - b[1], b[5] - b[2])
    }
}

/** Son üretilen modeli ekranlar arasında taşır. */
object ModelStore {
    @Volatile var mesh: Mesh? = null
    @Volatile var name: String = "model"
    @Volatile var parts: JSONArray? = null
}

object Cad {
    private const val N = 32

    private class Part(val v: List<DoubleArray>, val t: List<IntArray>, val e: List<IntArray>)

    fun safeName(n: String): String =
        n.replace(Regex("[^A-Za-z0-9_-]+"), "_").trim('_').ifEmpty { "model" }

    fun build(parts: JSONArray): Mesh {
        require(parts.length() in 1..80) { "Parça sayısı 1 ile 80 arasında olmalı." }
        val verts = ArrayList<Float>()
        val tris = ArrayList<Int>()
        val edges = ArrayList<Int>()
        var volume = 0.0

        for (k in 0 until parts.length()) {
            val p = parts.getJSONObject(k)
            val part = makePart(p)
            val rot = p.optJSONArray("rotation_deg")
            val pos = p.optJSONArray("position")
            val rx = Math.toRadians(rot?.optDouble(0, 0.0) ?: 0.0)
            val ry = Math.toRadians(rot?.optDouble(1, 0.0) ?: 0.0)
            val rz = Math.toRadians(rot?.optDouble(2, 0.0) ?: 0.0)
            val px = pos?.optDouble(0, 0.0) ?: 0.0
            val py = pos?.optDouble(1, 0.0) ?: 0.0
            val pz = pos?.optDouble(2, 0.0) ?: 0.0

            val tv = part.v.map { transform(it, rx, ry, rz, px, py, pz) }
            val off = verts.size / 3
            for (v in tv) {
                verts.add(v[0].toFloat()); verts.add(v[1].toFloat()); verts.add(v[2].toFloat())
            }
            var vol = 0.0
            for (t in part.t) {
                tris.add(off + t[0]); tris.add(off + t[1]); tris.add(off + t[2])
                vol += triple(tv[t[0]], tv[t[1]], tv[t[2]])
            }
            volume += abs(vol) / 6.0
            for (e in part.e) {
                edges.add(off + e[0]); edges.add(off + e[1])
            }
        }
        return Mesh(verts.toFloatArray(), tris.toIntArray(), edges.toIntArray(), volume)
    }

    // ---------------- şekiller ----------------

    private fun num(s: JSONObject, def: Double, vararg keys: String): Double {
        for (k in keys) if (s.has(k)) return max(0.1, s.optDouble(k, def))
        return def
    }

    private fun makePart(p: JSONObject): Part {
        val shape = p.optString("shape").lowercase()
        val s = p.optJSONObject("size") ?: JSONObject().also { o ->
            val nv = p.optDouble("size", Double.NaN)
            if (!nv.isNaN()) {
                o.put("x", nv); o.put("y", nv); o.put("z", nv)
                o.put("radius", nv); o.put("height", nv)
                o.put("major_radius", nv); o.put("minor_radius", nv / 4)
            }
        }
        return when (shape) {
            "box" -> box(
                num(s, 10.0, "x", "width"),
                num(s, 10.0, "y", "depth"),
                num(s, 10.0, "z", "height")
            )
            "cylinder" -> cylinder(num(s, 5.0, "radius", "r"), num(s, 10.0, "height", "h", "z"))
            "sphere" -> sphere(num(s, 5.0, "radius", "r"))
            "cone" -> cone(num(s, 5.0, "radius", "r"), num(s, 10.0, "height", "h", "z"))
            "torus" -> torus(num(s, 10.0, "major_radius", "radius"), num(s, 2.0, "minor_radius"))
            else -> throw IllegalArgumentException("Bilinmeyen şekil: '$shape' (box, cylinder, sphere, cone, torus)")
        }
    }

    private fun box(x: Double, y: Double, z: Double): Part {
        val a = x / 2; val b = y / 2; val c = z / 2
        val v = listOf(
            doubleArrayOf(-a, -b, -c), doubleArrayOf(a, -b, -c), doubleArrayOf(a, b, -c), doubleArrayOf(-a, b, -c),
            doubleArrayOf(-a, -b, c), doubleArrayOf(a, -b, c), doubleArrayOf(a, b, c), doubleArrayOf(-a, b, c)
        )
        val t = listOf(
            intArrayOf(0, 2, 1), intArrayOf(0, 3, 2),
            intArrayOf(4, 5, 6), intArrayOf(4, 6, 7),
            intArrayOf(0, 1, 5), intArrayOf(0, 5, 4),
            intArrayOf(2, 3, 7), intArrayOf(2, 7, 6),
            intArrayOf(3, 0, 4), intArrayOf(3, 4, 7),
            intArrayOf(1, 2, 6), intArrayOf(1, 6, 5)
        )
        val e = listOf(
            intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 0),
            intArrayOf(4, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 4),
            intArrayOf(0, 4), intArrayOf(1, 5), intArrayOf(2, 6), intArrayOf(3, 7)
        )
        return Part(v, t, e)
    }

    private fun cylinder(r: Double, h: Double): Part {
        val v = ArrayList<DoubleArray>()
        for (i in 0 until N) { val a = 2 * PI * i / N; v.add(doubleArrayOf(r * cos(a), r * sin(a), -h / 2)) }
        for (i in 0 until N) { val a = 2 * PI * i / N; v.add(doubleArrayOf(r * cos(a), r * sin(a), h / 2)) }
        v.add(doubleArrayOf(0.0, 0.0, -h / 2))
        v.add(doubleArrayOf(0.0, 0.0, h / 2))
        val cb = 2 * N
        val ct = 2 * N + 1
        val t = ArrayList<IntArray>()
        val e = ArrayList<IntArray>()
        for (i in 0 until N) {
            val j = (i + 1) % N
            t.add(intArrayOf(i, j, N + j)); t.add(intArrayOf(i, N + j, N + i))
            t.add(intArrayOf(cb, j, i)); t.add(intArrayOf(ct, N + i, N + j))
            e.add(intArrayOf(i, j)); e.add(intArrayOf(N + i, N + j))
            if (i % 4 == 0) e.add(intArrayOf(i, N + i))
        }
        return Part(v, t, e)
    }

    private fun cone(r: Double, h: Double): Part {
        val v = ArrayList<DoubleArray>()
        for (i in 0 until N) { val a = 2 * PI * i / N; v.add(doubleArrayOf(r * cos(a), r * sin(a), -h / 2)) }
        v.add(doubleArrayOf(0.0, 0.0, -h / 2))
        v.add(doubleArrayOf(0.0, 0.0, h / 2))
        val cb = N
        val apex = N + 1
        val t = ArrayList<IntArray>()
        val e = ArrayList<IntArray>()
        for (i in 0 until N) {
            val j = (i + 1) % N
            t.add(intArrayOf(i, j, apex)); t.add(intArrayOf(cb, j, i))
            e.add(intArrayOf(i, j))
            if (i % 4 == 0) e.add(intArrayOf(i, apex))
        }
        return Part(v, t, e)
    }

    private fun sphere(r: Double): Part {
        val st = 12
        val sl = 24
        val v = ArrayList<DoubleArray>()
        for (i in 0..st) {
            val phi = PI * i / st
            for (j in 0 until sl) {
                val th = 2 * PI * j / sl
                v.add(doubleArrayOf(r * sin(phi) * cos(th), r * sin(phi) * sin(th), r * cos(phi)))
            }
        }
        fun id(i: Int, j: Int) = i * sl + (j % sl)
        val t = ArrayList<IntArray>()
        val e = ArrayList<IntArray>()
        for (i in 0 until st) for (j in 0 until sl) {
            val a = id(i, j); val b = id(i, j + 1); val c = id(i + 1, j); val dd = id(i + 1, j + 1)
            t.add(intArrayOf(a, c, b)); t.add(intArrayOf(b, c, dd))
        }
        for (i in 1 until st) for (j in 0 until sl) e.add(intArrayOf(id(i, j), id(i, j + 1)))
        for (i in 0 until st) for (j in 0 until sl step 2) e.add(intArrayOf(id(i, j), id(i + 1, j)))
        return Part(v, t, e)
    }

    private fun torus(bigR: Double, smallR: Double): Part {
        val uu = 32
        val vv = 12
        val v = ArrayList<DoubleArray>()
        for (u in 0 until uu) {
            val au = 2 * PI * u / uu
            for (w in 0 until vv) {
                val aw = 2 * PI * w / vv
                val ring = bigR + smallR * cos(aw)
                v.add(doubleArrayOf(ring * cos(au), ring * sin(au), smallR * sin(aw)))
            }
        }
        fun id(u: Int, w: Int) = (u % uu) * vv + (w % vv)
        val t = ArrayList<IntArray>()
        val e = ArrayList<IntArray>()
        for (u in 0 until uu) for (w in 0 until vv) {
            val a = id(u, w); val b = id(u + 1, w); val c = id(u, w + 1); val dd = id(u + 1, w + 1)
            t.add(intArrayOf(a, b, c)); t.add(intArrayOf(b, dd, c))
        }
        for (u in 0 until uu step 2) for (w in 0 until vv) e.add(intArrayOf(id(u, w), id(u, w + 1)))
        for (u in 0 until uu) for (w in 0 until vv step 2) e.add(intArrayOf(id(u, w), id(u + 1, w)))
        return Part(v, t, e)
    }

    // ---------------- matematik ----------------

    private fun transform(
        v: DoubleArray, rx: Double, ry: Double, rz: Double,
        px: Double, py: Double, pz: Double
    ): DoubleArray {
        var x = v[0]; var y = v[1]; var z = v[2]
        // X ekseni
        var a = y * cos(rx) - z * sin(rx)
        var b = y * sin(rx) + z * cos(rx)
        y = a; z = b
        // Y ekseni
        a = x * cos(ry) + z * sin(ry)
        b = -x * sin(ry) + z * cos(ry)
        x = a; z = b
        // Z ekseni
        a = x * cos(rz) - y * sin(rz)
        b = x * sin(rz) + y * cos(rz)
        x = a; y = b
        return doubleArrayOf(x + px, y + py, z + pz)
    }

    private fun triple(p0: DoubleArray, p1: DoubleArray, p2: DoubleArray): Double =
        p0[0] * (p1[1] * p2[2] - p1[2] * p2[1]) -
            p0[1] * (p1[0] * p2[2] - p1[2] * p2[0]) +
            p0[2] * (p1[0] * p2[1] - p1[1] * p2[0])

    // ---------------- STL ----------------

    fun toStl(m: Mesh): ByteArray {
        val n = m.tris.size / 3
        val buf = ByteBuffer.allocate(84 + n * 50).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(80)
        buf.putInt(n)
        val vs = m.verts
        for (k in 0 until n) {
            val i0 = m.tris[k * 3] * 3
            val i1 = m.tris[k * 3 + 1] * 3
            val i2 = m.tris[k * 3 + 2] * 3
            val ux = vs[i1] - vs[i0]; val uy = vs[i1 + 1] - vs[i0 + 1]; val uz = vs[i1 + 2] - vs[i0 + 2]
            val wx = vs[i2] - vs[i0]; val wy = vs[i2 + 1] - vs[i0 + 1]; val wz = vs[i2 + 2] - vs[i0 + 2]
            var nx = uy * wz - uz * wy
            var ny = uz * wx - ux * wz
            var nz = ux * wy - uy * wx
            val len = sqrt(nx * nx + ny * ny + nz * nz)
            if (len > 0f) { nx /= len; ny /= len; nz /= len }
            buf.putFloat(nx); buf.putFloat(ny); buf.putFloat(nz)
            for (i in intArrayOf(i0, i1, i2)) {
                buf.putFloat(vs[i]); buf.putFloat(vs[i + 1]); buf.putFloat(vs[i + 2])
            }
            buf.putShort(0)
        }
        return buf.array()
    }

    /** STL'yi İndirilenler/A1 klasörüne kaydeder, yolu döndürür. */
    fun saveToDownloads(ctx: Context, m: Mesh, name: String): String {
        val fileName = safeName(name) + ".stl"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/A1")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Dosya oluşturulamadı.")
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(toStl(m)) }
            ?: throw IOException("Dosya yazılamadı.")
        return "İndirilenler/A1/$fileName"
    }
}
