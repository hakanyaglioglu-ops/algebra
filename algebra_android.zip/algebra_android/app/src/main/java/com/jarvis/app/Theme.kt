package com.jarvis.app

import android.graphics.Color

/** Renk teması: tek bir vurgu renginden tüm arayüz renkleri türetilir. */
class Theme(val id: String, val label: String, val accent: Int) {
    private fun mix(c: Int, k: Float) = Color.rgb(
        (Color.red(c) * k).toInt(), (Color.green(c) * k).toInt(), (Color.blue(c) * k).toInt()
    )

    private fun toWhite(c: Int, k: Float) = Color.rgb(
        Color.red(c) + ((255 - Color.red(c)) * k).toInt(),
        Color.green(c) + ((255 - Color.green(c)) * k).toInt(),
        Color.blue(c) + ((255 - Color.blue(c)) * k).toInt()
    )

    val bg: Int get() = mix(accent, 0.03f)
    val panel: Int get() = mix(accent, 0.10f)
    val text: Int get() = toWhite(accent, 0.45f)

    companion object {
        val all = listOf(
            Theme("fosfor", "Fosfor yeşil", Color.parseColor("#39FF14")),
            Theme("lacivert", "Lacivert", Color.parseColor("#3D5BFF")),
            Theme("mavi", "Mavi", Color.parseColor("#1E9BFF")),
            Theme("camgobegi", "Camgöbeği", Color.parseColor("#00E5FF")),
            Theme("kirmizi", "Kırmızı", Color.parseColor("#FF2A3D")),
            Theme("turuncu", "Turuncu", Color.parseColor("#FF8A00")),
            Theme("sari", "Sarı", Color.parseColor("#FFE600")),
            Theme("mor", "Mor", Color.parseColor("#B44CFF")),
            Theme("pembe", "Pembe", Color.parseColor("#FF3DA8")),
            Theme("beyaz", "Beyaz", Color.parseColor("#F2F2F2"))
        )

        fun byId(id: String): Theme = all.firstOrNull { it.id == id } ?: all[0]
    }
}
