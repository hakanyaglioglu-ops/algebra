package com.jarvis.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Algebra'nın telefondaki yetenekleri. Rastgele komut çalıştırma yoktur. */
class Skills(private val activity: Activity) {

    private fun ui(block: () -> Unit) {
        Handler(Looper.getMainLooper()).post {
            try {
                block()
            } catch (_: Exception) {
            }
        }
    }

    private fun norm(s: String) = s.lowercase(Locale("tr", "TR")).trim()

    fun run(name: String, a: JSONObject): String = try {
        when (name) {
            "open_app" -> openApp(a.getString("name"))
            "open_website" -> openWebsite(a.getString("url"))
            "web_search" -> webSearch(a.getString("query"))
            "system_control" -> systemControl(a.getString("action"), a.optInt("amount", 5))
            "set_timer" -> setTimer(a.getDouble("minutes"), a.optString("message", "ALGEBRA"))
            "set_alarm" -> setAlarm(a.getInt("hour"), a.optInt("minute", 0), a.optString("message", "ALGEBRA"))
            "get_time" -> SimpleDateFormat("d MMMM yyyy EEEE, HH:mm", Locale("tr", "TR")).format(Date())
            "get_weather" -> Http.get("https://wttr.in/${Uri.encode(a.getString("city"))}?format=3&lang=tr").trim()
            "dial_number" -> dial(a.getString("number"))
            "make_3d_model" -> make3d(a)
            "show_model" -> showModel()
            "save_model" -> saveModel()
            "inspect_for_print" -> inspect()
            else -> "Bilinmeyen araç: $name"
        }
    } catch (e: Exception) {
        "Hata: ${e.message}"
    }

    // ---------------- uygulama / web ----------------

    private fun openApp(name: String): String {
        val pm = activity.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val key = norm(name)
        fun label(i: android.content.pm.ResolveInfo) = norm(i.loadLabel(pm).toString())
        val match = apps.firstOrNull { label(it) == key }
            ?: apps.firstOrNull { label(it).contains(key) }
            ?: apps.firstOrNull { label(it).length >= 3 && key.contains(label(it)) }
            ?: return "Bulunamadı: '$name' adlı bir uygulama yüklü değil."
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Bulunamadı: '$name' açılamıyor."
        ui { activity.startActivity(launch) }
        return "${match.loadLabel(pm)} açılıyor."
    }

    private fun openWebsite(url: String): String {
        val u = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        ui { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        return "$u açılıyor."
    }

    private fun webSearch(q: String): String {
        ui {
            activity.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
            )
        }
        return "'$q' için arama açılıyor."
    }

    private fun dial(number: String): String {
        ui { activity.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))) }
        return "$number numarası arama ekranına yazıldı (aramak için siz onaylarsınız)."
    }

    // ---------------- sistem ----------------

    private fun systemControl(action: String, amount: Int): String {
        val am = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val steps = amount.coerceIn(1, 15)
        return when (action) {
            "volume_up" -> {
                for (i in 0 until steps) am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE,
                    if (i == 0) AudioManager.FLAG_SHOW_UI else 0
                )
                "Ses artırıldı."
            }
            "volume_down" -> {
                for (i in 0 until steps) am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER,
                    if (i == 0) AudioManager.FLAG_SHOW_UI else 0
                )
                "Ses azaltıldı."
            }
            "mute" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
                "Ses açıldı/kapatıldı."
            }
            "play_pause" -> {
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
                "Oynat/duraklat gönderildi."
            }
            "flashlight_on" -> torch(true)
            "flashlight_off" -> torch(false)
            else -> "Bilinmeyen sistem eylemi: $action"
        }
    }

    private fun torch(on: Boolean): String {
        val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Bu cihazda fener yok."
        cm.setTorchMode(id, on)
        return if (on) "Fener açıldı." else "Fener kapatıldı."
    }

    private fun setTimer(minutes: Double, msg: String): String {
        val seconds = (minutes * 60).toInt().coerceIn(1, 86400)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, msg)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        ui { activity.startActivity(i) }
        return "Sayaç kuruldu: %.1f dakika, '%s'.".format(Locale.US, seconds / 60.0, msg)
    }

    private fun setAlarm(hour: Int, minute: Int, msg: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_MESSAGE, msg)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        ui { activity.startActivity(i) }
        return "Alarm kuruldu: %02d:%02d.".format(hour, minute)
    }

    // ---------------- 3D ----------------

    private fun make3d(a: JSONObject): String {
        val name = a.optString("name", "model")
        val p = a.opt("parts") ?: return "Hata: 'parts' eksik."
        val arr = if (p is JSONArray) p else JSONArray(p.toString())
        val mesh = Cad.build(arr)
        ModelStore.mesh = mesh
        ModelStore.name = Cad.safeName(name)
        ui { activity.startActivity(Intent(activity, ViewerActivity::class.java)) }
        val e = mesh.extents()
        return "Model oluşturuldu (%d parça, %.0f x %.0f x %.0f mm) ve ekranda gösteriliyor.".format(
            arr.length(), e[0], e[1], e[2]
        )
    }

    private fun showModel(): String {
        if (ModelStore.mesh == null) return "Henüz bir model yok. Önce bir model tasarlamam gerekiyor."
        ui { activity.startActivity(Intent(activity, ViewerActivity::class.java)) }
        return "Model ekranda."
    }

    private fun saveModel(): String {
        val m = ModelStore.mesh ?: return "Kaydedilecek model yok."
        return "Kaydedildi: " + Cad.saveToDownloads(activity, m, ModelStore.name)
    }

    private fun inspect(): String {
        val m = ModelStore.mesh ?: return "İncelenecek model yok."
        val e = m.extents()
        val cm3 = m.volumeMm3 / 1000.0
        return "Boyut: %.1f x %.1f x %.1f mm. Parça hacimleri toplamı: %.1f cm³ (üst üste binen parçalar iki kez sayılır, dolu baskıda yaklaşık %.0f g PLA). STL dosyasını Cura veya PrusaSlicer ile dilimleyebilirsiniz; parçalar birleştirilmediği için dilimleyicide kontrol edin.".format(
            e[0], e[1], e[2], cm3, cm3 * 1.24
        )
    }

    // ---------------- araç tanımları ----------------

    private fun s(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun n(desc: String) = JSONObject().put("type", "number").put("description", desc)
    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc).put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req))
        )

    private val shapeDoc =
        "Her parça: shape (box|cylinder|sphere|cone|torus), size (box: x,y,z; cylinder ve cone: radius,height; " +
            "sphere: radius; torus: major_radius,minor_radius), position [x,y,z] mm, rotation_deg [rx,ry,rz]. Z yukarıdır."

    val tools: List<JSONObject> = listOf(
        tool("open_app", "Telefonda yüklü bir uygulamayı adıyla açar (YouTube, Kamera, WhatsApp...).",
            JSONObject().put("name", s("Uygulama adı")), listOf("name")),
        tool("open_website", "Tarayıcıda bir web sitesi açar.",
            JSONObject().put("url", s("Adres")), listOf("url")),
        tool("web_search", "Google araması açar.",
            JSONObject().put("query", s("Arama metni")), listOf("query")),
        tool("system_control", "Sistem kontrolü: volume_up, volume_down, mute, play_pause, flashlight_on, flashlight_off.",
            JSONObject().put("action", s("Eylem")).put("amount", n("Ses adımı (varsayılan 5)")), listOf("action")),
        tool("set_timer", "Belirtilen dakika sonra çalan sayaç kurar (hatırlatıcı olarak da kullanılır).",
            JSONObject().put("minutes", n("Dakika")).put("message", s("Hatırlatma metni")), listOf("minutes")),
        tool("set_alarm", "Belirli saate alarm kurar.",
            JSONObject().put("hour", n("Saat 0-23")).put("minute", n("Dakika 0-59")).put("message", s("Etiket")), listOf("hour")),
        tool("get_time", "Tarih ve saati verir."),
        tool("get_weather", "Bir şehrin hava durumunu verir.",
            JSONObject().put("city", s("Şehir")), listOf("city")),
        tool("dial_number", "Telefon numarasını arama ekranına yazar (aramayı kullanıcı onaylar).",
            JSONObject().put("number", s("Numara")), listOf("number")),
        tool("make_3d_model",
            "Basit şekilleri birleştirerek 3D model üretir ve ekranda gösterir (robot, kol, kutu, taşıyıcı...). Ölçüler mm. $shapeDoc",
            JSONObject()
                .put("name", s("Dosya adı"))
                .put("parts", JSONObject().put("type", "array").put("items",
                    JSONObject().put("type", "object").put("properties",
                        JSONObject()
                            .put("shape", s("box|cylinder|sphere|cone|torus"))
                            .put("size", JSONObject().put("type", "object"))
                            .put("position", JSONObject().put("type", "array").put("items", JSONObject().put("type", "number")))
                            .put("rotation_deg", JSONObject().put("type", "array").put("items", JSONObject().put("type", "number")))
                    ).put("required", JSONArray(listOf("shape", "size"))))),
            listOf("name", "parts")),
        tool("show_model", "Son üretilen 3D modeli holografik görüntüleyicide gösterir (dokunarak döndürülür, taşınır, büyütülür)."),
        tool("save_model", "Son modeli STL olarak İndirilenler/ALGEBRA klasörüne kaydeder (3D yazıcı için)."),
        tool("inspect_for_print", "Son modelin boyutunu, hacmini ve baskı notlarını verir.")
    )

    val toolSchemas: JSONArray get() = JSONArray(tools)

    /** Araç çağrısı desteklemeyen yapay zekalar için metin biçiminde araç listesi. */
    fun textDoc(): String = tools.joinToString("\n") { t ->
        val props = t.getJSONObject("input_schema").getJSONObject("properties")
        val names = props.keys().asSequence().joinToString(", ")
        "- ${t.getString("name")}($names): ${t.getString("description")}"
    }
}
