package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Providers {
    const val POLLINATIONS = "pollinations"
    const val CLAUDE = "claude"
    const val OPENAI = "openai"
    const val OFFLINE = "offline"

    val ids = listOf(POLLINATIONS, CLAUDE, OPENAI, OFFLINE)
    val labels = listOf(
        "Pollinations (anahtarsız, ücretsiz)",
        "Claude (Anthropic)",
        "OpenAI uyumlu (Gemini, Groq, OpenRouter, Ollama...)",
        "Yapay zekasız (yerel komutlar)"
    )

    fun defaultUrl(p: String) = when (p) {
        POLLINATIONS -> "https://text.pollinations.ai/openai"
        CLAUDE -> "https://api.anthropic.com/v1/messages"
        OPENAI -> "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
        else -> ""
    }

    fun defaultModel(p: String) = when (p) {
        POLLINATIONS -> "openai"
        CLAUDE -> "claude-sonnet-5-5"
        OPENAI -> "gemini-2.5-flash"
        else -> ""
    }

    fun hint(p: String) = when (p) {
        POLLINATIONS -> "Anahtar gerekmez. Ücretsiz ve kararsız olabilir; gizli bilgi yazmayın. Çalışmazsa başka bir seçenek deneyin."
        CLAUDE -> "console.anthropic.com adresinden aldığınız API anahtarını girin (kullandıkça ücretlenir)."
        OPENAI -> "Adres, sohbet (chat/completions) uç noktasının tamamı olmalı. Varsayılan Google Gemini içindir (aistudio.google.com'dan ücretsiz anahtar). Groq, OpenRouter, Ollama gibi OpenAI uyumlu hizmetlerin adresini ve model adını da yazabilirsiniz."
        else -> "Yapay zeka kullanılmaz; sadece kalıp komutlar çalışır (uygulama aç, sesi kıs, sayaç kur, küp yap...). İnternet gerekmez."
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var provider: String
        get() = p.getString("provider", Providers.POLLINATIONS) ?: Providers.POLLINATIONS
        set(v) { p.edit().putString("provider", v).apply() }

    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) { p.edit().putBoolean("speak", v).apply() }

    fun key(pr: String) = p.getString("key_$pr", "") ?: ""
    fun model(pr: String) = p.getString("model_$pr", Providers.defaultModel(pr)) ?: Providers.defaultModel(pr)
    fun url(pr: String) = p.getString("url_$pr", Providers.defaultUrl(pr)) ?: Providers.defaultUrl(pr)

    fun save(pr: String, key: String, model: String, url: String) {
        p.edit()
            .putString("key_$pr", key.trim())
            .putString("model_$pr", model.trim().ifEmpty { Providers.defaultModel(pr) })
            .putString("url_$pr", url.trim().ifEmpty { Providers.defaultUrl(pr) })
            .apply()
    }
}

class Brain(private val settings: Settings, private val skills: Skills) {

    private val claudeMsgs = ArrayList<JSONObject>()
    private val chatMsgs = ArrayList<JSONObject>()

    fun reset() { claudeMsgs.clear(); chatMsgs.clear() }

    fun ask(text: String): String = when (settings.provider) {
        Providers.CLAUDE -> askClaude(text)
        Providers.OFFLINE -> LocalCommands.handle(text, skills)
        else -> askChat(text)
    }

    private fun trim(list: ArrayList<JSONObject>) {
        while (list.size > 40) list.removeAt(0)
        while (list.isNotEmpty() && !(list[0].getString("role") == "user" && list[0].get("content") is String)) {
            list.removeAt(0)
        }
    }

    private val baseRules = """
        Sen A1'sin: kullanıcının Android telefonunda çalışan, zeki, nazik ve hafif esprili bir yapay zeka asistanısın.
        Kullanıcı hangi dilde yazıyorsa o dilde cevap ver (varsayılan Türkçe). Gerekirse "efendim" diyebilirsin.
        Cevapların KISA olsun (genelde 1-3 cümle), çünkü sesli okunacaklar. Markdown, madde işareti ve emoji kullanma.
        3D model istenirse make_3d_model ile basit şekillerden (kutu, silindir, küre, koni, halka) parçalar kurarak tasarla;
        ölçüler milimetredir, gerçekçi oranlar kullan, robot ve kol gibi nesneleri parça parça oluştur.
        Bilmediğin bir şeyi uydurma.
    """.trimIndent()

    // ---------------- Claude (yerel araç çağrısı) ----------------

    private fun askClaude(text: String): String {
        val key = settings.key(Providers.CLAUDE)
        if (key.isBlank()) return "Ayarlar'dan Claude API anahtarınızı girin."
        trim(claudeMsgs)
        claudeMsgs.add(JSONObject().put("role", "user").put("content", text))

        repeat(10) {
            val body = JSONObject()
                .put("model", settings.model(Providers.CLAUDE))
                .put("max_tokens", 1500)
                .put("system", baseRules)
                .put("tools", skills.toolSchemas)
                .put("messages", JSONArray(claudeMsgs))
            val raw = Http.post(
                settings.url(Providers.CLAUDE),
                mapOf(
                    "x-api-key" to key,
                    "anthropic-version" to "2023-06-01",
                    "content-type" to "application/json"
                ),
                body.toString()
            )
            val resp = JSONObject(raw)
            val content = resp.getJSONArray("content")
            claudeMsgs.add(JSONObject().put("role", "assistant").put("content", content))

            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().trim().ifEmpty { "Tamamdır." }
            }
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") == "tool_use") {
                    val out = skills.run(b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                    results.put(
                        JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id"))
                            .put("content", out)
                    )
                }
            }
            claudeMsgs.add(JSONObject().put("role", "user").put("content", results))
        }
        return "Bu işlem beklediğimden uzun sürdü, tekrar dener misiniz?"
    }

    // ---------------- OpenAI uyumlu (metin tabanlı araç protokolü) ----------------

    private fun chatSystem(): String = baseRules + "\n\n" + """
        ARAÇLAR (telefonda işlem yapmak için):
    """.trimIndent() + "\n" + skills.textDoc() + "\n\n" + """
        Bir araç çalıştırmak için cevabına, her araç için ayrı bir satıra, tek satırlık geçerli JSON olarak şunu yaz:
        @@ARAC {"name":"open_app","args":{"name":"YouTube"}}
        3D model örneği:
        @@ARAC {"name":"make_3d_model","args":{"name":"kule","parts":[{"shape":"box","size":{"x":40,"y":40,"z":10}},{"shape":"cylinder","size":{"radius":6,"height":50},"position":[0,0,30]}]}}
        Sonuçlar sana "ARAÇ SONUÇLARI" olarak geri gelir; sonra kullanıcıya kısa cevap ver.
        Araç gerekmiyorsa doğrudan cevap ver ve @@ARAC yazma.
    """.trimIndent()

    private fun askChat(text: String): String {
        val pr = settings.provider
        val key = settings.key(pr)
        if (pr == Providers.OPENAI && key.isBlank()) return "Ayarlar'dan API anahtarınızı girin."
        trim(chatMsgs)
        chatMsgs.add(JSONObject().put("role", "user").put("content", text))

        repeat(6) {
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content", chatSystem()))
            for (m in chatMsgs) msgs.put(m)
            val body = JSONObject().put("model", settings.model(pr)).put("messages", msgs)
            val headers = HashMap<String, String>()
            headers["Content-Type"] = "application/json"
            if (key.isNotBlank()) headers["Authorization"] = "Bearer $key"

            val raw = Http.post(settings.url(pr), headers, body.toString())
            val resp = JSONObject(raw)
            val reply = resp.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            chatMsgs.add(JSONObject().put("role", "assistant").put("content", reply))

            val lines = reply.lines()
            val calls = lines.filter { it.trim().startsWith("@@ARAC") }
            val visible = lines.filterNot { it.trim().startsWith("@@ARAC") }.joinToString("\n").trim()
            if (calls.isEmpty()) return visible.ifEmpty { "Tamamdır." }

            val sb = StringBuilder("ARAÇ SONUÇLARI:\n")
            for (c in calls) {
                try {
                    val j = JSONObject(c.trim().removePrefix("@@ARAC").trim())
                    val name = j.getString("name")
                    sb.append("- $name: ").append(skills.run(name, j.optJSONObject("args") ?: JSONObject())).append("\n")
                } catch (e: Exception) {
                    sb.append("- geçersiz çağrı: ${e.message}\n")
                }
            }
            sb.append("Bunlara göre kullanıcıya kısa bir cevap ver.")
            chatMsgs.add(JSONObject().put("role", "user").put("content", sb.toString()))
        }
        return "Bu işlem beklediğimden uzun sürdü, tekrar dener misiniz?"
    }
}
