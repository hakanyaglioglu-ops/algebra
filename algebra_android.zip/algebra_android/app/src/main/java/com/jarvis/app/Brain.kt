package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Providers {
    const val ONDEVICE = "ondevice"
    const val POLLINATIONS = "pollinations"
    const val CLAUDE = "claude"
    const val CHATGPT = "chatgpt"
    const val GEMINI = "gemini"
    const val DEEPSEEK = "deepseek"
    const val OPENAI = "openai"   // diğer OpenAI uyumlu hizmetler (Groq, OpenRouter, Ollama...)
    const val OFFLINE = "offline"

    val ids = listOf(ONDEVICE, POLLINATIONS, CLAUDE, CHATGPT, GEMINI, DEEPSEEK, OPENAI, OFFLINE)
    val labels = listOf(
        "Kendi yapay zekam (telefonda, varsayılan)",
        "Pollinations (anahtarsız, ücretsiz)",
        "Claude AI (Anthropic)",
        "ChatGPT (OpenAI)",
        "Gemini (Google)",
        "DeepSeek",
        "Diğer OpenAI uyumlu (Groq, OpenRouter, Ollama...)",
        "Yapay zekasız (yerel komutlar)"
    )

    /** Sohbet (chat/completions) uç noktası kullanan sağlayıcılar. */
    val COMPAT = setOf(POLLINATIONS, OPENAI, CHATGPT, GEMINI, DEEPSEEK)

    /** API anahtarı gerektirenler. */
    fun needsKey(p: String) = p == CLAUDE || p == CHATGPT || p == GEMINI || p == DEEPSEEK || p == OPENAI

    fun label(p: String) = labels[ids.indexOf(p).coerceAtLeast(0)]

    fun defaultUrl(p: String) = when (p) {
        POLLINATIONS -> "https://text.pollinations.ai/openai"
        CLAUDE -> "https://api.anthropic.com/v1/messages"
        CHATGPT -> "https://api.openai.com/v1/chat/completions"
        GEMINI, OPENAI -> "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
        DEEPSEEK -> "https://api.deepseek.com/chat/completions"
        else -> ""
    }

    fun defaultModel(p: String) = when (p) {
        POLLINATIONS -> "openai"
        CLAUDE -> "claude-sonnet-5-5"
        CHATGPT -> "gpt-4o-mini"
        GEMINI, OPENAI -> "gemini-2.5-flash"
        DEEPSEEK -> "deepseek-chat"
        else -> ""
    }

    fun hint(p: String) = when (p) {
        ONDEVICE -> "Telefonun kendi işlemcisiyle çalışır, internet gerekmez. Model dosyası (.litertlm) yüklü değilse A1 geçici olarak ücretsiz Pollinations'ı kullanır. Aşağıdan modeli indirebilir veya dosyadan seçebilirsiniz."
        POLLINATIONS -> "Anahtar gerekmez. Ücretsiz ve kararsız olabilir; gizli bilgi yazmayın."
        CLAUDE -> "console.anthropic.com adresinden aldığınız API anahtarını girin (kullandıkça ücretlenir)."
        CHATGPT -> "platform.openai.com adresinden aldığınız API anahtarını girin (kullandıkça ücretlenir)."
        GEMINI -> "aistudio.google.com adresinden ücretsiz API anahtarı alabilirsiniz."
        DEEPSEEK -> "platform.deepseek.com adresinden aldığınız API anahtarını girin."
        OPENAI -> "Adres, sohbet (chat/completions) uç noktasının tamamı olmalı; model adını da yazın."
        else -> "Yapay zeka kullanılmaz; sadece kalıp komutlar çalışır. İnternet gerekmez."
    }
}

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var provider: String
        get() = p.getString("provider", Providers.ONDEVICE) ?: Providers.ONDEVICE
        set(v) { p.edit().putString("provider", v).apply() }

    // renkler (ARGB)
    var textColor: Int
        get() = p.getInt("textColor", 0xFFFFFFFF.toInt())
        set(v) { p.edit().putInt("textColor", v).apply() }
    var ringColor: Int
        get() = p.getInt("ringColor", 0xFF3CC8F0.toInt())
        set(v) { p.edit().putInt("ringColor", v).apply() }
    var bgColor: Int
        get() = p.getInt("bgColor", 0xFF000000.toInt())
        set(v) { p.edit().putInt("bgColor", v).apply() }

    // ses
    var pitch: Float
        get() = p.getFloat("pitch", 0.85f)
        set(v) { p.edit().putFloat("pitch", v).apply() }
    var rate: Float
        get() = p.getFloat("rate", 0.95f)
        set(v) { p.edit().putFloat("rate", v).apply() }
    /** "auto", "tr" veya "en" */
    var lang: String
        get() = p.getString("lang", "auto") ?: "auto"
        set(v) { p.edit().putString("lang", v).apply() }
    var voiceTr: String
        get() = p.getString("voiceTr", "") ?: ""
        set(v) { p.edit().putString("voiceTr", v).apply() }
    var voiceEn: String
        get() = p.getString("voiceEn", "") ?: ""
        set(v) { p.edit().putString("voiceEn", v).apply() }
    var modelUrl: String
        get() = p.getString("modelUrl", "") ?: ""
        set(v) { p.edit().putString("modelUrl", v.trim()).apply() }
    var hfToken: String
        get() = p.getString("hfToken", "") ?: ""
        set(v) { p.edit().putString("hfToken", v.trim()).apply() }

    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) { p.edit().putBoolean("speak", v).apply() }

    /** Konuşmalardan otomatik çıkarım ve yorum üretip kütüphaneye yaz. */
    var autoLearn: Boolean
        get() = p.getBoolean("autoLearn", true)
        set(v) { p.edit().putBoolean("autoLearn", v).apply() }

    fun key(pr: String) = p.getString("key_$pr", "") ?: ""
    fun model(pr: String) = p.getString("model_$pr", Providers.defaultModel(pr)) ?: Providers.defaultModel(pr)
    fun url(pr: String) = p.getString("url_$pr", Providers.defaultUrl(pr)) ?: Providers.defaultUrl(pr)

    fun save(pr: String, key: String, model: String, url: String) {
        p.edit()
            .putString("key_$pr", key.trim())
            .putString("model_$pr", model.trim().ifEmpty { Providers.defaultModel(pr) })
            .putString("url_$pr", url.trim().ifEmpty { Providers.defaultUrl(pr) })
            .apply()
    }
}

class Brain(private val settings: Settings, private val skills: Skills, ctx: Context) {

    private val claudeMsgs = ArrayList<JSONObject>()
    private val chatMsgs = ArrayList<JSONObject>()
    private val onDevice = OnDeviceLlm(ctx)
    private var examples = ""

    /** Arka planda çalışırken (kendi kendine çalışma) durum mesajı göndermek için. */
    var onStatus: ((String) -> Unit)? = null

    private val project = ProjectBuilder(ctx, skills.library, { s, u -> complete(s, u) }, { onStatus?.invoke(it) })
    private val learner = Learner(ctx, skills.library, { s, u -> complete(s, u) }, { onStatus?.invoke(it) })

    /** Seçili sağlayıcı "kendi yapay zekam" ama model dosyası yoksa geçici olarak Pollinations. */
    fun effectiveProvider(): String =
        if (settings.provider == Providers.ONDEVICE && !onDevice.modelFile().exists()) Providers.POLLINATIONS
        else settings.provider

    fun reset() { claudeMsgs.clear(); chatMsgs.clear(); onDevice.resetConversation() }

    /** Yeni model dosyası kopyalandığında motoru kapatır; bir sonraki soruda yeniden yüklenir. */
    fun resetOnDevice() { onDevice.closeAll() }

    private val recent = ArrayList<Pair<String, String>>()
    private var sinceReflect = 0

    fun ask(text: String): String {
        val low = text.lowercase(java.util.Locale("tr", "TR")).trim()
        skills.panels.command(low)?.let { return it }
        project.command(low, text)?.let { return it }
        learner.command(low)?.let { return it }
        // "çıkarım yap": son konuşmadan kalıcı bir çıkarım ve yorum üretip kütüphaneye yaz
        if (Regex("^(?:bunlardan\\s+|bundan\\s+)?çıkarım\\s+yap").containsMatchIn(low)) {
            return try {
                reflect()
            } catch (e: Exception) {
                "Çıkarım yapamadım: ${e.message}"
            }
        }
        val answer = route(text)
        note(text, answer)
        return answer
    }

    private fun route(text: String): String = try {
        when (settings.provider) {
            Providers.CLAUDE -> askClaude(text)
            Providers.ONDEVICE ->
                if (onDevice.modelFile().exists()) onDevice.reply(text, skills)
                else (LocalCommands.tryHandle(text, skills) ?: askChat(text, Providers.POLLINATIONS))
            Providers.OFFLINE -> LocalCommands.handle(text, skills)
            else -> askChat(text, settings.provider)
        }
    } catch (e: java.io.IOException) {
        if (e.message?.contains("FREE_LIMIT") == true) {
            "Ücretsiz sınır doldu (yaklaşık 45 saniyede 1 cevap). Biraz bekleyip tekrar deneyin veya Ayarlar'dan başka bir yapay zeka seçin."
        } else {
            throw e
        }
    }

    // ---------------- öğrenme: çıkarım ve yorum ----------------

    /** Tasarım örnekleri + kütüphane notları: modele eklenen bağlam. */
    private fun extra(text: String): String =
        skills.memory.examplesFor(text) +
            skills.library.contextFor(text).let { if (it.isEmpty()) "" else "\n\n$it" }

    private fun note(q: String, a: String) {
        if (q.isBlank() || a.isBlank()) return
        synchronized(recent) {
            recent.add(q to a)
            while (recent.size > 6) recent.removeAt(0)
        }
        sinceReflect++
        // Pollinations'ta ücretsiz sınır yüzünden, yerel modelde işlemci yükü yüzünden otomatik yapılmaz
        val auto = settings.autoLearn &&
            Providers.needsKey(settings.provider)
        if (auto && sinceReflect >= 5) {
            sinceReflect = 0
            Thread {
                try {
                    reflect()
                } catch (_: Exception) {
                }
            }.start()
        }
    }

    private val reflectSystem = """
        Sen A1'in iç sesisin. Aşağıdaki konuşmadan, ileride işe yarayacak KALICI bir çıkarım
        (kullanıcının tercihi, bilgisi, alışkanlığı veya konuyla ilgili öğrenilen bir gerçek) ve buna kısa bir yorum yaz.
        Sohbet muhabbeti, selam, tek seferlik istek veya genel laf kalıcı değildir; bunlar için ikisine de "yok" yaz.
        Konuşmada kalıcı bir şey yoksa ikisine de "yok" yaz. Yalnızca şu üç satırı yaz:
        ÇIKARIM: tek cümle
        YORUM: tek cümle
        ETİKET: en fazla 4 kelime, virgülle ayrılmış
    """.trimIndent()

    private fun reflect(): String {
        val snap = synchronized(recent) { ArrayList(recent) }
        if (snap.isEmpty()) return "Henüz konuşmadık, çıkaracak bir şey yok."
        val convo = snap.joinToString("\n") { "Kullanıcı: ${it.first}\nA1: ${it.second}" }
        return storeReflection(complete(reflectSystem, convo))
    }

    private fun storeReflection(out: String): String {
        val loc = java.util.Locale("tr", "TR")
        var cik = ""
        var yor = ""
        var tag = ""
        for (line in out.lines()) {
            val l = line.trim()
            val u = l.uppercase(loc)
            when {
                u.startsWith("ÇIKARIM:") || u.startsWith("CIKARIM:") -> cik = l.substringAfter(":").trim()
                u.startsWith("YORUM:") -> yor = l.substringAfter(":").trim()
                u.startsWith("ETİKET:") || u.startsWith("ETIKET:") -> tag = l.substringAfter(":").trim()
            }
        }
        fun empty(s: String) = s.isBlank() || s.lowercase(loc).trim('.', ' ') == "yok"
        val tags = tag.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val src = settings.provider
        val sb = StringBuilder()
        // boş bilgiyle kütüphane dolmasın: çok kısa notlar kabul edilmez, yorum yalnızca çıkarımla birlikte kaydedilir
        fun solid(s: String) = !empty(s) && s.trim().split(Regex("\\s+")).size >= 6
        if (solid(cik) && skills.library.add("çıkarım", cik, tags, src)) {
            sb.append("Çıkarım: $cik\n")
            if (solid(yor) && skills.library.add("yorum", yor, tags, src)) sb.append("Yorum: $yor\n")
        }
        return if (sb.isEmpty()) {
            "Kaydedilecek yeni bir şey çıkaramadım."
        } else {
            "Öğrendim ve kütüphaneme ekledim.\n$sb".trim()
        }
    }

    /** Araçsız, tek seferlik model isteği (çıkarım için). */
    fun complete(system: String, user: String): String {
        val pr = effectiveProvider()
        return when (pr) {
            Providers.CLAUDE -> {
                val key = settings.key(pr)
                if (key.isBlank()) throw java.io.IOException("Claude anahtarı yok.")
                val body = JSONObject().put("model", settings.model(pr)).put("max_tokens", 300).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
                val raw = Http.post(
                    settings.url(pr),
                    mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01", "content-type" to "application/json"),
                    body.toString()
                )
                val c = JSONObject(raw).getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until c.length()) {
                    val b = c.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                sb.toString()
            }
            in Providers.COMPAT -> {
                val key = settings.key(pr)
                val msgs = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
                val body = JSONObject().put("model", settings.model(pr)).put("messages", msgs)
                val headers = HashMap<String, String>()
                headers["Content-Type"] = "application/json"
                if (key.isNotBlank()) headers["Authorization"] = "Bearer $key"
                val raw = postWithRetry(settings.url(pr), headers, body.toString())
                JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "")
            }
            Providers.ONDEVICE -> onDevice.oneShot(system + "\n\n" + user)
            else -> throw java.io.IOException("Çıkarım için bir yapay zeka gerekir; Ayarlar'dan seçin.")
        }
    }

    private fun trim(list: ArrayList<JSONObject>) {
        while (list.size > 40) list.removeAt(0)
        while (list.isNotEmpty() && !(list[0].getString("role") == "user" && list[0].get("content") is String)) {
            list.removeAt(0)
        }
    }

    private val baseRules = """
        Sen A1'sin: kullanıcının Android telefonunda çalışan, zeki, nazik ve hafif esprili bir yapay zeka asistanısın.
        Kullanıcı hangi dilde yazıyorsa o dilde cevap ver (varsayılan Türkçe). Gerekirse "efendim" diyebilirsin.
        Cevapların KISA olsun (genelde 1-3 cümle), çünkü sesli okunacaklar. Markdown, madde işareti ve emoji kullanma.
        3D model istenirse make_3d_model ile basit şekillerden (kutu, silindir, küre, koni, halka) parçalar kurarak tasarla;
        ölçüler milimetredir, gerçekçi oranlar kullan, robot ve kol gibi nesneleri parça parça oluştur.
        Robot, robot kol, tekerlekli araç, tutucu, drone ve dişli için önce hazır şablon aracını (make_design) kullan.
        Kullanıcı bir tasarımı beğendiğini söylerse save_design ile kaydet; sonraki benzer isteklerde kayıtlı örnekleri kullan.
        Bilmediğin bir şeyi uydurma.
        Kullanıcı internetten bir şey öğrenmeni isterse "internete erişemiyorum" deme: ona "araştır <konu>" demesini söyle, bu komut Vikipedi'yi okuyup öğrenir.
    """.trimIndent()

    // ---------------- Claude (yerel araç çağrısı) ----------------

    private fun askClaude(text: String): String {
        val key = settings.key(Providers.CLAUDE)
        if (key.isBlank()) return "Ayarlar'dan Claude API anahtarınızı girin."
        trim(claudeMsgs)
        examples = extra(text)
        claudeMsgs.add(JSONObject().put("role", "user").put("content", text))

        repeat(10) {
            val body = JSONObject()
                .put("model", settings.model(Providers.CLAUDE))
                .put("max_tokens", 1500)
                .put("system", baseRules + examples)
                .put("tools", skills.toolSchemas)
                .put("messages", JSONArray(claudeMsgs))
            val raw = Http.post(
                settings.url(Providers.CLAUDE),
                mapOf(
                    "x-api-key" to key,
                    "anthropic-version" to "2023-06-01",
                    "content-type" to "application/json"
                ),
                body.toString()
            )
            val resp = JSONObject(raw)
            val content = resp.getJSONArray("content")
            claudeMsgs.add(JSONObject().put("role", "assistant").put("content", content))

            if (resp.optString("stop_reason") != "tool_use") {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                return sb.toString().trim().ifEmpty { "Tamamdır." }
            }
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") == "tool_use") {
                    val out = skills.run(b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                    results.put(
                        JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id"))
                            .put("content", out)
                    )
                }
            }
            claudeMsgs.add(JSONObject().put("role", "user").put("content", results))
        }
        return "Bu işlem beklediğimden uzun sürdü, tekrar dener misiniz?"
    }

    // ---------------- OpenAI uyumlu (metin tabanlı araç protokolü) ----------------

    /** Ücretsiz sınıra ("Retry after Ns") takılırsa bir kez bekleyip yeniden dener. */
    private fun postWithRetry(url: String, headers: Map<String, String>, body: String): String {
        try {
            return Http.post(url, headers, body)
        } catch (e: java.io.IOException) {
            val msg = e.message ?: ""
            val wait = Regex("Retry after (\\d+)s").find(msg)?.groupValues?.get(1)?.toLongOrNull()
            if (msg.startsWith("HTTP 402") && wait != null && wait in 1..60) {
                Thread.sleep((wait + 1) * 1000)
                return Http.post(url, headers, body)
            }
            throw e
        }
    }

    private fun chatSystem(): String = baseRules + examples + "\n\n" + """
        ARAÇLAR (telefonda işlem yapmak için):
    """.trimIndent() + "\n" + skills.textDoc() + "\n\n" + """
        Bir araç çalıştırmak için cevabına, her araç için ayrı bir satıra, tek satırlık geçerli JSON olarak şunu yaz:
        @@ARAC {"name":"open_app","args":{"name":"YouTube"}}
        3D model örneği:
        @@ARAC {"name":"make_3d_model","args":{"name":"kule","parts":[{"shape":"box","size":{"x":40,"y":40,"z":10}},{"shape":"cylinder","size":{"radius":6,"height":50},"position":[0,0,30]}]}}
        Sonuçlar sana "ARAÇ SONUÇLARI" olarak geri gelir; sonra kullanıcıya kısa cevap ver.
        Araç gerekmiyorsa doğrudan cevap ver ve @@ARAC yazma.
    """.trimIndent()

    private fun askChat(text: String, pr: String): String {
        val key = settings.key(pr)
        if (Providers.needsKey(pr) && key.isBlank()) return "Ayarlar'dan API anahtarınızı girin."
        trim(chatMsgs)
        examples = extra(text)
        chatMsgs.add(JSONObject().put("role", "user").put("content", text))

        repeat(6) {
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content", chatSystem()))
            for (m in chatMsgs) msgs.put(m)
            val body = JSONObject().put("model", settings.model(pr)).put("messages", msgs)
            val headers = HashMap<String, String>()
            headers["Content-Type"] = "application/json"
            if (key.isNotBlank()) headers["Authorization"] = "Bearer $key"

            val raw = postWithRetry(settings.url(pr), headers, body.toString())
            val resp = JSONObject(raw)
            val reply = resp.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            chatMsgs.add(JSONObject().put("role", "assistant").put("content", reply))

            val lines = reply.lines()
            val calls = lines.filter { it.trim().startsWith("@@ARAC") }
            val visible = lines.filterNot { it.trim().startsWith("@@ARAC") }.joinToString("\n").trim()
            if (calls.isEmpty()) return visible.ifEmpty { "Tamamdır." }

            val sb = StringBuilder("ARAÇ SONUÇLARI:\n")
            for (c in calls) {
                try {
                    val j = JSONObject(c.trim().removePrefix("@@ARAC").trim())
                    val name = j.getString("name")
                    sb.append("- $name: ").append(skills.run(name, j.optJSONObject("args") ?: JSONObject())).append("\n")
                } catch (e: Exception) {
                    sb.append("- geçersiz çağrı: ${e.message}\n")
                }
            }
            if (pr == Providers.POLLINATIONS) {
                // Ücretsiz sınır (45 sn'de 1 cevap) yüzünden ikinci model çağrısı yapma, sonucu doğrudan söyle
                val outs = sb.toString().removePrefix("ARAÇ SONUÇLARI:\n").trim()
                return (visible + "\n" + outs).trim()
            }
            sb.append("Bunlara göre kullanıcıya kısa bir cevap ver.")
            chatMsgs.add(JSONObject().put("role", "user").put("content", sb.toString()))
        }
        return "Bu işlem beklediğimden uzun sürdü, tekrar dener misiniz?"
    }
}
