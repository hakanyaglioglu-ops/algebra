package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Yapay zeka olmadan çalışan kalıp komutlar (Türkçe). */
object LocalCommands {

    private val sites = mapOf(
        "youtube" to "youtube.com", "google" to "google.com", "instagram" to "instagram.com",
        "facebook" to "facebook.com", "twitter" to "x.com", "x" to "x.com", "github" to "github.com",
        "netflix" to "netflix.com", "gmail" to "mail.google.com", "harita" to "maps.google.com",
        "haritalar" to "maps.google.com", "vikipedi" to "tr.wikipedia.org", "wikipedia" to "wikipedia.org"
    )

    private val help =
        "Yapay zekasız moddayım, sadece kalıp komutları anlarım. Örnekler: 'Chrome'u aç', 'sesi kıs', " +
            "'feneri aç', '10 dakika sonra hatırlat', 'saat kaç', 'İstanbul hava durumu', " +
            "'40 küp yap', 'modeli göster'. Sohbet için Ayarlar'dan bir yapay zeka seçin."

    private fun args(vararg p: Pair<String, Any>) = JSONObject().apply { p.forEach { put(it.first, it.second) } }

    fun handle(raw: String, s: Skills): String {
        val t = raw.lowercase(Locale("tr", "TR")).trim().trimEnd('.', '!', '?')
        if (t.isEmpty()) return "Sizi dinliyorum."

        // saat
        if (t.contains("saat kaç")) return s.run("get_time", JSONObject())

        // hava durumu
        if (t.contains("hava")) {
            val m = Regex("^(.*?)\\s*(?:['’]?(?:da|de|ta|te))?\\s*hava").find(t)
            val city = m?.groupValues?.get(1)?.trim().orEmpty().ifEmpty { "Istanbul" }
            return s.run("get_weather", args("city" to city))
        }

        // ses
        if (t.contains("sessize") || t.contains("sesi kapat")) return s.run("system_control", args("action" to "mute"))
        if (t.contains("sesi") || t.startsWith("ses ")) {
            if (Regex("artır|yükselt|aç|yükselt").containsMatchIn(t)) return s.run("system_control", args("action" to "volume_up"))
            if (Regex("azalt|kıs|düşür").containsMatchIn(t)) return s.run("system_control", args("action" to "volume_down"))
        }
        if (t.contains("müziği durdur") || t.contains("duraklat") || t.contains("oynat")) {
            return s.run("system_control", args("action" to "play_pause"))
        }

        // fener
        if (t.contains("fener")) {
            return s.run("system_control", args("action" to if (t.contains("kapat")) "flashlight_off" else "flashlight_on"))
        }

        // sayaç / hatırlatıcı
        val tm = Regex("(\\d+)\\s*(dakika|dk|saniye|sn|saat)").find(t)
        if (tm != null && Regex("hatırlat|sayaç|zamanlayıcı|süre").containsMatchIn(t)) {
            val v = tm.groupValues[1].toDouble()
            val minutes = when (tm.groupValues[2]) {
                "saniye", "sn" -> v / 60.0
                "saat" -> v * 60.0
                else -> v
            }
            return s.run("set_timer", args("minutes" to minutes, "message" to "ALGEBRA hatırlatması"))
        }

        // alarm
        val am = Regex("alarm.*?(\\d{1,2})[:.](\\d{2})").find(t) ?: Regex("(\\d{1,2})[:.](\\d{2}).*alarm").find(t)
        if (am != null) {
            return s.run("set_alarm", args("hour" to am.groupValues[1].toInt(), "minute" to am.groupValues[2].toInt()))
        }

        // 3D
        if (t.contains("modeli göster")) return s.run("show_model", JSONObject())
        if (t.contains("modeli kaydet")) return s.run("save_model", JSONObject())
        if (t.contains("baskı") && t.contains("kontrol")) return s.run("inspect_for_print", JSONObject())
        val sh = Regex("(?:(\\d+)\\s*(?:mm)?\\s*)?(küp|kutu|silindir|küre|koni|halka)\\s*(?:yap|çiz|oluştur|tasarla)").find(t)
        if (sh != null) {
            val size = sh.groupValues[1].toDoubleOrNull() ?: 30.0
            val part = JSONObject()
            when (sh.groupValues[2]) {
                "küp", "kutu" -> part.put("shape", "box").put("size", args("x" to size, "y" to size, "z" to size))
                "silindir" -> part.put("shape", "cylinder").put("size", args("radius" to size / 2, "height" to size))
                "küre" -> part.put("shape", "sphere").put("size", args("radius" to size / 2))
                "koni" -> part.put("shape", "cone").put("size", args("radius" to size / 2, "height" to size))
                else -> part.put("shape", "torus").put("size", args("major_radius" to size / 2, "minor_radius" to size / 8))
            }
            return s.run("make_3d_model", args("name" to sh.groupValues[2], "parts" to JSONArray().put(part)))
        }

        // arama
        val se = Regex("^(.+?)\\s+(?:ara|araştır)$").find(t)
        if (se != null) return s.run("web_search", args("query" to se.groupValues[1]))

        // aç
        val op = Regex("^(.+?)\\s*(?:uygulamasını|uygulamasi|programını|sitesini|sayfasını)?\\s*(?:aç|başlat|çalıştır)$").find(t)
        if (op != null) {
            val target = op.groupValues[1].replace(Regex("['’]\\w+$"), "").trim()
            if (target.contains(".")) return s.run("open_website", args("url" to target))
            val r = s.run("open_app", args("name" to target))
            val site = sites[target]
            return if (r.startsWith("Bulunamadı") && site != null) s.run("open_website", args("url" to site)) else r
        }

        return help
    }
}
