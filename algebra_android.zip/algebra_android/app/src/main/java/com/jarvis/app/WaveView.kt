package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Konuşma/dinleme sırasında hareket eden ses çubukları. level: 0..1 (hedef yükseklik). */
class WaveView(ctx: Context, private val color: Int) : View(ctx) {
    @Volatile var level = 0.15f
    private var cur = 0.15f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@WaveView.color; strokeCap = Paint.Cap.ROUND }

    override fun onDraw(c: Canvas) {
        cur += (level - cur) * 0.15f
        val n = 30
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val step = w / n
        p.strokeWidth = (step * 0.45f).coerceAtLeast(2f * d)
        val t = SystemClock.uptimeMillis() / 1000f
        for (i in 0 until n) {
            val env = 0.35f + 0.65f * abs(sin(i * 0.55f + t * 3f)) * (0.5f + 0.5f * sin(i * 0.23f - t * 1.7f))
            val bh = (h * 0.12f + h * 0.85f * cur * env).coerceAtMost(h)
            val x = step * (i + 0.5f)
            p.alpha = (110 + 145 * cur).toInt().coerceAtMost(255)
            c.drawLine(x, h / 2f - bh / 2f, x, h / 2f + bh / 2f, p)
        }
        postInvalidateOnAnimation()
    }
}
