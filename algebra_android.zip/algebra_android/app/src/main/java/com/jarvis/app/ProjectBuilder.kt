package com.jarvis.app

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * "insansı robot ... tasarla" gibi bir istekten tam bir proje paketi üretir ve İndirilenler/A1/Projeler/<proje> klasörüne yazar:
 *   sunum.html (slayt gösterisi), rapor.html (yazdırılıp PDF yapılabilir), malzeme_listesi.csv, eklemler.csv,
 *   robot_tam.stl + parcalar klasöründeki STL dosyaları (3B baskı), proje.json (parametreler ve parça listesi).
 * Sayılar (tork, kütle, güç, maliyet) kodla hesaplanır; yapay zeka yalnızca gereksinim, risk ve yol haritası önerir.
 * Bu bir ön tasarım paketidir: benzetim, sonlu elemanlar ve fiziksel test yerine geçmez; rapor bunu açıkça söyler.
 */
class ProjectBuilder(
    ctx: Context,
    private val lib: Library,
    private val ask: (String, String) -> String,
    private val say: (String) -> Unit
) {
    private val appCtx = ctx.applicationContext
    @Volatile private var building = false

    private class Spec(val brief: String, val heightMm: Double, val massKg: Double, val payloadKg: Double, val runtimeMin: Int, val massGiven: Boolean)
    private class Bom(val item: String, val qty: Int, val unit: Double, val note: String)
    private class Sec(val title: String, val html: String)

    // ---------------- komut ----------------

    fun command(low: String, orig: String): String? {
        val l = low.trim()
        val isProject = Regex("^(?:yeni\\s+)?proje\\s*[:,]?\\s+(.{5,})$").containsMatchIn(l) ||
            (l.contains("insansı robot") && Regex("tasarla|tasarım|geliştir|proje|oluştur|üret|sun|tamamla|yap").containsMatchIn(l) &&
                !l.contains("öğren") && !l.contains("araştır"))
        if (!isProject) return null
        if (building) return "Bir proje zaten hazırlanıyor, bitince haber veririm."
        val free = Learner.freeMb(appCtx)
        if (free < Learner.MIN_FREE_MB) return "Disk uyarısı: boş alan $free MB, 1 GB'ın altında. Proje dosyaları için yer açın."
        building = true
        Thread {
            try {
                say(buildProject(parse(orig)))
            } catch (e: Exception) {
                say("Proje yarıda kaldı: ${e.message}")
            } finally {
                building = false
            }
        }.start()
        return "Proje çalışmasına başladım. Hesapları yapıp 3B modeli, sunumu ve raporu hazırlayacağım; bitince dosya yerlerini söylerim."
    }

    private fun num(s: String) = s.replace(',', '.').toDoubleOrNull()

    private fun parse(brief: String): Spec {
        val t = brief.lowercase(Locale("tr", "TR"))
        var h = 1200.0
        Regex("(\\d+(?:[.,]\\d+)?)\\s*(cm|santim|santimetre|mm|metre|m)\\b").find(t)?.let {
            val v = num(it.groupValues[1]) ?: return@let
            h = when (it.groupValues[2]) {
                "mm" -> v
                "cm", "santim", "santimetre" -> v * 10
                else -> v * 1000
            }
        }
        h = h.coerceIn(300.0, 2200.0)
        var mass: Double? = null
        var payload = 2.0
        for (m in Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:kg|kilo)(\\s*(?:yük|taşı|kaldır))?").findAll(t)) {
            val v = num(m.groupValues[1]) ?: continue
            if (m.groupValues[2].isNotEmpty()) payload = v else if (mass == null) mass = v
        }
        Regex("(?:yük|taşıma kapasitesi|taşı)\\w*\\s*(\\d+(?:[.,]\\d+)?)\\s*(?:kg|kilo)").find(t)?.let { num(it.groupValues[1])?.let { v -> payload = v } }
        val run = Regex("(\\d+)\\s*(?:dk|dakika)").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 30
        val given = mass != null
        val m = mass ?: (0.7 * 70.0 * Math.pow(h / 1750.0, 3.0))
        return Spec(brief.trim(), h, m.coerceIn(2.0, 120.0), payload.coerceIn(0.0, 40.0), run.coerceIn(5, 240), given)
    }

    // ---------------- ana akış ----------------

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)
    private fun f2(x: Double) = String.format(Locale.US, "%.2f", x)
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun buildProject(sp: Spec): String {
        say("Hesaplıyorum: boy ${sp.heightMm.toInt()} mm, kütle ${f1(sp.massKg)} kg, yük ${f1(sp.payloadKg)} kg.")
        val hum = Humanoid(sp.heightMm, sp.massKg, sp.payloadKg)
        val joints = hum.joints()
        val sf = 2.0

        // aktüatör seçimi
        val picks = joints.map { it to Humanoid.pick(it.torqueNm * sf) }
        val actMass = picks.sumOf { it.first.qty * it.second.massKg }
        val actCost = picks.sumOf { it.first.qty * it.second.priceUsd }
        val busV = picks.maxOf { it.second.busV }.let { if (it <= 12) 12 else if (it <= 24) 24 else 48 }

        // 3B model ve parçalar
        say("3B model ve parçalar üretiliyor...")
        val parts = hum.parts()
        val full = Cad.build(parts)
        class PartInfo(val name: String, val label: String, val ext: FloatArray, val volMm3: Double, val massG: Double, val mesh: Mesh)
        val infos = ArrayList<PartInfo>()
        for (i in 0 until parts.length()) {
            val o = parts.getJSONObject(i)
            val m = Cad.build(JSONArray().put(o))
            infos.add(PartInfo(o.getString("name"), o.getString("label"), m.extents(), m.volumeMm3, m.volumeMm3 / 1000.0 * 1.27 * 0.25, m))
        }
        val structKg = infos.sumOf { it.massG } / 1000.0
        ModelStore.mesh = full
        ModelStore.name = "insansi_robot"
        ModelStore.parts = parts

        // güç ve kütle bütçesi
        val pMech = 1.0 * sp.massKg * 9.81 * 0.5            // taşıma maliyeti ≈ 1, hız 0,5 m/s
        val pElec = pMech / 0.5 + 25.0                      // %50 verim + mantık elektroniği
        val wh = pElec * sp.runtimeMin / 60.0 * 1.3
        val nomV = when (busV) { 12 -> 11.1; 24 -> 22.2; else -> 48.1 }
        val cellsTxt = when (busV) { 12 -> "3S"; 24 -> "6S"; else -> "13S" }
        val battKg = wh / (180.0 * 0.8)
        val elecKg = 0.6 + 0.01 * hum.dof
        val totalKg = actMass + structKg + battKg + elecKg
        val overPct = (totalKg / sp.massKg - 1.0) * 100.0

        // malzeme listesi
        val bom = ArrayList<Bom>()
        for ((name, grp) in picks.groupBy { it.second.name }) {
            val a = grp.first().second
            bom.add(Bom(name, grp.sumOf { it.first.qty }, a.priceUsd, "aktüatör"))
        }
        val filamentKg = max(1.0, ceil(structKg * 1.4))
        bom.add(Bom("Ana bilgisayar: NVIDIA Jetson Orin Nano 8GB geliştirme kiti", 1, 250.0, "algı, planlama, konuşma"))
        bom.add(Bom("Gerçek zamanlı denetleyici: Teensy 4.1", 1, 32.0, "denge ve eklem döngüsü"))
        bom.add(Bom("IMU: BNO085 modülü", 2, 25.0, "gövde ve kafa"))
        bom.add(Bom("Derinlik kamerası (RealSense D435i sınıfı)", 1, 320.0, "görü"))
        bom.add(Bom("Mikrofon dizisi (USB)", 1, 70.0, "ses girişi"))
        bom.add(Bom("Hoparlör", 1, 10.0, "ses çıkışı"))
        bom.add(Bom("Yük hücresi + HX711 (ayak kuvveti)", 8, 12.0, "ayak başına 4"))
        bom.add(Bom("Pil paketi $cellsTxt, ~${f1(wh)} Wh (~${f1(wh / nomV)} Ah)", 1, max(60.0, wh * 0.8), "BMS dahil"))
        bom.add(Bom("Acil durdurma düğmesi + kontaktör + ana sigorta", 1, 45.0, "donanım güvenliği"))
        bom.add(Bom("DC-DC dönüştürücüler (12V/5V mantık hattı)", 1, 25.0, ""))
        bom.add(Bom("CAN/RS485 haberleşme kartları ve kablolama seti", 1, 120.0, ""))
        bom.add(Bom("PETG / PA-CF filament (kg)", filamentKg.toInt(), 25.0, "tahmini tüketim"))
        bom.add(Bom("Alüminyum boru/profil ve bağlantı parçaları", 1, 150.0, "yük taşıyan uzuvlar"))
        bom.add(Bom("Rulman, vida, cıvata, ısıl yuva seti", 1, 80.0, ""))
        val bomTotal = bom.sumOf { it.qty * it.unit }

        // yapay zeka önerileri (yalnızca metin; sayıları kod hesapladı)
        val specText = "Boy ${sp.heightMm.toInt()} mm, kütle hedefi ${f1(sp.massKg)} kg, yük ${f1(sp.payloadKg)} kg, çalışma ${sp.runtimeMin} dk, " +
            "${hum.dof} serbestlik derecesi, veri yolu ${busV} V, tahmini kütle ${f1(totalKg)} kg, tahmini maliyet ~${bomTotal.toInt()} USD."
        val know = knowledge()
        val llm = ArrayList<Sec>()
        val sys = "Sen deneyimli bir robotik mühendisisin. Türkçe, kısa ve uygulanabilir yaz. Verilen sayıları kullan, yeni sayı uydurma. " +
            "En fazla 7 satır yaz; her satır '- ' ile başlasın. Başka giriş veya sonuç cümlesi yazma."
        val asks = listOf(
            "Kullanım amacı ve gereksinimler" to "Proje isteği: ${sp.brief}\nTeknik özet: $specText\n$know\nBu istek için ölçülebilir gereksinimleri ve kabul ölçütlerini yaz.",
            "Riskler ve azaltma" to "Proje isteği: ${sp.brief}\nTeknik özet: $specText\n$know\nBu tasarımın en önemli teknik risklerini ve her biri için azaltma yöntemini yaz.",
            "Yol haritası (aşama ve süre)" to "Proje isteği: ${sp.brief}\nTeknik özet: $specText\n$know\nBir kişilik atölye ekibi için aşamalı yol haritası yaz (aşama, hafta sayısı, çıktı)."
        )
        for ((i, a) in asks.withIndex()) {
            say("Yapay zeka önerisi ${i + 1}/3: ${a.first}")
            val html = try {
                list(ask(sys, a.second))
            } catch (e: Exception) {
                "<p class='warn'>Yapay zeka önerisi alınamadı (${esc(e.message ?: "hata")}). Bu bölüm boş bırakıldı; Ayarlar'dan bir yapay zeka seçip projeyi yeniden verin.</p>"
            }
            llm.add(Sec(a.first, html))
        }

        // dosyalar
        say("Sunum ve rapor yazılıyor...")
        val slug = "insansi_robot_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val dir = Environment.DIRECTORY_DOWNLOADS + "/A1/Projeler/" + slug

        val sb3 = StringBuilder()
        sb3.append("<div class='views'>")
        sb3.append("<figure>").append(svg(full, 0, 2, true, 300.0, 430.0)).append("<figcaption>Önden</figcaption></figure>")
        sb3.append("<figure>").append(svg(full, 1, 2, true, 160.0, 430.0)).append("<figcaption>Yandan</figcaption></figure>")
        sb3.append("<figure>").append(svg(full, 0, 1, false, 300.0, 200.0)).append("<figcaption>Üstten</figcaption></figure>")
        sb3.append("</div>")

        val segRows = listOf(
            listOf("Kafa", f1(hum.lHead * 1000), f2(hum.mHead)),
            listOf("Gövde", f1(hum.lTorso * 1000), f2(hum.mTrunk)),
            listOf("Üst kol (tek)", f1(hum.lUpperArm * 1000), f2(hum.mUpperArm)),
            listOf("Ön kol (tek)", f1(hum.lForearm * 1000), f2(hum.mForearm)),
            listOf("El (tek)", f1(hum.lHand * 1000), f2(hum.mHand)),
            listOf("Uyluk (tek)", f1(hum.lThigh * 1000), f2(hum.mThigh)),
            listOf("İncik (tek)", f1(hum.lShank * 1000), f2(hum.mShank)),
            listOf("Ayak (tek)", f1(hum.lFoot * 1000), f2(hum.mFoot))
        )
        val s = ArrayList<Sec>()
        s.add(Sec("Özet",
            "<div class='kpis'>" +
                kpi("Boy", "${sp.heightMm.toInt()} mm") + kpi("Hedef kütle", "${f1(sp.massKg)} kg") +
                kpi("Yük", "${f1(sp.payloadKg)} kg") + kpi("Serbestlik", "${hum.dof} DOF") +
                kpi("Çalışma", "${sp.runtimeMin} dk") + kpi("Tahmini maliyet", "~${bomTotal.toInt()} USD") +
                "</div><p class='note'>İstek: ${esc(sp.brief)}</p>" +
                "<h3>Uzuv ölçüleri ve kütleleri</h3>" + table(listOf("Uzuv", "Uzunluk (mm)", "Kütle (kg)"), segRows)))
        s.add(Sec("Görünümler", sb3.toString()))
        s.add(Sec("Eklemler ve aktüatörler",
            "<p>Statik en kötü durum torku; seçimde dinamik emniyet katsayısı ×${f1(sf)} uygulandı.</p>" +
                table(listOf("Eksen", "Adet", "Statik (N·m)", "Gerekli ×${f1(sf)}", "Seçilen aktüatör"),
                    picks.map { (j, a) ->
                        val ok = a.peakNm >= j.torqueNm * sf
                        listOf(j.name, j.qty.toString(), f2(j.torqueNm), f2(j.torqueNm * sf), a.name + if (ok) "" else " ⚠ yetersiz")
                    })))
        s.add(Sec("Kütle ve güç bütçesi",
            table(listOf("Kalem", "Kütle (kg)"), listOf(
                listOf("Aktüatörler", f2(actMass)), listOf("Yapı (baskı, %25 dolgu eşdeğeri)", f2(structKg)),
                listOf("Pil", f2(battKg)), listOf("Elektronik ve kablolama", f2(elecKg)),
                listOf("<b>Tahmini toplam</b>", "<b>${f2(totalKg)}</b>"), listOf("Hedef", f2(sp.massKg)))) +
                (if (overPct > 10) "<p class='warn'>⚠ Tahmini kütle hedefi %${f1(overPct)} aşıyor. Tork hesapları hedef kütleyle yapıldığı için ihtiyaç bundan da yüksek olabilir. " +
                    "Çözüm: hafif yapı (karbon boru, boşaltılmış parçalar), daha az DOF veya daha yüksek hedef kütle.</p>"
                else "<p class='ok'>Tahmini kütle hedefe uyuyor (fark %${f1(overPct)}).</p>") +
                "<h3>Güç</h3><p>Yürüme gücü ≈ taşıma maliyeti (1,0) × kütle × g × hız (0,5 m/s) = ${f1(pMech)} W mekanik; %50 verim ve 25 W elektronikle " +
                "<b>${f1(pElec)} W</b> elektriksel. ${sp.runtimeMin} dk için %30 payla <b>${f1(wh)} Wh</b>, ${busV} V veri yolu (${cellsTxt}) için ~${f1(wh / nomV)} Ah.</p>"))
        s.add(Sec("Elektronik mimari", ELECTRONICS))
        s.add(Sec("Kontrol ve yazılım", CONTROL))
        s.add(Sec("Parçalar ve üretim",
            "<p>Aşağıdaki parçalar bu paketteki <code>parcalar/</code> klasöründe STL olarak var. Bunlar blok halindeki ön tasarım geometrisidir; " +
                "üretimden önce içini boşaltın, montaj deliklerini ve aktüatör yuvalarını ekleyin. Yük taşıyan uzuvlarda alüminyum boru önerilir.</p>" +
                table(listOf("Parça", "En büyük ölçü (mm)", "Hacim (cm³)", "Kütle* (g)", "Baskı (220×220×250)"),
                    infos.map { p ->
                        val d = p.ext.sorted()
                        val fits = d[0] <= 220f && d[1] <= 220f && d[2] <= 250f
                        listOf(esc(p.label), f1(d[2].toDouble()), f1(p.volMm3 / 1000.0), f1(p.massG), if (fits) "sığar" else "bölünmeli")
                    }) + "<p class='note'>* PETG 1,27 g/cm³ ve %25 dolgu eşdeğeri varsayımıyla.</p>"))
        s.add(Sec("Malzeme listesi (yaklaşık)",
            table(listOf("Kalem", "Adet", "Birim (USD)", "Toplam (USD)", "Not"),
                bom.map { listOf(esc(it.item), it.qty.toString(), f1(it.unit), f1(it.qty * it.unit), esc(it.note)) } +
                    listOf(listOf("<b>Toplam</b>", "", "", "<b>${f1(bomTotal)}</b>", ""))) +
                "<p class='note'>Fiyatlar ve katalog değerleri yaklaşıktır; satın almadan önce güncel veri sayfalarından doğrulayın. Aktüatör fiyatı aktüatör bütçesi: ${actCost.toInt()} USD.</p>"))
        s.add(Sec("Test planı", TESTS))
        s.add(Sec("Güvenlik", SAFETY))
        s.addAll(llm.map { Sec("Yapay zeka önerisi: " + it.title, it.html) })
        s.add(Sec("Varsayımlar ve sınırlar",
            "<ul><li>Bu bir <b>ön tasarım</b> paketidir. Geometri blok halindedir; gerçek parça tasarımı, çarpışma kontrolü ve sonlu elemanlar analizi yapılmadı.</li>" +
                "<li>Torklar statik ve yarı-statik en kötü durum içindir (60° diz bükümü, kollar yatay). Dinamik yürüme yükleri emniyet katsayısıyla kapsanmaya çalışıldı, benzetimle doğrulanmalıdır.</li>" +
                "<li>Uzuv oranları ve kütle dağılımı insan antropometrisinden (Drillis-Contini, Winter) yaklaşıktır.</li>" +
                "<li>Güç tahmini taşıma maliyeti 1,0 ve 0,5 m/s varsayar; gerçek değer yürüyüş denetleyicisine bağlıdır.</li>" +
                "<li>Fiyatlar ve aktüatör değerleri yaklaşıktır.</li>" +
                "<li>Robotik bilgi kütüphanem: ${knowledgeCount()} not. ${if (knowledgeCount() < 5) "Henüz az; \"insansı robot için internetten öğren\" komutuyla zenginleştirirseniz öneriler iyileşir." else ""}</li></ul>"))

        val title = "İnsansı Robot Projesi"
        val stamp = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date())
        val deck = html(title, stamp, s, true)
        val doc = html(title, stamp, s, false)

        save(dir, "sunum.html", "text/html", deck.toByteArray(Charsets.UTF_8))
        save(dir, "rapor.html", "text/html", doc.toByteArray(Charsets.UTF_8))
        save(dir, "malzeme_listesi.csv", "text/csv",
            ("Kalem;Adet;Birim USD;Toplam USD;Not\n" + bom.joinToString("\n") {
                "\"${it.item}\";${it.qty};${f1(it.unit)};${f1(it.qty * it.unit)};\"${it.note}\""
            }).toByteArray(Charsets.UTF_8))
        save(dir, "eklemler.csv", "text/csv",
            ("Eksen;Grup;Adet;Statik Nm;Gerekli Nm;Aktuator\n" + picks.joinToString("\n") { (j, a) ->
                "${j.name};${j.group};${j.qty};${f2(j.torqueNm)};${f2(j.torqueNm * sf)};${a.name}"
            }).toByteArray(Charsets.UTF_8))
        save(dir, "robot_tam.stl", "application/octet-stream", Cad.toStl(full))
        for (p in infos) save("$dir/parcalar", p.name + ".stl", "application/octet-stream", Cad.toStl(p.mesh))
        val json = JSONObject()
            .put("format", "a1-proje").put("tur", "insansi_robot")
            .put("istek", sp.brief).put("boy_mm", sp.heightMm).put("kutle_kg", sp.massKg).put("yuk_kg", sp.payloadKg)
            .put("sure_dk", sp.runtimeMin).put("dof", hum.dof).put("veri_yolu_V", busV)
            .put("tahmini_kutle_kg", totalKg).put("tahmini_maliyet_usd", bomTotal)
            .put("parcalar", parts)
        save(dir, "proje.json", "application/json", json.toString(2).toByteArray(Charsets.UTF_8))

        return "Proje hazır: İndirilenler/A1/Projeler/$slug\n" +
            "- sunum.html (slayt gösterisi, tarayıcıda açın; ok tuşları veya ekrana dokunma)\n" +
            "- rapor.html (yazdırıp PDF yapabilirsiniz)\n" +
            "- robot_tam.stl ve parcalar/ (${infos.size} STL), malzeme_listesi.csv, eklemler.csv, proje.json\n" +
            "Özet: ${hum.dof} DOF, tahmini ${f1(totalKg)} kg (hedef ${f1(sp.massKg)}), ~${f1(pElec)} W, ~${bomTotal.toInt()} USD." +
            (if (overPct > 10) "\nUyarı: tahmini kütle hedefi %${f1(overPct)} aşıyor, ayrıntı raporda." else "") +
            (if (picks.any { it.second.peakNm < it.first.torqueNm * sf }) "\nUyarı: bazı eklemler için katalog yetersiz, özel aktüatör gerekir." else "") +
            "\n3B modeli görmek için \"modeli göster\" deyin."
    }

    // ---------------- yardımcılar ----------------

    private fun knowledge(): String {
        val sb = StringBuilder()
        for (f in listOf("robotik", "elektronik", "mekanik", "yazılım")) {
            for (e in lib.latest("özet", f, 2)) sb.append("- ").append(e.text.take(180)).append("\n")
            for (e in lib.latest("kanun", f, 2)) sb.append("- ").append(e.text.take(180)).append("\n")
        }
        return if (sb.isEmpty()) "" else "Kütüphanemdeki ilgili bilgiler:\n" + sb.toString().take(1500)
    }

    private fun knowledgeCount(): Int {
        var n = 0
        for (f in listOf("robotik", "elektronik", "mekanik", "yazılım")) {
            n += lib.latest("özet", f, 1000).size + lib.latest("kanun", f, 1000).size
        }
        return n
    }

    /** Modelin "- madde" satırlarını HTML listesine çevirir. */
    private fun list(text: String): String {
        val items = text.lines().map { it.trim().trimStart('-', '*', '•', ' ').replace("**", "") }.filter { it.length > 3 }.take(8)
        if (items.isEmpty()) return "<p class='warn'>Model boş cevap verdi.</p>"
        return "<ul>" + items.joinToString("") { "<li>${esc(it)}</li>" } + "</ul>"
    }

    private fun kpi(k: String, v: String) = "<div class='kpi'><span>$k</span><b>$v</b></div>"

    private fun table(head: List<String>, rows: List<List<String>>): String {
        val sb = StringBuilder("<div class='tw'><table><thead><tr>")
        for (h in head) sb.append("<th>").append(h).append("</th>")
        sb.append("</tr></thead><tbody>")
        for (r in rows) {
            sb.append("<tr>")
            for (c in r) sb.append("<td>").append(c).append("</td>")
            sb.append("</tr>")
        }
        return sb.append("</tbody></table></div>").toString()
    }

    /** Ağın dik izdüşümü: hx yatay eksen (0=x,1=y), vy dikey eksen (2=z veya 1=y). */
    private fun svg(m: Mesh, hx: Int, vy: Int, flipV: Boolean, maxW: Double, maxH: Double): String {
        val v = m.verts
        var minA = Double.MAX_VALUE; var maxA = -Double.MAX_VALUE
        var minB = Double.MAX_VALUE; var maxB = -Double.MAX_VALUE
        var i = 0
        while (i < v.size) {
            val a = v[i + hx].toDouble(); val b = v[i + vy].toDouble()
            minA = min(minA, a); maxA = max(maxA, a); minB = min(minB, b); maxB = max(maxB, b)
            i += 3
        }
        val w = max(1.0, maxA - minA); val h = max(1.0, maxB - minB)
        val sc = min(maxW / w, maxH / h)
        val pad = 10.0
        val sb = StringBuilder()
        sb.append("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${f1(w * sc + 2 * pad)} ${f1(h * sc + 2 * pad)}' class='view'><path d='")
        fun put(x: Double) {
            val r = Math.round(x * 10).toInt()
            sb.append(r / 10).append('.').append(abs(r % 10))
        }
        val e = m.edges
        var k = 0
        while (k + 1 < e.size) {
            val a = e[k] * 3; val b = e[k + 1] * 3
            val x1 = pad + (v[a + hx] - minA) * sc
            val x2 = pad + (v[b + hx] - minA) * sc
            val y1 = if (flipV) pad + (maxB - v[a + vy]) * sc else pad + (v[a + vy] - minB) * sc
            val y2 = if (flipV) pad + (maxB - v[b + vy]) * sc else pad + (v[b + vy] - minB) * sc
            sb.append('M'); put(x1); sb.append(' '); put(y1); sb.append('L'); put(x2); sb.append(' '); put(y2)
            k += 2
        }
        sb.append("'/></svg>")
        return sb.toString()
    }

    private fun html(title: String, stamp: String, secs: List<Sec>, deck: Boolean): String {
        val sb = StringBuilder()
        sb.append("<!doctype html><html lang='tr'><head><meta charset='utf-8'>")
        sb.append("<meta name='viewport' content='width=device-width,initial-scale=1'><title>").append(title).append("</title><style>")
        sb.append(CSS)
        sb.append(if (deck) DECK_CSS else DOC_CSS)
        sb.append("</style></head><body>")
        sb.append("<section class='slide cover'><h1>").append(title).append("</h1><p class='sub'>A1 tarafından hazırlandı · ")
            .append(stamp).append("</p><p class='sub'>Ön tasarım paketi</p></section>")
        for ((i, sec) in secs.withIndex()) {
            sb.append("<section class='slide'><h2><span>").append(i + 1).append("</span>").append(esc(sec.title)).append("</h2>")
                .append(sec.html).append("</section>")
        }
        if (deck) {
            sb.append("<div id='n'></div><script>")
            sb.append("var s=document.querySelectorAll('.slide'),i=0;")
            sb.append("function show(n){i=Math.max(0,Math.min(s.length-1,n));for(var k=0;k<s.length;k++){s[k].style.display=(k==i)?'flex':'none';}")
            sb.append("document.getElementById('n').textContent=(i+1)+' / '+s.length;window.scrollTo(0,0);}")
            sb.append("addEventListener('keydown',function(e){if(e.key=='ArrowRight'||e.key==' '||e.key=='PageDown')show(i+1);if(e.key=='ArrowLeft'||e.key=='PageUp')show(i-1);});")
            sb.append("addEventListener('click',function(e){if(e.target.closest('table'))return;show(e.clientX>innerWidth/2?i+1:i-1);});")
            sb.append("show(0);</script>")
        }
        return sb.append("</body></html>").toString()
    }

    private fun save(relDir: String, name: String, mime: String, bytes: ByteArray) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relDir)
        }
        val uri = appCtx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Dosya oluşturulamadı: $name")
        appCtx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: throw IOException("Dosya yazılamadı: $name")
    }

    // ---------------- sabit mühendislik içeriği ----------------

    private val CSS = """
        :root{--bg:#050b18;--panel:#0b1a33;--line:#16335f;--acc:#22d3ee;--tx:#e6f1ff;--mut:#8fa8c8;--warn:#ffb020;--ok:#3ddc97}
        *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.5}
        h1{font-size:clamp(28px,6vw,64px);margin:0 0 12px;letter-spacing:.02em}h2{font-size:clamp(20px,3.4vw,34px);margin:0 0 16px;color:var(--acc);display:flex;gap:12px;align-items:baseline}
        h2 span{font-size:.55em;color:var(--mut);border:1px solid var(--line);border-radius:6px;padding:0 8px}h3{color:var(--acc);margin:18px 0 8px}
        .sub{color:var(--mut)}.note{color:var(--mut);font-size:.9em}.warn{color:var(--warn)}.ok{color:var(--ok)}
        .tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:clamp(12px,1.6vw,16px)}
        th,td{border:1px solid var(--line);padding:6px 10px;text-align:left}th{background:var(--panel);color:var(--acc)}
        .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:12px}
        .kpi{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px}.kpi span{display:block;color:var(--mut);font-size:.8em}.kpi b{font-size:1.4em;color:var(--acc)}
        .views{display:flex;gap:18px;flex-wrap:wrap;align-items:flex-end;justify-content:center}figure{margin:0;text-align:center}
        .view{max-height:52vh;width:auto;max-width:90vw;background:var(--panel);border:1px solid var(--line);border-radius:8px}.view path{fill:none;stroke:var(--acc);stroke-width:.5}
        figcaption{color:var(--mut);margin-top:4px}code{background:var(--panel);padding:1px 6px;border-radius:4px}ul{padding-left:1.2em}li{margin:4px 0}
    """.trimIndent()

    private val DECK_CSS = """
        .slide{display:none;flex-direction:column;justify-content:center;min-height:100vh;padding:5vh 6vw;overflow:auto}
        .cover{align-items:flex-start}#n{position:fixed;right:14px;bottom:10px;color:var(--mut);font-size:13px}
        @media print{.slide{display:flex!important;min-height:auto;page-break-after:always;overflow:visible}#n{display:none}body{background:#fff;color:#000}
        h2,h3,th{color:#075985}.view{background:#fff}.view path{stroke:#075985}.kpi,th{background:#eef5fb}td,th,.kpi,.view{border-color:#9fb6cc}.sub,.note{color:#445}}
    """.trimIndent()

    private val DOC_CSS = """
        body{max-width:980px;margin:0 auto;padding:0 18px}.slide{padding:26px 0;border-bottom:1px solid var(--line)}.cover{padding:60px 0}
        @media print{body{background:#fff;color:#000}h2,h3,th{color:#075985}.view{background:#fff}.view path{stroke:#075985}.kpi,th{background:#eef5fb}
        td,th,.kpi,.view{border-color:#9fb6cc}.sub,.note{color:#445}.slide{page-break-inside:avoid}}
    """.trimIndent()

    private val ELECTRONICS = """
        <ul>
        <li><b>Üst seviye bilgisayar</b> (Jetson Orin Nano sınıfı): kamera, algı, planlama, konuşma ve davranış katmanı.</li>
        <li><b>Gerçek zamanlı denetleyici</b> (Teensy 4.1 / STM32): IMU okuma, ayak kuvveti, denge ve eklem komutları, 500 Hz-1 kHz.</li>
        <li><b>Aktüatör hattı:</b> BLDC için CAN-FD, Dynamixel için RS485/TTL; kol ve bacaklar ayrı hat, hat başına en fazla ~8 aktüatör.</li>
        <li><b>Güç:</b> tek pil → BMS → ana sigorta ve acil durdurma kontaktörü → motor veri yolu; ayrı DC-DC ile 12 V/5 V mantık hattı; toprak tek noktada birleşir.</li>
        <li><b>Algılama:</b> gövde ve kafada IMU, her ayakta 4 yük hücresi, aktüatör içi enkoder ve sıcaklık, derinlik kamerası, mikrofon dizisi.</li>
        <li><b>Isı:</b> aktüatör sıcaklığı sürekli okunur; yazılım limiti 70 °C'de tork azaltır, 80 °C'de durdurur.</li>
        </ul>
    """.trimIndent()

    private val CONTROL = """
        <ul>
        <li><b>Eklem seviyesi</b> (aktüatör sürücüsü, 1-10 kHz): akım/tork ve konum döngüsü (FOC, PID).</li>
        <li><b>Tüm vücut</b> (200-500 Hz): ters kinematik, doğrusal ters sarkaç/ZMP tabanlı yürüyüş, IMU ile durum kestirimi (tamamlayıcı veya Kalman filtresi).</li>
        <li><b>Davranış</b> (10-50 Hz): durum makinesi veya davranış ağacı; düşme algılama ve güvenli çökme.</li>
        <li><b>Algı ve konuşma:</b> görü, konuşma tanıma ve sentezi, dil modeli ile görev anlama.</li>
        <li><b>Yazılım yığını:</b> ROS 2, gerçek zamanlı çekirdek yaması, URDF modeli (uzuv uzunlukları ve kütleler bu rapordan alınır).</li>
        <li><b>Benzetim önce:</b> MuJoCo, Isaac Sim veya Gazebo'da yürüyüş ve denge doğrulanır; pekiştirmeli öğrenme politikaları alan rastgeleleştirmeyle eğitilir.</li>
        </ul>
    """.trimIndent()

    private val TESTS = """
        <ol>
        <li><b>Tezgâh:</b> tek aktüatör; tork-akım eğrisi, 30 dk ısınma testi (limit 70 °C).</li>
        <li><b>Tek uzuv:</b> kol ve bacak; yükle statik tutma, ters kinematik doğruluğu (hedef ±2 mm).</li>
        <li><b>Askıda tüm vücut:</b> ayaklar yerden kesik; tüm eksenler hareket, enerji ölçümü, kabloların sıkışması.</li>
        <li><b>Ayakta durma:</b> denge, hafif itme direnci, denetleyici ayarı.</li>
        <li><b>Emniyet halatıyla yürüme:</b> 0,2 m/s'den 0,5 m/s'ye kademeli.</li>
        <li><b>Yük ve dayanıklılık:</b> taşıma yükü, uzun çalışma, kontrollü düşme testi.</li>
        </ol>
        <p class='note'>Kabul ölçütleri: aktüatör sıcaklığı &lt; 70 °C, tork marjı ≥ 1,5, hedef çalışma süresinin ≥ %80'i.</p>
    """.trimIndent()

    private val SAFETY = """
        <ul>
        <li>Donanım acil durdurma (yazılımdan bağımsız kontaktör) her zaman erişilebilir olmalı.</li>
        <li>İlk testler emniyet halatı veya askıyla; robotun çevresinde kimse ve evcil hayvan olmadan.</li>
        <li>Pil: BMS, sigorta ve yanmaz kutu; şarj gözetimli.</li>
        <li>Parmak sıkışması ve ezilme noktaları kapatılmalı; eklem torku sınırları yazılımda tanımlı olmalı.</li>
        <li>Ağır düşme olasılığı için kafa ve pil bölgesine darbe emici yapı.</li>
        </ul>
    """.trimIndent()
}
