package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var settings: Settings
    private lateinit var skills: Skills
    private lateinit var brain: Brain
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var brainView: BrainView
    private lateinit var caption: TextView
    private lateinit var stage: android.widget.FrameLayout
    private var showLog = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val cBg = Color.parseColor("#000000")
    private val cPanel = Color.parseColor("#07140A")
    private val cAccent = Color.parseColor("#00FF66")
    private val cText = Color.parseColor("#7CFFA8")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        skills = Skills(this)
        brain = Brain(settings, skills, this)
        brain.onStatus = { msg ->
            runOnUiThread {
                addLine("A1", msg, cAccent)
                brainView.pulse()
                refreshGraph()
            }
        }
        tts = TextToSpeech(this, this)
        buildUi()
        refreshGraph()
        addLine("A1", "Sistemler çevrimiçi. Size nasıl yardımcı olabilirim? Yapay zekayı sağ üstteki ayarlardan seçebilirsiniz.", cAccent)
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val r = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = true
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                addLine(
                    "A1",
                    "Türkçe seslendirme bulunamadı. Ayarlar > Genel yönetim > Dil > Metinden sese (Samsung/Google) bölümünden Türkçe ses indirin.",
                    cAccent
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::brainView.isInitialized) refreshGraph()
    }

    /** Kütüphaneden ve tasarımlardan ilişki haritasını yeniden kurar. */
    private fun refreshGraph() {
        val entries = skills.library.forGraph(90)
        val edges = skills.library.edgesFor(entries)
        val nodes = ArrayList<BrainView.GNode>()
        for (e in entries) {
            val label = e.tags.firstOrNull()
                ?: e.text.split(" ").firstOrNull { it.length >= 3 }
                ?: ""
            nodes.add(BrainView.GNode(label.take(10), e.text, e.kind))
        }
        for (name in skills.memory.names().take(8)) {
            nodes.add(BrainView.GNode(name.take(10), "Tasarım: $name", "tasarım"))
        }
        brainView.setGraph(nodes, edges)
    }

    /** Telefonun belleği azalırsa yerel modeli kapat (A32 gibi 4 GB'lık cihazlarda RAM'i boşaltır). */
    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        val low = level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
        // Kilit bir cevap sürerken beklemesin diye arka planda kapat
        if (low) Thread { brain.resetOnDevice() }.start()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        worker.shutdown()
        super.onDestroy()
    }

    // ---------------- arayüz ----------------

    private fun buildUi() {
        val title = TextView(this).apply {
            text = "A1"
            setTextColor(cAccent)
            textSize = 22f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        val gear = Button(this).apply {
            text = "⚙ Ayarlar"
            setOnClickListener { showSettings() }
        }
        val logBtn = Button(this).apply {
            text = "☰ Metin"
            setOnClickListener {
                showLog = !showLog
                stage.visibility = if (showLog) View.GONE else View.VISIBLE
                scroll.visibility = if (showLog) View.VISIBLE else View.GONE
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(logBtn)
            addView(gear)
        }

        status = TextView(this).apply {
            text = "Hazır."
            setTextColor(cText)
            textSize = 12f
        }

        log = TextView(this).apply {
            setTextColor(cText)
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(cPanel)
            addView(log)
            visibility = View.GONE   // metin geçmişi varsayılan olarak gizli; "☰ Metin" ile açılır
        }

        brainView = BrainView(this).apply { onNodeTap = { t -> caption.text = t } }
        caption = TextView(this).apply {
            setTextColor(cText)
            textSize = 14f
            maxLines = 5
            setPadding(dp(14), dp(8), dp(14), dp(12))
            setBackgroundColor(Color.argb(140, 0, 0, 0))
        }
        stage = android.widget.FrameLayout(this).apply {
            addView(brainView, android.widget.FrameLayout.LayoutParams(-1, -1))
            addView(caption, android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }

        input = EditText(this).apply {
            hint = "Bir şey yazın..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(cPanel)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = InputType.TYPE_CLASS_TEXT
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)
                ) {
                    sendTyped(); true
                } else false
            }
        }
        val send = Button(this).apply { text = "➤"; setOnClickListener { sendTyped() } }
        val mic = Button(this).apply {
            text = "🎤"
            setOnClickListener { startListening() }
            // Uzun basış: Google'ın hazır konuşma penceresi (yedek yol)
            setOnLongClickListener { speechDialog(); true }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(send)
            addView(mic)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            setPadding(dp(12), dp(36), dp(12), dp(12))
            addView(header)
            addView(status)
            val lp = { LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                topMargin = dp(8); bottomMargin = dp(8)
            } }
            addView(stage, lp())
            addView(scroll, lp())
            addView(bar)
        }
        setContentView(root)
    }

    private fun addLine(who: String, text: String, color: Int) {
        val head = SpannableString("$who: ")
        head.setSpan(ForegroundColorSpan(color), 0, head.length, 0)
        head.setSpan(StyleSpan(Typeface.BOLD), 0, head.length, 0)
        log.append(head)
        log.append("$text\n\n")
        if (who != "SİZ" && ::caption.isInitialized) caption.text = text
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(t: String) { status.text = t }

    // ---------------- girdi ----------------

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) {
            input.setText("")
            handle(t)
        }
    }

    private fun handle(text: String) {
        addLine("SİZ", text, Color.WHITE)
        setStatus("Düşünüyorum...")
        brainView.setActive(true)
        worker.execute {
            val answer = try {
                brain.ask(text)
            } catch (e: Exception) {
                "Bir sorun oluştu: ${e.message}"
            }
            runOnUiThread {
                addLine("A1", answer, cAccent)
                speak(answer)
                setStatus("Hazır.")
                brainView.setActive(false)
                brainView.pulse()
                refreshGraph()
            }
        }
    }

    private fun speak(text: String) {
        if (ttsReady && settings.speak) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            // Samsung'da servis kapalı/eksik olabilir: Google'ın konuşma penceresini dene
            speechDialog()
            return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { setStatus("Dinliyorum...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { setStatus("İşleniyor...") }
                override fun onError(error: Int) {
                    when (error) {
                        // servis/istemci sorunları: yedek konuşma penceresine geç
                        SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> speechDialog()
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            setStatus("İnternet gerekli: konuşma tanıma için bağlantıyı kontrol edin.")
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            setStatus("Sizi duyamadım, tekrar deneyin.")
                        else -> setStatus("Konuşma tanıma hatası (kod $error). Mikrofona uzun basarak yedek yolu deneyin.")
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    val first = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (first.isNullOrBlank()) {
                        setStatus("Anlayamadım, tekrar deneyin.")
                        return
                    }
                    handle(stripWake(first))
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        recognizer?.startListening(i)
    }

    private fun stripWake(text: String): String {
        val cleaned = text.replace(
            Regex("^(a\\s?1|a\\s?bir|ay\\s?bir)[,\\s]*", RegexOption.IGNORE_CASE), ""
        ).trim()
        return cleaned.ifEmpty { text }
    }

    /** Google'ın hazır konuşma tanıma penceresi (yedek yol). */
    private fun speechDialog() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dinliyorum...")
        try {
            startActivityForResult(i, 2)
        } catch (e: Exception) {
            Toast.makeText(this, "Konuşma tanıma için Google uygulaması gerekli. Yazarak kullanabilirsiniz.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) {
            val first = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!first.isNullOrBlank()) handle(stripWake(first))
        }
        if (requestCode == 3 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importModel(uri)
        }
        if (requestCode == 4 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importLibrary(uri)
        }
    }

    // ---------------- yerel model dosyası ----------------

    // ---------------- kütüphane dışa / içe aktarma ----------------

    private fun exportLibrary() {
        worker.execute {
            val r = try {
                skills.run("export_library", org.json.JSONObject())
            } catch (e: Exception) {
                "Dışa aktarılamadı: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, r, Toast.LENGTH_LONG).show() }
        }
    }

    private fun pickLibrary() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        try {
            startActivityForResult(i, 4)
        } catch (e: Exception) {
            Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_LONG).show()
        }
    }

    private fun importLibrary(uri: android.net.Uri) {
        worker.execute {
            val msg = try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw java.io.IOException("Dosya okunamadı.")
                skills.importLibrary(text)
            } catch (e: Exception) {
                "İçe aktarılamadı: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }
    }

    private fun modelFile() = java.io.File(filesDir, "model.litertlm")

    private fun modelStatusText(): String {
        val f = modelFile()
        return if (f.exists()) "Yüklü model: %.0f MB".format(f.length() / 1048576.0) else "Model yüklü değil."
    }

    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        try {
            startActivityForResult(i, 3)
        } catch (e: Exception) {
            Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_LONG).show()
        }
    }

    /** Seçilen model dosyasını uygulamanın özel alanına kopyalar (büyük dosya, birkaç dakika sürebilir). */
    private fun importModel(uri: android.net.Uri) {
        setStatus("Model kopyalanıyor, lütfen bekleyin...")
        worker.execute {
            val tmp = java.io.File(filesDir, "model.tmp")
            try {
                contentResolver.openInputStream(uri).use { input ->
                    if (input == null) throw java.io.IOException("Dosya açılamadı.")
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var total = 0L
                        var next = 50L shl 20
                        var n = input.read(buf)
                        while (n >= 0) {
                            out.write(buf, 0, n)
                            total += n
                            if (total >= next) {
                                next += 50L shl 20
                                val mb = total / 1048576
                                runOnUiThread { setStatus("Kopyalanıyor: $mb MB") }
                            }
                            n = input.read(buf)
                        }
                    }
                }
                val dest = modelFile()
                dest.delete()
                if (!tmp.renameTo(dest)) throw java.io.IOException("Model kaydedilemedi.")
                brain.resetOnDevice()
                runOnUiThread {
                    setStatus("Model hazır.")
                    Toast.makeText(this, "Model yüklendi. Ayarlardan 'Telefonda' seçeneğini kaydedin.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                tmp.delete()
                runOnUiThread { setStatus("Model kopyalanamadı: ${e.message}") }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            Toast.makeText(this, "Mikrofon izni verilmedi; yazarak kullanabilirsiniz.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------- ayarlar ----------------

    private fun showSettings() {
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Providers.labels)
        val hint = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, dp(10)) }
        val key = EditText(this).apply {
            this.hint = "API anahtarı"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val model = EditText(this).apply { this.hint = "Model adı"; inputType = InputType.TYPE_CLASS_TEXT }
        val url = EditText(this).apply {
            this.hint = "Adres (URL)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val speak = CheckBox(this).apply { text = "Cevapları sesli oku"; isChecked = settings.speak }
        val learn = CheckBox(this).apply {
            text = "Otomatik çıkarım ve yorum (Claude/Gemini ile, kütüphaneye)"
            isChecked = settings.autoLearn
        }
        val libInfo = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(10), 0, dp(4))
            text = skills.run("library_stats", org.json.JSONObject())
        }
        val libExport = Button(this).apply { text = "Kütüphaneyi dışa aktar"; setOnClickListener { exportLibrary() } }
        val libImport = Button(this).apply { text = "Kütüphaneyi içe aktar"; setOnClickListener { pickLibrary() } }
        val modelInfo = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, dp(6)) }
        val pick = Button(this).apply {
            text = "Model dosyası seç (.litertlm)"
            setOnClickListener { pickModel() }
        }

        var selected = settings.provider
        fun fill(p: String) {
            selected = p
            hint.text = Providers.hint(p)
            val ai = p != Providers.OFFLINE && p != Providers.ONDEVICE
            val local = p == Providers.ONDEVICE
            key.visibility = if (ai) View.VISIBLE else View.GONE
            model.visibility = if (ai) View.VISIBLE else View.GONE
            url.visibility = if (ai) View.VISIBLE else View.GONE
            pick.visibility = if (local) View.VISIBLE else View.GONE
            modelInfo.visibility = if (local) View.VISIBLE else View.GONE
            modelInfo.text = modelStatusText()
            key.hint = if (p == Providers.POLLINATIONS) "API anahtarı (gerekmez)" else "API anahtarı"
            key.setText(settings.key(p))
            model.setText(settings.model(p))
            url.setText(settings.url(p))
        }

        spinner.setSelection(Providers.ids.indexOf(selected).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                fill(Providers.ids[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
            addView(spinner); addView(hint); addView(modelInfo); addView(pick)
            addView(key); addView(model); addView(url); addView(speak); addView(learn)
            addView(libInfo); addView(libExport); addView(libImport)
        }
        val sv = ScrollView(this).apply { addView(box) }

        AlertDialog.Builder(this)
            .setTitle("Ayarlar — Yapay zeka")
            .setView(sv)
            .setPositiveButton("Kaydet") { _, _ ->
                settings.save(selected, key.text.toString(), model.text.toString(), url.text.toString())
                settings.provider = selected
                settings.speak = speak.isChecked
                settings.autoLearn = learn.isChecked
                brain.reset()
                Toast.makeText(this, "Kaydedildi: ${Providers.labels[Providers.ids.indexOf(selected)]}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }
}
