package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.speech.tts.UtteranceProgressListener
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var settings: Settings
    private lateinit var skills: Skills
    private lateinit var brain: Brain
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var brainView: BrainView
    private lateinit var caption: TextView
    private lateinit var stage: android.widget.FrameLayout
    private var showLog = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsTrOk = false
    private var curEngine: String? = null
    private val ttsTried = HashSet<String>()
    private val ui = Handler(Looper.getMainLooper())
    private var tick = 0
    private val ticker = object : Runnable {
        override fun run() {
            tick++
            if (tick % 30 == 0) renderPanels()
            ui.postDelayed(this, 1000)
        }
    }
    private var recognizer: SpeechRecognizer? = null
    private val worker = Executors.newSingleThreadExecutor()

    private var cBg = Color.BLACK
    private var cPanel = Color.BLACK
    private var cAccent = Color.GREEN
    private var cText = Color.GREEN
    private lateinit var uiTheme: Theme

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        skills = Skills(this)
        uiTheme = Theme.byId(settings.theme)
        cBg = uiTheme.bg; cPanel = uiTheme.panel; cAccent = uiTheme.accent; cText = uiTheme.text
        brain = Brain(settings, skills, this)
        brain.onStatus = { msg ->
            runOnUiThread {
                addLine("A1", msg, cAccent)
                if (msg.startsWith("Disk uyarısı")) speak(msg)
                brainView.pulse()
                refreshGraph()
                renderPanels()
            }
        }
        initTts(null)
        buildUi()
        refreshGraph()
        renderPanels()
        addLine("A1", "Sistemler çevrimiçi. Size nasıl yardımcı olabilirim? Yapay zekayı sağ üstteki ayarlardan seçebilirsiniz.", cAccent)
    }

    private fun initTts(engine: String?) {
        ttsReady = false
        ttsTrOk = false
        try { tts?.shutdown() } catch (_: Exception) {}
        curEngine = engine
        tts = if (engine == null) TextToSpeech(this, this) else TextToSpeech(this, this, engine)
    }

    /** Türkçe sesi olmayan motorda diğer kurulu motorları dener (Samsung / Google). */
    private fun tryNextEngine(): Boolean {
        val t = tts ?: return false
        ttsTried.add(curEngine ?: t.defaultEngine ?: "")
        val next = try { t.engines.map { it.name }.firstOrNull { it !in ttsTried } } catch (_: Exception) { null }
        if (next == null) return false
        ui.post { initTts(next) }
        return true
    }

    override fun onInit(code: Int) {
        val t = tts ?: return
        if (code != TextToSpeech.SUCCESS) {
            if (!tryNextEngine()) {
                ttsReady = true
                renderPanels()
            }
            return
        }
        val loc = Locale("tr", "TR")
        var r = t.setLanguage(loc)
        if (r < TextToSpeech.LANG_AVAILABLE) r = t.setLanguage(Locale("tr"))
        val ok = r >= TextToSpeech.LANG_AVAILABLE
        if (ok) {
            // en iyi Türkçe sesi (tercihen çevrimdışı olanı) seç
            try {
                val v = t.voices?.filter { it.locale.language == "tr" }
                    ?.sortedWith(compareBy<android.speech.tts.Voice>({ it.isNetworkConnectionRequired }, { -it.quality }))?.firstOrNull()
                if (v != null) t.voice = v
            } catch (_: Exception) {}
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { ui.post { setLevel(1f) } }
                override fun onDone(id: String?) { ui.post { setLevel(0.15f) } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { ui.post { setLevel(0.15f) } }
            })
        }
        ttsTrOk = ok
        ttsReady = true
        if (!ok && tryNextEngine()) return
        if (!ok) {
            addLine(
                "A1",
                "Türkçe ses bulunamadı; bu yüzden sesli okumayı kapalı tuttum (İngilizce okumasın diye). " +
                    "Ayarlar > \"Türkçe ses ayarını aç\" düğmesinden Türkçe ses verisini indirin; sonra uygulamayı yeniden açın.",
                cAccent
            )
        }
        renderPanels()
    }

    override fun onResume() {
        super.onResume()
        if (::brainView.isInitialized) { refreshGraph(); renderPanels() }
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        val keep: CharSequence = if (::log.isInitialized) log.text else ""
        val cap: CharSequence = if (::caption.isInitialized) caption.text else ""
        buildUi()
        log.text = keep
        caption.text = cap
        refreshGraph()
        renderPanels()
    }

    /** Kütüphaneden ve tasarımlardan ilişki haritasını yeniden kurar. */
    private fun refreshGraph() {
        val entries = skills.library.forGraph(90)
        val edges = skills.library.edgesFor(entries)
        val nodes = ArrayList<BrainView.GNode>()
        for (e in entries) {
            val label = e.tags.firstOrNull()
                ?: e.text.split(" ").firstOrNull { it.length >= 3 }
                ?: ""
            nodes.add(BrainView.GNode(label.take(10), e.text, e.kind))
        }
        for (name in skills.memory.names().take(8)) {
            nodes.add(BrainView.GNode(name.take(10), "Tasarım: $name", "tasarım"))
        }
        brainView.setGraph(nodes, edges)
    }

    /** Telefonun belleği azalırsa yerel modeli kapat (A32 gibi 4 GB'lık cihazlarda RAM'i boşaltır). */
    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        val low = level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
        // Kilit bir cevap sürerken beklemesin diye arka planda kapat
        if (low) Thread { brain.resetOnDevice() }.start()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        worker.shutdown()
        super.onDestroy()
    }

    // ---------------- arayüz ----------------

    private fun buildUi() {
        val title = TextView(this).apply {
            text = "A1"
            setTextColor(cAccent)
            textSize = 22f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        val gear = Button(this).apply {
            text = "⚙ Ayarlar"
            setOnClickListener { showSettings() }
        }
        val colorBtn = Button(this).apply {
            text = "🎨"
            setOnClickListener { showThemes() }
        }
        val logBtn = Button(this).apply {
            text = "☰ Metin"
            setOnClickListener { toggleLog() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(colorBtn)
            addView(logBtn)
            addView(gear)
        }

        status = TextView(this).apply {
            text = "Hazır."
            setTextColor(cText)
            textSize = 12f
        }

        log = TextView(this).apply {
            setTextColor(cText)
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply {
            setBackgroundColor(cPanel)
            addView(log)
            visibility = View.GONE   // metin geçmişi varsayılan olarak gizli; "☰ Metin" ile açılır
        }

        brainView = BrainView(this).apply {
            setTheme(uiTheme)
            onNodeTap = { t -> caption.text = t }
            onMenu = { i -> menuAction(i) }
        }
        caption = TextView(this).apply {
            setTextColor(cText)
            textSize = 14f
            maxLines = 5
            setPadding(dp(14), dp(8), dp(14), dp(12))
            setBackgroundColor(Color.argb(140, 0, 0, 0))
        }
        stage = android.widget.FrameLayout(this).apply {
            addView(brainView, android.widget.FrameLayout.LayoutParams(-1, -1))
            addView(caption, android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }

        input = EditText(this).apply {
            hint = "Bir şey yazın..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(cPanel)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = InputType.TYPE_CLASS_TEXT
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_SEND ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)
                ) {
                    sendTyped(); true
                } else false
            }
        }
        val send = Button(this).apply { text = "➤"; setOnClickListener { sendTyped() } }
        val mic = Button(this).apply {
            text = "🎤"
            setOnClickListener { startListening() }
            // Uzun basış: Google'ın hazır konuşma penceresi (yedek yol)
            setOnLongClickListener { speechDialog(); true }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(send)
            addView(mic)
        }

        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(stage, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        val content: View = left
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            setPadding(dp(12), dp(if (landscape) 14 else 36), dp(12), dp(12))
            addView(header)
            addView(status)
            addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                topMargin = dp(8); bottomMargin = dp(8)
            })
            addView(bar)
        }
        setContentView(root)
    }

    private fun addLine(who: String, text: String, color: Int) {
        val head = SpannableString("$who: ")
        head.setSpan(ForegroundColorSpan(color), 0, head.length, 0)
        head.setSpan(StyleSpan(Typeface.BOLD), 0, head.length, 0)
        log.append(head)
        log.append("$text\n\n")
        if (who != "SİZ" && ::caption.isInitialized) caption.text = text
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** Renk seçim ekranı. */
    private fun showThemes() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        lateinit var dlg: android.app.AlertDialog
        for (th in Theme.all) {
            val b = Button(this).apply {
                text = th.label + if (th.id == uiTheme.id) "  ✓" else ""
                setTextColor(Color.BLACK)
                setBackgroundColor(th.accent)
                setOnClickListener {
                    settings.theme = th.id
                    dlg.dismiss()
                    recreate()
                }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48))
            lp.setMargins(0, dp(4), 0, dp(4))
            col.addView(b, lp)
        }
        val sv = ScrollView(this).apply { addView(col) }
        dlg = android.app.AlertDialog.Builder(this).setTitle("Renk seç").setView(sv)
            .setNegativeButton("Kapat", null).create()
        dlg.show()
    }

    private fun setStatus(t: String) { status.text = t }

    // ---------------- girdi ----------------

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) {
            input.setText("")
            handle(t)
        }
    }

    private fun handle(text: String) {
        addLine("SİZ", text, Color.WHITE)
        setStatus("Düşünüyorum...")
        brainView.setActive(true)
        setLevel(0.8f)
        worker.execute {
            val answer = try {
                brain.ask(text)
            } catch (e: Exception) {
                "Bir sorun oluştu: ${e.message}"
            }
            runOnUiThread {
                addLine("A1", answer, cAccent)
                speak(answer)
                setStatus("Hazır.")
                brainView.setActive(false)
                brainView.pulse()
                refreshGraph()
                renderPanels()
                if (!ttsTrOk || !settings.speak) setLevel(0.15f)
            }
        }
    }

    private fun speak(text: String) {
        // Türkçe ses yoksa susar: Türkçe metni İngilizce sesle okumak anlaşılmaz
        if (!ttsReady || !ttsTrOk || !settings.speak) return
        val clean = text.replace(Regex("[*_`#>|]+"), " ")
            .replace(Regex("[\\p{So}\\p{Cs}\\uFE0F]"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return
        val t = tts ?: return
        t.setLanguage(Locale("tr", "TR"))
        t.speak(clean.take(TextToSpeech.getMaxSpeechInputLength() - 1), TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            // Samsung'da servis kapalı/eksik olabilir: Google'ın konuşma penceresini dene
            speechDialog()
            return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { setStatus("Dinliyorum...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) { setLevel(((rmsdB + 2f) / 12f).coerceIn(0.15f, 1f)) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { setStatus("İşleniyor...") }
                override fun onError(error: Int) {
                    when (error) {
                        // servis/istemci sorunları: yedek konuşma penceresine geç
                        SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> speechDialog()
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            setStatus("İnternet gerekli: konuşma tanıma için bağlantıyı kontrol edin.")
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            setStatus("Sizi duyamadım, tekrar deneyin.")
                        else -> setStatus("Konuşma tanıma hatası (kod $error). Mikrofona uzun basarak yedek yolu deneyin.")
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    val first = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (first.isNullOrBlank()) {
                        setStatus("Anlayamadım, tekrar deneyin.")
                        return
                    }
                    handle(stripWake(first))
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        recognizer?.startListening(i)
    }

    private fun stripWake(text: String): String {
        val cleaned = text.replace(
            Regex("^(a\\s?1|a\\s?bir|ay\\s?bir)[,\\s]*", RegexOption.IGNORE_CASE), ""
        ).trim()
        return cleaned.ifEmpty { text }
    }

    /** Google'ın hazır konuşma tanıma penceresi (yedek yol). */
    private fun speechDialog() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dinliyorum...")
        try {
            startActivityForResult(i, 2)
        } catch (e: Exception) {
            Toast.makeText(this, "Konuşma tanıma için Google uygulaması gerekli. Yazarak kullanabilirsiniz.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) {
            val first = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!first.isNullOrBlank()) handle(stripWake(first))
        }
        if (requestCode == 3 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importModel(uri)
        }
        if (requestCode == 4 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importLibrary(uri)
        }
    }

    // ---------------- yerel model dosyası ----------------

    // ---------------- kütüphane dışa / içe aktarma ----------------

    private fun exportLibrary() {
        worker.execute {
            val r = try {
                skills.run("export_library", org.json.JSONObject())
            } catch (e: Exception) {
                "Dışa aktarılamadı: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, r, Toast.LENGTH_LONG).show() }
        }
    }

    private fun pickLibrary() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        try {
            startActivityForResult(i, 4)
        } catch (e: Exception) {
            Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_LONG).show()
        }
    }

    private fun importLibrary(uri: android.net.Uri) {
        worker.execute {
            val msg = try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw java.io.IOException("Dosya okunamadı.")
                skills.importLibrary(text)
            } catch (e: Exception) {
                "İçe aktarılamadı: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }
    }

    private fun modelFile() = java.io.File(filesDir, "model.litertlm")

    private fun modelStatusText(): String {
        val f = modelFile()
        return if (f.exists()) "Yüklü model: %.0f MB".format(f.length() / 1048576.0) else "Model yüklü değil."
    }

    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        try {
            startActivityForResult(i, 3)
        } catch (e: Exception) {
            Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_LONG).show()
        }
    }

    /** Seçilen model dosyasını uygulamanın özel alanına kopyalar (büyük dosya, birkaç dakika sürebilir). */
    private fun importModel(uri: android.net.Uri) {
        setStatus("Model kopyalanıyor, lütfen bekleyin...")
        worker.execute {
            val tmp = java.io.File(filesDir, "model.tmp")
            try {
                contentResolver.openInputStream(uri).use { input ->
                    if (input == null) throw java.io.IOException("Dosya açılamadı.")
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var total = 0L
                        var next = 50L shl 20
                        var n = input.read(buf)
                        while (n >= 0) {
                            out.write(buf, 0, n)
                            total += n
                            if (total >= next) {
                                next += 50L shl 20
                                val mb = total / 1048576
                                runOnUiThread { setStatus("Kopyalanıyor: $mb MB") }
                            }
                            n = input.read(buf)
                        }
                    }
                }
                val dest = modelFile()
                dest.delete()
                if (!tmp.renameTo(dest)) throw java.io.IOException("Model kaydedilemedi.")
                brain.resetOnDevice()
                runOnUiThread {
                    setStatus("Model hazır.")
                    Toast.makeText(this, "Model yüklendi. Ayarlardan 'Telefonda' seçeneğini kaydedin.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                tmp.delete()
                runOnUiThread { setStatus("Model kopyalanamadı: ${e.message}") }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            Toast.makeText(this, "Mikrofon izni verilmedi; yazarak kullanabilirsiniz.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------- ayarlar ----------------

    // ---------------- sağ taraf: bilgi panelleri ----------------

    private fun frame(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.argb(120, Color.red(cPanel), Color.green(cPanel), Color.blue(cPanel)))
            setStroke(dp(1), Color.argb(130, Color.red(cAccent), Color.green(cAccent), Color.blue(cAccent)))
            cornerRadius = dp(4).toFloat()
        }
    }

    private fun small(t: String, color: Int, sp: Float = 11f, bold: Boolean = false) = TextView(this).apply {
        text = t
        setTextColor(color)
        textSize = sp
        typeface = Typeface.MONOSPACE
        if (bold) setTypeface(typeface, Typeface.BOLD)
        letterSpacing = 0.06f
    }

    private fun lp(top: Int = 0, w: Int = LinearLayout.LayoutParams.MATCH_PARENT) =
        LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun tile(title: String, value: String): LinearLayout = frame().apply {
        addView(small(title, cAccent, 10f, true))
        addView(small(value, cText, 12f), lp(2))
    }

    private fun programStatus(text: String): String {
        val m = Regex("^(\\d{2}):(\\d{2})").find(text) ?: return ""
        val cal = java.util.Calendar.getInstance()
        val now = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        val diff = m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt() - now
        return when {
            diff <= 0 -> "Geçti"
            diff < 60 -> "$diff dk sonra"
            else -> "Sırada"
        }
    }

    private fun setLevel(v: Float) { if (::brainView.isInitialized) brainView.level = v }

    private fun batteryPct(): Int {
        val i = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", -1) ?: -1
        val sc = i?.getIntExtra("scale", 100) ?: 100
        return if (l < 0 || sc <= 0) -1 else l * 100 / sc
    }

    private fun ramPct(): Int {
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return if (mi.totalMem <= 0) 0 else ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
    }

    /** Kadranın yanlarındaki blokları gerçek verilerle hazırlayıp BrainView'e verir. */
    private fun renderPanels() {
        if (!::brainView.isInitialized) return
        val tr = Locale("tr", "TR")
        val lib = skills.library
        val prov = Providers.labels[Providers.ids.indexOf(settings.provider).coerceAtLeast(0)]
        val voice = when {
            !ttsReady -> "başlıyor"
            ttsTrOk -> "Türkçe ✓"
            else -> "Türkçe yok ✗"
        }
        val free = Learner.freeMb(this)
        val diskTxt = if (free == Long.MAX_VALUE) "?" else
            String.format(Locale.US, "%.1f GB", free / 1024.0) + if (free < Learner.MIN_FREE_MB) " ⚠" else ""
        val bat = batteryPct()
        val batTxt = if (bat >= 0) "%$bat" else "?"
        val ram = ramPct()
        val laws = lib.lawCounts().values.sum()
        val ss = lib.summaryCounts()

        val left = ArrayList<HudBlock>()
        val right = ArrayList<HudBlock>()
        // kullanıcının düzenlediği paneller: sırayla sol ve sağa dağılır
        for ((i, p) in skills.panels.snapshot().withIndex()) {
            val rows = p.rows.map { r ->
                val st = when {
                    p.kind == "program" -> programStatus(r.text)
                    r.ok == true -> "✓"
                    r.ok == false -> "✗"
                    else -> ""
                }
                r.text to st
            }
            val b = HudBlock(
                p.title.uppercase(tr),
                if (rows.isEmpty()) listOf("(boş) \"${p.title.lowercase(tr)} ... ekle\" deyin" to "") else rows
            )
            (if (i % 2 == 0) left else right).add(b)
        }
        left.add(HudBlock("SİSTEM", listOf("Ses" to voice, "RAM" to "%$ram", "Disk boş" to diskTxt, "Güç" to batTxt)))
        val sums = ss.entries.filter { it.value > 0 }.map { it.key to "${it.value} özet" }.take(6)
        right.add(HudBlock("KÜTÜPHANE", listOf("Not" to "${lib.count()}", "Kanun" to "$laws") + sums))
        brainView.setData(HudData(prov, "SES $voice · DİSK $diskTxt · GÜÇ $batTxt", left, right))
    }

    private fun toggleLog() {
        showLog = !showLog
        stage.visibility = if (showLog) View.GONE else View.VISIBLE
        scroll.visibility = if (showLog) View.VISIBLE else View.GONE
    }

    /** Kadran halkasındaki düğmeler (BrainView.MENU sırasıyla). */
    private fun menuAction(i: Int) {
        when (BrainView.MENU.getOrNull(i)) {
            "METİN" -> toggleLog()
            "KÜTÜPH" -> handle("neler öğrendin")
            "KANUN" -> handle("kanunlarım")
            "ÇALIŞ" -> handle("kendi kendine çalış")
            "DURDUR" -> handle("çalışmayı bırak")
            "MODEL" -> handle("modeli göster")
            "DİNLE" -> startListening()
            "PANEL" -> showPanelEditor()
            "RENK" -> showThemes()
            "AYAR" -> showSettings()
            "YENİ" -> {
                brain.reset()
                caption.text = "Yeni konuşma başladı."
            }
            "PROJE" -> {
                input.setText("proje: ")
                input.setSelection(input.text.length)
                input.requestFocus()
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(input, 0)
            }
        }
    }

    private fun askText(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine(true); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("Tamam") { _, _ -> ok(et.text.toString()) }
            .setNegativeButton("İptal", null).show()
    }

    private fun showPanelEditor() {
        val snap = skills.panels.snapshot()
        val names = ArrayList<String>()
        for (p in snap) names.add("${p.title} (${p.rows.size})")
        names.add("+ Yeni panel")
        names.add("↺ Varsayılana dön")
        AlertDialog.Builder(this).setTitle("Paneller")
            .setItems(names.toTypedArray()) { _, i ->
                when {
                    i < snap.size -> showRowEditor(i)
                    i == snap.size -> askText("Yeni panel adı", "") {
                        skills.panels.addPanel(it); renderPanels(); showPanelEditor()
                    }
                    else -> { skills.panels.resetDefaults(); renderPanels() }
                }
            }
            .setNegativeButton("Kapat", null).show()
    }

    private fun showRowEditor(pi: Int) {
        val p = skills.panels.snapshot().getOrNull(pi) ?: return
        val items = ArrayList<String>()
        items.add("+ Satır ekle")
        for (r in p.rows) items.add(r.text + (if (r.ok == true) "  ✓" else if (r.ok == false) "  ✗" else ""))
        items.add("🗑 Bu paneli sil")
        AlertDialog.Builder(this).setTitle(p.title)
            .setItems(items.toTypedArray()) { _, i ->
                when {
                    i == 0 -> askText(if (p.kind == "program") "Yeni satır (örn. 18:00 Gün sonu)" else "Yeni satır", "") {
                        skills.panels.addRow(pi, it); renderPanels(); showRowEditor(pi)
                    }
                    i == items.size - 1 -> { skills.panels.removePanel(pi); renderPanels(); showPanelEditor() }
                    else -> editRow(pi, i - 1, p)
                }
            }
            .setNegativeButton("Geri") { _, _ -> showPanelEditor() }
            .show()
    }

    private fun editRow(pi: Int, ri: Int, p: Panel) {
        val r = p.rows[ri]
        val et = EditText(this).apply { setText(r.text); setSingleLine(true); setSelection(text.length) }
        val b = AlertDialog.Builder(this).setTitle("Satırı düzenle").setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                skills.panels.setRow(pi, ri, et.text.toString(), r.ok); renderPanels(); showRowEditor(pi)
            }
            .setNegativeButton("Sil") { _, _ ->
                skills.panels.removeRow(pi, ri); renderPanels(); showRowEditor(pi)
            }
        if (p.kind == "baglanti") {
            b.setNeutralButton(if (r.ok == true) "✗ Kapalı yap" else "✓ Bağlı yap") { _, _ ->
                skills.panels.setRow(pi, ri, et.text.toString(), r.ok != true); renderPanels(); showRowEditor(pi)
            }
        }
        b.show()
    }

    private fun showSettings() {
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Providers.labels)
        val hint = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, dp(10)) }
        val key = EditText(this).apply {
            this.hint = "API anahtarı"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val model = EditText(this).apply { this.hint = "Model adı"; inputType = InputType.TYPE_CLASS_TEXT }
        val url = EditText(this).apply {
            this.hint = "Adres (URL)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val speak = CheckBox(this).apply { text = "Cevapları sesli oku"; isChecked = settings.speak }
        val learn = CheckBox(this).apply {
            text = "Otomatik çıkarım ve yorum (Claude/Gemini ile, kütüphaneye)"
            isChecked = settings.autoLearn
        }
        val libInfo = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(10), 0, dp(4))
            text = skills.run("library_stats", org.json.JSONObject())
        }
        val libExport = Button(this).apply { text = "Kütüphaneyi dışa aktar"; setOnClickListener { exportLibrary() } }
        val libImport = Button(this).apply { text = "Kütüphaneyi içe aktar"; setOnClickListener { pickLibrary() } }
        val ttsBtn = Button(this).apply {
            text = "Türkçe ses ayarını aç"
            setOnClickListener {
                try {
                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                } catch (_: Exception) {
                    try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "Ayarlar > Genel yönetim > Dil > Metinden sese yolunu izleyin.", Toast.LENGTH_LONG).show() }
                }
            }
        }
        val panelBtn = Button(this).apply { text = "Panelleri düzenle (sağ taraf)"; setOnClickListener { showPanelEditor() } }
        val modelInfo = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, dp(6)) }
        val pick = Button(this).apply {
            text = "Model dosyası seç (.litertlm)"
            setOnClickListener { pickModel() }
        }

        var selected = settings.provider
        fun fill(p: String) {
            selected = p
            hint.text = Providers.hint(p)
            val ai = p != Providers.OFFLINE && p != Providers.ONDEVICE
            val local = p == Providers.ONDEVICE
            key.visibility = if (ai) View.VISIBLE else View.GONE
            model.visibility = if (ai) View.VISIBLE else View.GONE
            url.visibility = if (ai) View.VISIBLE else View.GONE
            pick.visibility = if (local) View.VISIBLE else View.GONE
            modelInfo.visibility = if (local) View.VISIBLE else View.GONE
            modelInfo.text = modelStatusText()
            key.hint = if (p == Providers.POLLINATIONS) "API anahtarı (gerekmez)" else "API anahtarı"
            key.setText(settings.key(p))
            model.setText(settings.model(p))
            url.setText(settings.url(p))
        }

        spinner.setSelection(Providers.ids.indexOf(selected).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                fill(Providers.ids[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
            addView(spinner); addView(hint); addView(modelInfo); addView(pick)
            addView(key); addView(model); addView(url); addView(speak); addView(learn)
            addView(panelBtn); addView(ttsBtn)
            addView(libInfo); addView(libExport); addView(libImport)
        }
        val sv = ScrollView(this).apply { addView(box) }

        AlertDialog.Builder(this)
            .setTitle("Ayarlar — Yapay zeka")
            .setView(sv)
            .setPositiveButton("Kaydet") { _, _ ->
                settings.save(selected, key.text.toString(), model.text.toString(), url.text.toString())
                settings.provider = selected
                settings.speak = speak.isChecked
                settings.autoLearn = learn.isChecked
                brain.reset()
                Toast.makeText(this, "Kaydedildi: ${Providers.labels[Providers.ids.indexOf(selected)]}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }
}
