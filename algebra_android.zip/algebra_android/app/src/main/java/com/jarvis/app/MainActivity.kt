package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Ekranda yalnızca A.L.P.H.A. halkası vardır. Dokunuşlar:
 *  - halkanın içine dokun: yazı → dünya → ağ → yazı
 *  - halkanın dışına dokun: dinle (sesli komut / soru)
 *  - uzun bas: ayarlar
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener, VoiceControl.Host {

    private lateinit var settings: Settings
    private lateinit var skills: Skills
    private lateinit var brain: Brain
    private lateinit var brainView: BrainView
    private lateinit var voice: VoiceControl

    private val history = StringBuilder()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsTrOk = false
    private var speaking = false
    private var curEngine: String? = null
    private val ttsTried = HashSet<String>()
    private var warnedNoVoice = false
    private val ui = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var continuous = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        skills = Skills(this)
        brain = Brain(settings, skills, this)
        voice = VoiceControl(settings, this)
        brain.onStatus = { msg ->
            runOnUiThread {
                addLog("A1", msg)
                if (msg.startsWith("Disk uyarısı")) speak(msg)
                brainView.pulse()
                refreshGraph()
            }
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        brainView = BrainView(this).apply {
            onLongPress = { showSettings() }
            onOutsideTap = { toggleListening() }
        }
        setContentView(brainView)
        colorsChanged()
        initTts(null)
        refreshGraph()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c) // BrainView kendi boyutuna göre yeniden yerleşir
    }

    override fun onResume() {
        super.onResume()
        refreshGraph()
    }

    override fun onDestroy() {
        continuous = false
        recognizer?.destroy()
        tts?.shutdown()
        worker.shutdown()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        val low = level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
        if (low) Thread { brain.resetOnDevice() }.start()
    }

    // ---------------- VoiceControl.Host ----------------

    override fun colorsChanged() {
        brainView.setColors(settings.textColor, settings.ringColor, settings.bgColor)
        window.decorView.setBackgroundColor(settings.bgColor)
    }

    override fun setMode(m: Int) { brainView.setMode(m) }
    override fun openSettings() { showSettings() }
    override fun listenContinuous(on: Boolean) {
        continuous = on
        if (on) startListening() else { recognizer?.cancel(); brainView.level = 0f }
    }
    override fun voiceChanged() {}
    override fun providerChanged() { brain.reset() }

    // ---------------- günlük ve ağ ----------------

    private fun addLog(who: String, text: String) {
        history.append(who).append(": ").append(text).append("\n\n")
        if (history.length > 30000) history.delete(0, history.length - 20000)
    }

    private fun refreshGraph() {
        val entries = skills.library.forGraph(90)
        val edges = skills.library.edgesFor(entries)
        val nodes = ArrayList<BrainView.GNode>()
        for (e in entries) {
            val label = e.tags.firstOrNull() ?: e.text.split(" ").firstOrNull { it.length >= 3 } ?: ""
            nodes.add(BrainView.GNode(label.take(10), e.text, e.kind))
        }
        for (name in skills.memory.names().take(8)) {
            nodes.add(BrainView.GNode(name.take(10), "Tasarım: $name", "tasarım"))
        }
        brainView.setGraph(nodes, edges)
    }

    // ---------------- ses çıkışı (Türkçe + İngilizce) ----------------

    private fun initTts(engine: String?) {
        ttsReady = false
        ttsTrOk = false
        try { tts?.shutdown() } catch (_: Exception) {}
        curEngine = engine
        tts = if (engine == null) TextToSpeech(this, this) else TextToSpeech(this, this, engine)
    }

    /** Türkçe sesi olmayan motorda diğer kurulu motorları dener (Samsung / Google). */
    private fun tryNextEngine(): Boolean {
        val t = tts ?: return false
        ttsTried.add(curEngine ?: t.defaultEngine ?: "")
        val next = try { t.engines.map { it.name }.firstOrNull { it !in ttsTried } } catch (_: Exception) { null }
        if (next == null) return false
        ui.post { initTts(next) }
        return true
    }

    override fun onInit(code: Int) {
        val t = tts ?: return
        if (code != TextToSpeech.SUCCESS) {
            if (!tryNextEngine()) ttsReady = true
            return
        }
        var r = t.setLanguage(Locale("tr", "TR"))
        if (r < TextToSpeech.LANG_AVAILABLE) r = t.setLanguage(Locale("tr"))
        ttsTrOk = r >= TextToSpeech.LANG_AVAILABLE
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { ui.post { brainView.level = 1f } }
            override fun onDone(id: String?) { ui.post { speechEnded() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { ui.post { speechEnded() } }
        })
        ttsReady = true
        if (!ttsTrOk && tryNextEngine()) return
        if (!ttsTrOk && !warnedNoVoice) {
            warnedNoVoice = true
            Toast.makeText(this, "Türkçe ses verisi yok. Ayarlar > \"Ses ayarını aç\" ile indirin; İngilizce okuma çalışır.", Toast.LENGTH_LONG).show()
        }
    }

    private fun speechEnded() {
        speaking = false
        brainView.level = 0f
        resumeListening()
    }

    private val trWords = setOf("ve", "bir", "bu", "için", "ile", "ben", "sen", "de", "da", "mi", "mı", "ne", "evet", "hayır",
        "tamam", "merhaba", "nasıl", "çok", "var", "yok", "daha", "gibi", "ama", "efendim", "olarak", "şu", "o", "ki", "değil")
    private val enWords = setOf("the", "and", "is", "are", "you", "to", "of", "in", "it", "that", "for", "with", "this", "what",
        "how", "i", "can", "will", "your", "have", "not", "be", "on", "my", "hello", "yes", "no", "please", "was", "do")

    private fun isTurkish(t: String): Boolean {
        when (settings.lang) { "tr" -> return true; "en" -> return false }
        if (Regex("[çğıöşüÇĞİÖŞÜ]").containsMatchIn(t)) return true
        val w = t.lowercase(Locale.ROOT).split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
        val en = w.count { it in enWords }
        val tr = w.count { it in trWords }
        return tr >= en
    }

    private fun applyVoice(t: TextToSpeech, turkish: Boolean) {
        try {
            val lang = if (turkish) "tr" else "en"
            val all = t.voices?.filter { it.locale.language == lang } ?: return
            val saved = if (turkish) settings.voiceTr else settings.voiceEn
            val v = all.firstOrNull { it.name == saved }
                ?: all.sortedWith(compareBy<android.speech.tts.Voice>({ it.isNetworkConnectionRequired }, { -it.quality })).firstOrNull()
            if (v != null) t.voice = v
        } catch (_: Exception) {}
    }

    /** Cevabı sesli okur; dili metinden seçer. Okuma başladıysa true. */
    private fun speak(text: String): Boolean {
        if (!ttsReady || !settings.speak) return false
        val clean = text.replace(Regex("[*_`#>|]+"), " ")
            .replace(Regex("[\\p{So}\\p{Cs}\\uFE0F]"), "")
            .replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return false
        val t = tts ?: return false
        val turkish = isTurkish(clean)
        var r = t.setLanguage(if (turkish) Locale("tr", "TR") else Locale.US)
        if (r < TextToSpeech.LANG_AVAILABLE && turkish) r = t.setLanguage(Locale("tr"))
        if (r < TextToSpeech.LANG_AVAILABLE) {
            if (!warnedNoVoice) {
                warnedNoVoice = true
                Toast.makeText(this, if (turkish) "Türkçe ses verisi yok (Ayarlar > Ses ayarını aç)." else "İngilizce ses verisi yok.", Toast.LENGTH_LONG).show()
            }
            return false
        }
        applyVoice(t, turkish)
        t.setPitch(settings.pitch)
        t.setSpeechRate(settings.rate)
        speaking = true
        t.speak(clean.take(TextToSpeech.getMaxSpeechInputLength() - 1), TextToSpeech.QUEUE_FLUSH, null, "alpha")
        return true
    }

    // ---------------- girdi ----------------

    private fun handle(text: String) {
        addLog("SİZ", text)
        voice.handle(text)?.let { reply ->
            addLog("A1", reply)
            afterReply(reply)
            return
        }
        brainView.setActive(true)
        brainView.level = 0.5f
        worker.execute {
            val answer = try {
                brain.ask(text)
            } catch (e: Exception) {
                "Bir sorun oluştu: ${e.message}"
            }
            runOnUiThread {
                addLog("A1", answer)
                brainView.setActive(false)
                brainView.pulse()
                refreshGraph()
                afterReply(answer)
            }
        }
    }

    private fun afterReply(answer: String) {
        if (!speak(answer)) {
            brainView.level = 0f
            resumeListening()
        }
    }

    private fun resumeListening() {
        if (continuous && !speaking) ui.postDelayed({ if (continuous && !speaking) startListening() }, 500)
    }

    private fun toggleListening() {
        if (continuous) { listenContinuous(false); Toast.makeText(this, "Dinleme kapandı.", Toast.LENGTH_SHORT).show(); return }
        tts?.stop()
        startListening()
    }

    private fun sttLang() = if (settings.lang == "en") "en-US" else "tr-TR"

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { speechDialog(); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { brainView.level = 0.2f }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) { brainView.level = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1f) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { brainView.level = 0f }
                override fun onError(error: Int) {
                    brainView.level = 0f
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            if (continuous) ui.postDelayed({ if (continuous && !speaking) startListening() }, 400)
                        SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            continuous = false; speechDialog()
                        }
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                            continuous = false
                            Toast.makeText(this@MainActivity, "Konuşma tanıma için internet gerekli.", Toast.LENGTH_LONG).show()
                        }
                        else -> {
                            continuous = false
                            Toast.makeText(this@MainActivity, "Konuşma tanıma hatası (kod $error).", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    val first = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (first.isNullOrBlank()) { resumeListening(); return }
                    handle(stripWake(first))
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, sttLang())
            .putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf("en-US", "tr-TR"))
        recognizer?.startListening(i)
    }

    private fun stripWake(text: String): String {
        val cleaned = text.replace(
            Regex("^(a\\s?1|a\\s?bir|ay\\s?bir|alfa|alpha|al\\s?fa|a\\.?\\s?l\\.?\\s?p\\.?\\s?h\\.?\\s?a\\.?)[,\\s]+", RegexOption.IGNORE_CASE), ""
        ).trim()
        return cleaned.ifEmpty { text }
    }

    /** Google'ın hazır konuşma penceresi (yedek yol). */
    private fun speechDialog() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, sttLang())
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dinliyorum...")
        try {
            startActivityForResult(i, 2)
        } catch (e: Exception) {
            Toast.makeText(this, "Konuşma tanıma için Google uygulaması gerekli. Ayarlar > Metinle yaz ile kullanabilirsiniz.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) {
            val first = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!first.isNullOrBlank()) handle(stripWake(first))
        }
        if (requestCode == 3 && resultCode == RESULT_OK) data?.data?.let { importModel(it) }
        if (requestCode == 4 && resultCode == RESULT_OK) data?.data?.let { importLibrary(it) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            Toast.makeText(this, "Mikrofon izni verilmedi. Ayarlar > Metinle yaz ile kullanabilirsiniz.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------- kütüphane dışa / içe aktarma ----------------

    private fun exportLibrary() {
        worker.execute {
            val r = try { skills.run("export_library", org.json.JSONObject()) } catch (e: Exception) { "Dışa aktarılamadı: ${e.message}" }
            runOnUiThread { Toast.makeText(this, r, Toast.LENGTH_LONG).show() }
        }
    }

    private fun pickFile(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        try { startActivityForResult(i, code) } catch (e: Exception) {
            Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_LONG).show()
        }
    }

    private fun importLibrary(uri: android.net.Uri) {
        worker.execute {
            val msg = try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw java.io.IOException("Dosya okunamadı.")
                skills.importLibrary(text)
            } catch (e: Exception) { "İçe aktarılamadı: ${e.message}" }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }
    }

    // ---------------- yerel model dosyası ----------------

    private fun modelFile() = java.io.File(filesDir, "model.litertlm")

    private fun modelStatusText(): String {
        val f = modelFile()
        return if (f.exists()) "Yüklü model: %.0f MB".format(f.length() / 1048576.0)
        else "Model yüklü değil (şimdilik Pollinations kullanılıyor)."
    }

    private fun importModel(uri: android.net.Uri) {
        Toast.makeText(this, "Model kopyalanıyor, birkaç dakika sürebilir...", Toast.LENGTH_LONG).show()
        worker.execute {
            val tmp = java.io.File(filesDir, "model.tmp")
            try {
                contentResolver.openInputStream(uri).use { input ->
                    if (input == null) throw java.io.IOException("Dosya açılamadı.")
                    tmp.outputStream().use { out -> input.copyTo(out, 1 shl 20) }
                }
                val dest = modelFile()
                dest.delete()
                if (!tmp.renameTo(dest)) throw java.io.IOException("Model kaydedilemedi.")
                brain.resetOnDevice()
                runOnUiThread { Toast.makeText(this, "Model yüklendi. Artık kendi yapay zekam çalışacak.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                tmp.delete()
                runOnUiThread { Toast.makeText(this, "Model kopyalanamadı: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun downloadModel(url: String, token: String) {
        if (!url.startsWith("https://")) {
            Toast.makeText(this, "Önce modelin https:// ile başlayan indirme adresini yapıştırın.", Toast.LENGTH_LONG).show()
            return
        }
        settings.modelUrl = url
        settings.hfToken = token
        val msg = TextView(this).apply { text = "Başlıyor..."; setPadding(dp(24), dp(16), dp(24), dp(8)) }
        val dlg = AlertDialog.Builder(this).setTitle("Model indiriliyor").setView(msg)
            .setCancelable(false)
            .setNegativeButton("İptal") { _, _ -> ModelDownloader.cancelled = true }.show()
        worker.execute {
            try {
                ModelDownloader.download(url, token, modelFile()) { got, total ->
                    runOnUiThread {
                        msg.text = if (total > 0) "%d / %d MB".format(got shr 20, total shr 20) else "%d MB".format(got shr 20)
                    }
                }
                brain.resetOnDevice()
                runOnUiThread { dlg.dismiss(); Toast.makeText(this, "Model indirildi.", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { dlg.dismiss(); Toast.makeText(this, "İndirilemedi: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    // ---------------- ayarlar ----------------

    private fun askText(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine(true); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("Tamam") { _, _ -> ok(et.text.toString()) }
            .setNegativeButton("İptal", null).show()
    }

    private fun swatch(color: Int, size: Int): View = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(1), Color.GRAY)
        }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    /** Renk paleti: renklere dokun veya #RRGGBB yaz. */
    private fun pickColor(title: String, onPick: (Int) -> Unit) {
        lateinit var dlg: AlertDialog
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        var row: LinearLayout? = null
        for ((i, nc) in Palette.colors.withIndex()) {
            if (i % 5 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
                col.addView(row)
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { onPick(nc.color); dlg.dismiss() }
                addView(swatch(nc.color, 44))
                addView(TextView(this@MainActivity).apply { text = nc.label; textSize = 10f; gravity = Gravity.CENTER })
            }
            row?.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val hex = EditText(this).apply { hint = "Özel renk: #RRGGBB"; setSingleLine(true) }
        col.addView(hex)
        dlg = AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("Özel rengi uygula") { _, _ ->
                val c = Palette.find(hex.text.toString())
                if (c != null) onPick(c) else Toast.makeText(this, "Geçerli bir renk girin (#RRGGBB).", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Kapat", null).create()
        dlg.show()
    }

    private fun chooseVoice(turkish: Boolean) {
        val t = tts
        val lang = if (turkish) "tr" else "en"
        val vs = try { t?.voices?.filter { it.locale.language == lang }?.sortedBy { it.name } } catch (_: Exception) { null }
        if (t == null || vs.isNullOrEmpty()) {
            Toast.makeText(this, if (turkish) "Türkçe ses bulunamadı." else "İngilizce ses bulunamadı.", Toast.LENGTH_LONG).show()
            return
        }
        val names = vs.map { it.name + if (it.isNetworkConnectionRequired) " (ağ)" else "" }.toTypedArray()
        AlertDialog.Builder(this).setTitle(if (turkish) "Türkçe ses seç" else "İngilizce ses seç")
            .setItems(names) { _, i ->
                val v = vs[i]
                if (turkish) settings.voiceTr = v.name else settings.voiceEn = v.name
                try {
                    t.setLanguage(v.locale)
                    t.voice = v
                    t.setPitch(settings.pitch)
                    t.setSpeechRate(settings.rate)
                    t.speak(if (turkish) "Merhaba, ben alfa." else "Hello, I am alpha.", TextToSpeech.QUEUE_FLUSH, null, "demo")
                } catch (_: Exception) {}
            }
            .setNegativeButton("Kapat", null).show()
    }

    private fun showHistory() {
        val tv = TextView(this).apply {
            text = if (history.isEmpty()) "Henüz konuşma yok." else history.toString()
            setPadding(dp(20), dp(10), dp(20), dp(10))
            setTextIsSelectable(true)
        }
        AlertDialog.Builder(this).setTitle("Sohbet geçmişi").setView(ScrollView(this).apply { addView(tv) })
            .setNegativeButton("Kapat", null).show()
    }

    private fun showSettings() {
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Providers.labels)
        val hint = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, dp(10)) }
        val key = EditText(this).apply { this.hint = "API anahtarı"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val model = EditText(this).apply { this.hint = "Model adı"; inputType = InputType.TYPE_CLASS_TEXT }
        val url = EditText(this).apply { this.hint = "Adres (URL)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
        val modelInfo = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, dp(6)) }
        val pick = Button(this).apply { text = "Model dosyası seç (.litertlm)"; setOnClickListener { pickFile(3) } }
        val dlUrl = EditText(this).apply {
            this.hint = "Model indirme adresi (https://...litertlm)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(settings.modelUrl)
        }
        val dlToken = EditText(this).apply {
            this.hint = "Hugging Face erişim anahtarı (gerekirse)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(settings.hfToken)
        }
        val dlBtn = Button(this).apply {
            text = "Modeli internetten indir"
            setOnClickListener { downloadModel(dlUrl.text.toString().trim(), dlToken.text.toString().trim()) }
        }

        var selected = settings.provider
        fun fill(p: String) {
            selected = p
            hint.text = Providers.hint(p)
            val ai = p != Providers.OFFLINE && p != Providers.ONDEVICE
            val local = p == Providers.ONDEVICE
            for (v in listOf(key, model, url)) v.visibility = if (ai) View.VISIBLE else View.GONE
            for (v in listOf(pick, modelInfo, dlUrl, dlToken, dlBtn)) v.visibility = if (local) View.VISIBLE else View.GONE
            modelInfo.text = modelStatusText()
            key.hint = if (p == Providers.POLLINATIONS) "API anahtarı (gerekmez)" else "API anahtarı"
            key.setText(settings.key(p)); model.setText(settings.model(p)); url.setText(settings.url(p))
        }
        spinner.setSelection(Providers.ids.indexOf(selected).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { fill(Providers.ids[position]) }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        fun section(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(16), 0, dp(4))
        }

        // renkler
        fun colorRow(label: String, get: () -> Int, set: (Int) -> Unit): View {
            val chip = swatch(get(), 28)
            val btn = Button(this).apply {
                text = label
                setOnClickListener {
                    pickColor(label) { c ->
                        set(c); colorsChanged()
                        chip.background = (chip.background as GradientDrawable).apply { setColor(c) }
                    }
                }
            }
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(chip); addView(btn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
        }

        // ses
        val speak = CheckBox(this).apply { text = "Cevapları sesli oku"; isChecked = settings.speak }
        val pitchLbl = TextView(this)
        val pitchBar = SeekBar(this).apply {
            max = 100; progress = (settings.pitch * 100).toInt() - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    pitchLbl.text = "Ses tonu: %${p + 50}"; if (fromUser) settings.pitch = (p + 50) / 100f
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        pitchLbl.text = "Ses tonu: %${pitchBar.progress + 50}"
        val rateLbl = TextView(this)
        val rateBar = SeekBar(this).apply {
            max = 110; progress = (settings.rate * 100).toInt() - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    rateLbl.text = "Konuşma hızı: %${p + 50}"; if (fromUser) settings.rate = (p + 50) / 100f
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        rateLbl.text = "Konuşma hızı: %${rateBar.progress + 50}"
        val langSp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Dil: cevaba göre otomatik", "Dil: hep Türkçe", "Dil: hep İngilizce"))
            setSelection(when (settings.lang) { "tr" -> 1; "en" -> 2; else -> 0 })
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    settings.lang = when (pos) { 1 -> "tr"; 2 -> "en"; else -> "auto" }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        val trVoice = Button(this).apply { text = "Türkçe ses seç"; setOnClickListener { chooseVoice(true) } }
        val enVoice = Button(this).apply { text = "İngilizce ses seç"; setOnClickListener { chooseVoice(false) } }
        val ttsBtn = Button(this).apply {
            text = "Ses verisi ayarını aç (Türkçe/İngilizce indir)"
            setOnClickListener {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) {
                    try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) } catch (_: Exception) {
                        Toast.makeText(this@MainActivity, "Ayarlar > Genel yönetim > Dil > Metinden sese yolunu izleyin.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        // diğer
        val learn = CheckBox(this).apply { text = "Otomatik çıkarım ve yorum (anahtarlı yapay zekalarla)"; isChecked = settings.autoLearn }
        val libInfo = TextView(this).apply { textSize = 13f; setPadding(0, dp(6), 0, dp(4)); text = skills.run("library_stats", org.json.JSONObject()) }
        val typeBtn = Button(this).apply { text = "Metinle yaz"; setOnClickListener { askText("A.L.P.H.A.'ya yaz", "") { if (it.isNotBlank()) handle(it.trim()) } } }
        val histBtn = Button(this).apply { text = "Sohbet geçmişi"; setOnClickListener { showHistory() } }
        val help = TextView(this).apply {
            textSize = 12f
            text = "Sesli komut örnekleri:\n" +
                "• yazı rengini mavi yap / arka plan rengini siyah yap / halka rengini kırmızı yap\n" +
                "• dünyayı göster / ağı göster / yazıya dön\n" +
                "• yapay zekayı Claude yap (ChatGPT, Gemini, DeepSeek, kendi yapay zekam)\n" +
                "• ses tonunu düşür / yükselt, daha hızlı / yavaş konuş, sesi kapat / aç\n" +
                "• İngilizce konuş / Türkçe konuş / dili otomatik yap\n" +
                "• sürekli dinle / dinlemeyi bırak, ayarları aç\n\n" +
                "Dokunuşlar: halkanın içi = yazı→dünya→ağ; halkanın dışı = dinle; uzun basış = ayarlar."
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
            addView(section("Yapay zeka")); addView(spinner); addView(hint)
            addView(modelInfo); addView(pick); addView(dlUrl); addView(dlToken); addView(dlBtn)
            addView(key); addView(model); addView(url); addView(learn)
            addView(section("Renkler"))
            addView(colorRow("Yazı rengi", { settings.textColor }, { settings.textColor = it }))
            addView(colorRow("Arka plan rengi", { settings.bgColor }, { settings.bgColor = it }))
            addView(colorRow("Halka rengi", { settings.ringColor }, { settings.ringColor = it }))
            addView(section("Ses"))
            addView(speak); addView(langSp); addView(pitchLbl); addView(pitchBar); addView(rateLbl); addView(rateBar)
            addView(trVoice); addView(enVoice); addView(ttsBtn)
            addView(section("Kütüphane"))
            addView(libInfo)
            addView(Button(this@MainActivity).apply { text = "Kütüphaneyi dışa aktar"; setOnClickListener { exportLibrary() } })
            addView(Button(this@MainActivity).apply { text = "Kütüphaneyi içe aktar"; setOnClickListener { pickFile(4) } })
            addView(section("Diğer"))
            addView(typeBtn); addView(histBtn); addView(help)
        }

        AlertDialog.Builder(this)
            .setTitle("Ayarlar")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Kaydet") { _, _ ->
                if (selected != Providers.OFFLINE && selected != Providers.ONDEVICE) {
                    settings.save(selected, key.text.toString(), model.text.toString(), url.text.toString())
                }
                settings.provider = selected
                settings.speak = speak.isChecked
                settings.autoLearn = learn.isChecked
                settings.modelUrl = dlUrl.text.toString()
                settings.hfToken = dlToken.text.toString()
                brain.reset()
                Toast.makeText(this, "Kaydedildi: ${Providers.label(selected)}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Kapat", null)
            .show()
    }
}
