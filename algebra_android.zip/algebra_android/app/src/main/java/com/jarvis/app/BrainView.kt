package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * A1'in "beyni": siyah fon üzerinde yeşil bir atom çekirdeği ve etrafında dönen,
 * birbirine bağlanan düğümler. Her düğüm kütüphanedeki bir not veya tasarımdır;
 * ortak kelime/etiket paylaşan notlar birbirine bağlanır. Düşünürken ağ parlar.
 */
class BrainView(ctx: Context) : View(ctx) {

    class GNode(val label: String, val text: String, val kind: String)

    /** Bir düğüme dokunulunca notun metniyle çağrılır. */
    var onNodeTap: ((String) -> Unit)? = null

    private var nodes: List<GNode> = emptyList()
    private var edges: List<IntArray> = emptyList()
    private var phase = FloatArray(0)
    private var speed = FloatArray(0)
    private var wob = FloatArray(0)
    private var px = FloatArray(0)
    private var py = FloatArray(0)
    private var linkBuf = FloatArray(0)
    private var coreBuf = FloatArray(0)

    private var bands = 3
    private var growth = 0f
    private var active = false
    private var energy = 0f
    private var rippleStart = -100000L
    private var downX = 0f
    private var downY = 0f

    private val d = ctx.resources.displayMetrics.density
    private val green = Color.parseColor("#00FF66")
    private val rect = RectF()

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = green; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = green; strokeWidth = 1.2f * d }
    private val orbit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = green; strokeWidth = 1.1f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = green }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = green; textSize = 10f * d; textAlign = Paint.Align.CENTER
    }

    fun setGraph(n: List<GNode>, e: List<IntArray>) {
        nodes = n
        edges = e.filter { it[0] < n.size && it[1] < n.size }
        val cnt = n.size
        // bağlantı arttıkça ağ büyür: daha çok halka, yörünge ve daha iri çekirdek
        bands = (3 + cnt / 20).coerceAtMost(7)
        growth = (Math.log(1.0 + edges.size) / Math.log(1.0 + 150.0)).toFloat().coerceIn(0f, 1f)
        phase = FloatArray(cnt)
        speed = FloatArray(cnt)
        wob = FloatArray(cnt)
        px = FloatArray(cnt)
        py = FloatArray(cnt)
        for (i in 0 until cnt) {
            val r = Random(i * 7919L + 13)
            phase[i] = r.nextFloat() * (2f * PI.toFloat())
            val band = i % bands
            val dir = if (i % 2 == 0) 1f else -1f
            speed[i] = dir * 0.22f / (1f + band * 0.35f)
            wob[i] = r.nextFloat() * (2f * PI.toFloat())
        }
        linkBuf = FloatArray(edges.size * 4)
        coreBuf = FloatArray(cnt * 4)
        invalidate()
    }

    /** Düşünürken true: ağ parlar ve darbeler hızlanır. */
    fun setActive(a: Boolean) {
        active = a
        invalidate()
    }

    /** Yeni bir şey öğrenildiğinde/cevap geldiğinde çekirdekten bir dalga yayar. */
    fun pulse() {
        rippleStart = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun kindColor(kind: String): Int = when (kind) {
        "çıkarım" -> Color.parseColor("#B6FF3B")
        "yorum" -> Color.parseColor("#2BFFC6")
        "tasarım" -> Color.parseColor("#D8FFE8")
        "kanun" -> Color.WHITE
        else -> green
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        if (width == 0 || height == 0) return

        val now = SystemClock.uptimeMillis()
        val t = now / 1000f
        val cx = width / 2f
        val cy = height / 2f
        val r0 = min(width, height) / 2f
        // dikey telefonda ağ ekranın yüksekliğine yayılsın
        val ky = ((height / 2f) / r0 * 1.2f).coerceIn(0.9f, 2.5f)
        energy += ((if (active) 1f else 0f) - energy) * 0.06f

        // düğüm konumları (halkalar üzerinde dönen yörüngeler)
        for (i in nodes.indices) {
            val band = i % bands
            val rr = r0 * (0.30f + 0.62f * band / (bands - 1).coerceAtLeast(1)) * (1f + 0.05f * sin(t * 0.7f + wob[i]))
            val a = phase[i] + speed[i] * t
            px[i] = cx + rr * cos(a)
            py[i] = cy + rr * sin(a) * ky
        }

        drawAtom(canvas, cx, cy, r0, t)

        // çekirdekten düğümlere zayıf bağlar
        var k = 0
        for (i in nodes.indices) {
            coreBuf[k++] = cx; coreBuf[k++] = cy; coreBuf[k++] = px[i]; coreBuf[k++] = py[i]
        }
        glow.alpha = (12 + 25 * energy).toInt()
        line.alpha = (45 + 70 * energy).toInt()
        canvas.drawLines(coreBuf, 0, k, glow)
        canvas.drawLines(coreBuf, 0, k, line)

        // ilişki bağları
        var m = 0
        for (e in edges) {
            linkBuf[m++] = px[e[0]]; linkBuf[m++] = py[e[0]]; linkBuf[m++] = px[e[1]]; linkBuf[m++] = py[e[1]]
        }
        glow.alpha = (30 + 60 * energy).toInt()
        line.alpha = (110 + 120 * energy).toInt()
        canvas.drawLines(linkBuf, 0, m, glow)
        canvas.drawLines(linkBuf, 0, m, line)

        // bağlar üzerinde akan darbeler
        fill.color = green
        val flow = 0.3f + 0.9f * energy
        for ((idx, e) in edges.withIndex()) {
            val f = (t * flow + idx * 0.173f) % 1f
            val x = px[e[0]] + (px[e[1]] - px[e[0]]) * f
            val y = py[e[0]] + (py[e[1]] - py[e[0]]) * f
            fill.alpha = (150 + 100 * energy).toInt().coerceAtMost(255)
            canvas.drawCircle(x, y, 2.2f * d, fill)
        }

        // düğümler
        for (i in nodes.indices) {
            val c = kindColor(nodes[i].kind)
            fill.color = c
            fill.alpha = 45
            val big = if (nodes[i].kind == "kanun") 1.5f else 1f
            canvas.drawCircle(px[i], py[i], 9f * d * big, fill)
            fill.alpha = 255
            canvas.drawCircle(px[i], py[i], (if (nodes.size > 60) 2.6f else 3.6f) * d * big, fill)
            text.color = c
            text.alpha = 150
            if (nodes.size <= 45) canvas.drawText(nodes[i].label, px[i], py[i] + 17f * d, text)
        }

        // dalga
        val el = (now - rippleStart) / 1400f
        if (el in 0f..1f) {
            orbit.alpha = ((1f - el) * 190).toInt()
            canvas.drawCircle(cx, cy, r0 * 1.1f * el, orbit)
            orbit.alpha = 255
        }

        postInvalidateOnAnimation()
    }

    private fun drawAtom(c: Canvas, cx: Float, cy: Float, r0: Float, t: Float) {
        val core = r0 * (0.09f + 0.07f * growth) * (1f + 0.12f * sin(t * 2.2f) + 0.3f * energy)

        // çekirdek ışıltısı
        for (k in 4 downTo 1) {
            fill.color = green
            fill.alpha = 9 * (5 - k) + (26 * energy).toInt()
            c.drawCircle(cx, cy, core * (1f + 0.5f * k), fill)
        }
        // protonlar/nötronlar
        val nuc = 7 + (growth * 20).toInt()
        for (i in 0 until nuc) {
            val a = i * 2.4f + t * (0.7f + 0.5f * energy)
            val rr = core * 0.6f * ((i % 4) + 1) / 4f
            fill.color = if (i % 2 == 0) green else Color.parseColor("#B6FF3B")
            fill.alpha = 255
            c.drawCircle(cx + rr * cos(a), cy + rr * sin(a), core * 0.3f, fill)
        }
        // yörüngeler ve elektronlar
        val ow = r0 * 0.78f
        val oh = r0 * 0.26f
        val orbs = 3 + (growth * 3).toInt()
        for (k in 0 until orbs) {
            c.save()
            c.rotate(k * (180f / orbs) + t * (6f + 10f * energy), cx, cy)
            rect.set(cx - ow, cy - oh, cx + ow, cy + oh)
            orbit.alpha = 90
            c.drawOval(rect, orbit)
            val a = t * (1.4f + k * 0.5f + 1.2f * energy) + k * 2f
            fill.color = green
            fill.alpha = 255
            c.drawCircle(cx + ow * cos(a), cy + oh * sin(a), r0 * 0.022f, fill)
            c.restore()
        }
        orbit.alpha = 255
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y }
            MotionEvent.ACTION_UP -> {
                if (abs(e.x - downX) < 16f * d && abs(e.y - downY) < 16f * d) {
                    var best = -1
                    var bestD = 30f * d
                    for (i in nodes.indices) {
                        val dist = hypot(e.x - px[i], e.y - py[i])
                        if (dist < bestD) { bestD = dist; best = i }
                    }
                    if (best >= 0) {
                        onNodeTap?.invoke("[" + nodes[best].kind + "] " + nodes[best].text)
                    } else {
                        pulse()
                    }
                }
            }
        }
        return true
    }
}
