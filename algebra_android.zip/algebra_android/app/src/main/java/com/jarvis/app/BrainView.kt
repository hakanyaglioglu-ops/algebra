package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

/**
 * A1'in "beyni": koyu zeminde yavaşça süzülen noktalar; yakın olanlar ince çizgilerle bağlanır (plexus ağı).
 * Parlak, etiketli noktalar kütüphanedeki notlar, kanunlar ve tasarımlardır; aralarındaki ilişkiler
 * daha kalın çizgi ve akan darbelerle gösterilir. Düşünürken ağ hızlanır ve parlar.
 */
class BrainView(ctx: Context) : View(ctx) {

    class GNode(val label: String, val text: String, val kind: String)

    /** Bir düğüme dokunulunca notun metniyle çağrılır. */
    var onNodeTap: ((String) -> Unit)? = null

    private var nodes: List<GNode> = emptyList()
    private var edges: List<IntArray> = emptyList()

    // koordinatlar 0..1 aralığında (ekran boyutundan bağımsız)
    private var nu = FloatArray(0)
    private var nv = FloatArray(0)
    private var nvu = FloatArray(0)
    private var nvv = FloatArray(0)
    private var au = FloatArray(0)
    private var av = FloatArray(0)
    private var avu = FloatArray(0)
    private var avv = FloatArray(0)
    private var asz = FloatArray(0)
    private var aph = FloatArray(0)

    private var sx = FloatArray(0)   // ekran koordinatları (önce gezgin noktalar, sonra düğümler)
    private var sy = FloatArray(0)

    private val maxLinks = 2600
    private val bucket = Array(4) { FloatArray(maxLinks * 4) }
    private val bucketN = IntArray(4)
    private var edgeBuf = FloatArray(0)

    private var active = false
    private var energy = 0f
    private var rippleStart = -100000L
    private var last = 0L
    private var downX = 0f
    private var downY = 0f

    private val d = ctx.resources.displayMetrics.density
    private var accent = Color.parseColor("#39FF14")
    private var bgColor = Color.BLACK

    private val bgPaint = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 0.9f * d }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.4f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f * d; textAlign = Paint.Align.CENTER }

    /** Tema rengini uygular (zemin ve tüm çizimler bu renkten türer). */
    fun setTheme(th: Theme) {
        accent = th.accent
        bgColor = th.bg
        for (p in listOf(glow, line, ring, fill, text)) p.color = accent
        rebuildBg()
        invalidate()
    }

    private fun mixC(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) * k + Color.red(b) * (1 - k)).toInt(),
        (Color.green(a) * k + Color.green(b) * (1 - k)).toInt(),
        (Color.blue(a) * k + Color.blue(b) * (1 - k)).toInt()
    )

    private fun rebuildBg() {
        if (width == 0 || height == 0) return
        val top = mixC(accent, bgColor, 0.30f)
        bgPaint.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bgColor, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wdp = w / d
        val hdp = h / d
        val n = (wdp * hdp / 1800f).toInt().coerceIn(35, 110)
        val r = Random(42)
        au = FloatArray(n) { r.nextFloat() }
        av = FloatArray(n) { r.nextFloat() }
        avu = FloatArray(n) { (r.nextFloat() - 0.5f) * 0.05f }
        avv = FloatArray(n) { (r.nextFloat() - 0.5f) * 0.05f }
        asz = FloatArray(n) { 0.8f + r.nextFloat() * 1.6f }
        aph = FloatArray(n) { r.nextFloat() * 6.28f }
        resizeScreenBufs()
        rebuildBg()
    }

    private fun resizeScreenBufs() {
        val m = au.size + nodes.size
        if (sx.size != m) { sx = FloatArray(m); sy = FloatArray(m) }
    }

    fun setGraph(n: List<GNode>, e: List<IntArray>) {
        val oldU = nu; val oldV = nv; val oldVu = nvu; val oldVv = nvv
        nodes = n
        edges = e.filter { it[0] < n.size && it[1] < n.size }
        val cnt = n.size
        nu = FloatArray(cnt); nv = FloatArray(cnt); nvu = FloatArray(cnt); nvv = FloatArray(cnt)
        for (i in 0 until cnt) {
            if (i < oldU.size) {   // güncellemede düğümler yerinde kalsın
                nu[i] = oldU[i]; nv[i] = oldV[i]; nvu[i] = oldVu[i]; nvv[i] = oldVv[i]
            } else {
                val r = Random(i * 7919L + 13)
                nu[i] = 0.08f + r.nextFloat() * 0.84f
                nv[i] = 0.08f + r.nextFloat() * 0.84f
                nvu[i] = (r.nextFloat() - 0.5f) * 0.03f
                nvv[i] = (r.nextFloat() - 0.5f) * 0.03f
            }
        }
        edgeBuf = FloatArray(edges.size * 4)
        resizeScreenBufs()
        invalidate()
    }

    /** Düşünürken true: ağ hızlanır ve parlar. */
    fun setActive(a: Boolean) {
        active = a
        invalidate()
    }

    /** Cevap geldiğinde/yeni şey öğrenildiğinde ekranda bir dalga yayar. */
    fun pulse() {
        rippleStart = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun shift(c: Int, dh: Float): Int {
        val h = FloatArray(3)
        Color.colorToHSV(c, h)
        h[0] = (h[0] + dh + 360f) % 360f
        return Color.HSVToColor(h)
    }

    private fun kindColor(kind: String): Int = when (kind) {
        "çıkarım" -> shift(accent, 35f)
        "yorum" -> shift(accent, -35f)
        "tasarım" -> mixC(Color.WHITE, accent, 0.75f)
        "kanun" -> Color.WHITE
        else -> accent
    }

    private fun move(u: FloatArray, v: FloatArray, vu: FloatArray, vv: FloatArray, dt: Float) {
        for (i in u.indices) {
            u[i] += vu[i] * dt
            v[i] += vv[i] * dt
            if (u[i] < 0f) { u[i] = 0f; vu[i] = abs(vu[i]) } else if (u[i] > 1f) { u[i] = 1f; vu[i] = -abs(vu[i]) }
            if (v[i] < 0f) { v[i] = 0f; vv[i] = abs(vv[i]) } else if (v[i] > 1f) { v[i] = 1f; vv[i] = -abs(vv[i]) }
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(bgColor)
        if (width == 0 || height == 0) return

        val now = SystemClock.uptimeMillis()
        var dt = (now - last) / 1000f
        last = now
        if (dt > 0.05f || dt < 0f) dt = 0.016f
        val t = now / 1000f
        energy += ((if (active) 1f else 0f) - energy) * 0.06f
        val w = width.toFloat()
        val h = height.toFloat()

        move(au, av, avu, avv, dt * (1f + 2.2f * energy))
        move(nu, nv, nvu, nvv, dt * (1f + 1.5f * energy))

        val a = au.size
        for (i in 0 until a) { sx[i] = au[i] * w; sy[i] = av[i] * h }
        for (i in nodes.indices) { sx[a + i] = nu[i] * w; sy[a + i] = nv[i] * h }

        // zemin ve üstteki bulanık ışık lekeleri
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        for (k in 0 until 6) {
            val bx = w * (0.1f + 0.15f * k) + sin(t * 0.07f + k * 1.7f) * w * 0.05f
            val by = h * (0.03f + 0.04f * (k % 3)) + sin(t * 0.09f + k) * h * 0.02f
            val br = (46f + k * 13f) * d
            fill.color = mixC(Color.WHITE, accent, 0.25f)
            for (layer in 0 until 3) {
                fill.alpha = 7 + layer * 6
                canvas.drawCircle(bx, by, br * (1f - 0.3f * layer), fill)
            }
        }

        // yakın noktalar arasında ince çizgiler (plexus)
        for (b in 0 until 4) bucketN[b] = 0
        val la = 92f * d
        val ln = 140f * d
        val m = a + nodes.size
        for (i in 0 until m) {
            val ni = i >= a
            for (j in i + 1 until m) {
                val thr = if (ni || j >= a) ln else la
                val dx = sx[i] - sx[j]
                if (dx > thr || dx < -thr) continue
                val dy = sy[i] - sy[j]
                if (dy > thr || dy < -thr) continue
                val dist = hypot(dx, dy)
                if (dist >= thr) continue
                val lvl = ((1f - dist / thr) * 4f).toInt().coerceIn(0, 3)
                val n = bucketN[lvl]
                if (n + 4 > maxLinks * 4) continue
                val bk = bucket[lvl]
                bk[n] = sx[i]; bk[n + 1] = sy[i]; bk[n + 2] = sx[j]; bk[n + 3] = sy[j]
                bucketN[lvl] = n + 4
            }
        }
        line.color = accent
        for (b in 0 until 4) {
            line.alpha = ((35 + 48 * b) * (0.8f + 0.5f * energy)).toInt().coerceAtMost(255)
            canvas.drawLines(bucket[b], 0, bucketN[b], line)
        }

        // gezgin noktalar
        for (i in 0 until a) {
            val tw = 0.6f + 0.4f * sin(t * 1.3f + aph[i])
            fill.color = mixC(Color.WHITE, accent, 0.35f)
            fill.alpha = (70 * tw).toInt()
            canvas.drawCircle(sx[i], sy[i], asz[i] * 2.4f * d, fill)
            fill.alpha = (200 * tw).toInt()
            canvas.drawCircle(sx[i], sy[i], asz[i] * d, fill)
        }

        // ilişki bağları (kütüphane): daha belirgin, üzerinde akan darbeler
        var q = 0
        for (e in edges) {
            edgeBuf[q++] = sx[a + e[0]]; edgeBuf[q++] = sy[a + e[0]]
            edgeBuf[q++] = sx[a + e[1]]; edgeBuf[q++] = sy[a + e[1]]
        }
        glow.color = accent
        glow.alpha = (28 + 50 * energy).toInt()
        canvas.drawLines(edgeBuf, 0, q, glow)
        line.alpha = (130 + 110 * energy).toInt().coerceAtMost(255)
        canvas.drawLines(edgeBuf, 0, q, line)
        fill.color = accent
        val flow = 0.3f + 0.9f * energy
        for ((idx, e) in edges.withIndex()) {
            val f = (t * flow + idx * 0.173f) % 1f
            val x = sx[a + e[0]] + (sx[a + e[1]] - sx[a + e[0]]) * f
            val y = sy[a + e[0]] + (sy[a + e[1]] - sy[a + e[0]]) * f
            fill.alpha = (170 + 85 * energy).toInt().coerceAtMost(255)
            canvas.drawCircle(x, y, 2.1f * d, fill)
        }

        // düğümler (kütüphane notları)
        val small = nodes.size > 60
        for (i in nodes.indices) {
            val c = kindColor(nodes[i].kind)
            val big = if (nodes[i].kind == "kanun") 1.5f else 1f
            val x = sx[a + i]
            val y = sy[a + i]
            fill.color = c
            fill.alpha = 40 + (40 * energy).toInt()
            canvas.drawCircle(x, y, 10f * d * big, fill)
            fill.alpha = 255
            canvas.drawCircle(x, y, (if (small) 2.8f else 3.8f) * d * big, fill)
            if (nodes.size <= 45) {
                text.color = c
                text.alpha = 170
                canvas.drawText(nodes[i].label, x, y + 18f * d, text)
            }
        }

        // dalga
        val el = (now - rippleStart) / 1500f
        if (el in 0f..1f) {
            ring.color = accent
            ring.alpha = ((1f - el) * 190).toInt()
            canvas.drawCircle(w / 2f, h / 2f, maxOf(w, h) * 0.6f * el, ring)
        }

        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y }
            MotionEvent.ACTION_UP -> {
                if (abs(e.x - downX) < 16f * d && abs(e.y - downY) < 16f * d) {
                    var best = -1
                    var bestD = 32f * d
                    val a = au.size
                    for (i in nodes.indices) {
                        val dist = hypot(e.x - sx[a + i], e.y - sy[a + i])
                        if (dist < bestD) { bestD = dist; best = i }
                    }
                    if (best >= 0) {
                        onNodeTap?.invoke("[" + nodes[best].kind + "] " + nodes[best].text)
                    } else {
                        pulse()
                    }
                }
            }
        }
        return true
    }
}
