package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Ekranın yanlarındaki bilgi kutusu: başlık + (metin, durum) satırları. */
class HudBlock(val title: String, val rows: List<Pair<String, String>>)

/** Komuta merkezi ekranının metin verisi. */
class HudData(val topLeft: String, val topLeft2: String, val left: List<HudBlock>, val right: List<HudBlock>)

/**
 * A1 komuta merkezi: ortada dönen halkalar, parlayan mavi reaktör ve çevresinde menü düğmeleri;
 * reaktörün içinde şeffaf olarak A1'in hareketli bağlantı ağı (kütüphane notları, kanunlar, tasarımlar) çalışır.
 * Yanlarda panel içerikleri ve gerçek sistem bilgileri görünür.
 */
class BrainView(ctx: Context) : View(ctx) {

    class GNode(val label: String, val text: String, val kind: String)

    companion object {
        val MENU = listOf("METİN", "KÜTÜPH", "KANUN", "ÇALIŞ", "DURDUR", "PROJE", "MODEL", "DİNLE", "PANEL", "RENK", "AYAR", "YENİ")
    }

    /** Ağdaki bir düğüme dokunulunca notun metni. */
    var onNodeTap: ((String) -> Unit)? = null

    /** Halkadaki bir menü düğmesine dokunulunca MENU indeksi. */
    var onMenu: ((Int) -> Unit)? = null

    /** Konuşma/dinleme seviyesi 0..1 (alttaki çubuklar). */
    @Volatile var level = 0.15f

    private var data = HudData("", "", emptyList(), emptyList())

    // ---- ağ (0..1 birim kare, daire içine kırpılır) ----
    private var nodes: List<GNode> = emptyList()
    private var edges: List<IntArray> = emptyList()
    private var nu = FloatArray(0); private var nv = FloatArray(0)
    private var nvu = FloatArray(0); private var nvv = FloatArray(0)
    private var au = FloatArray(0); private var av = FloatArray(0)
    private var avu = FloatArray(0); private var avv = FloatArray(0)
    private var asz = FloatArray(0); private var aph = FloatArray(0)
    private var sx = FloatArray(0); private var sy = FloatArray(0)
    private val maxLinks = 1800
    private val bucket = Array(4) { FloatArray(maxLinks * 4) }
    private val bucketN = IntArray(4)
    private var edgeBuf = FloatArray(0)

    // ---- durum ----
    private var active = false
    private var energy = 0f
    private var rippleStart = -100000L
    private var last = 0L
    private var downX = 0f
    private var downY = 0f
    private var pressIdx = -1
    private var pressTime = 0L

    // ---- yerleşim ----
    private var cx = 0f; private var cy = 0f; private var rad = 1f
    private var land = true
    private val d = ctx.resources.displayMetrics.density
    private var accent = Color.parseColor("#22D3EE")
    private var bgColor = Color.BLACK
    private val rect = RectF()
    private val clip = Path()
    private var haze: RadialGradient? = null
    private var tickBuf = FloatArray(0)
    private var bandDash: DashPathEffect? = null

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val linkP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 0.9f * d }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val hazeP = Paint()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateFmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr", "TR"))
    private var lastSec = -1L
    private var timeStr = ""
    private var dateStr = ""

    // ---------------- dış API ----------------

    fun setTheme(th: Theme) {
        accent = th.accent
        bgColor = th.bg
        rebuild()
        invalidate()
    }

    fun setData(dt: HudData) { data = dt; invalidate() }

    fun setGraph(n: List<GNode>, e: List<IntArray>) {
        val oldU = nu; val oldV = nv; val oldVu = nvu; val oldVv = nvv
        val cnt = min(n.size, 40)
        nodes = n.take(cnt)
        edges = e.filter { it[0] < cnt && it[1] < cnt }
        nu = FloatArray(cnt); nv = FloatArray(cnt); nvu = FloatArray(cnt); nvv = FloatArray(cnt)
        for (i in 0 until cnt) {
            if (i < oldU.size) {
                nu[i] = oldU[i]; nv[i] = oldV[i]; nvu[i] = oldVu[i]; nvv[i] = oldVv[i]
            } else {
                val r = Random(i * 7919L + 13)
                nu[i] = 0.15f + r.nextFloat() * 0.7f
                nv[i] = 0.15f + r.nextFloat() * 0.7f
                nvu[i] = (r.nextFloat() - 0.5f) * 0.04f
                nvv[i] = (r.nextFloat() - 0.5f) * 0.04f
            }
        }
        edgeBuf = FloatArray(edges.size * 4)
        resizeScreenBufs()
        invalidate()
    }

    fun setActive(a: Boolean) { active = a; invalidate() }

    fun pulse() { rippleStart = SystemClock.uptimeMillis(); invalidate() }

    // ---------------- yerleşim ----------------

    private fun mixC(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) * k + Color.red(b) * (1 - k)).toInt(),
        (Color.green(a) * k + Color.green(b) * (1 - k)).toInt(),
        (Color.blue(a) * k + Color.blue(b) * (1 - k)).toInt()
    )

    private fun lighten(c: Int, k: Float) = mixC(Color.WHITE, c, k)

    private fun shift(c: Int, dh: Float): Int {
        val h = FloatArray(3)
        Color.colorToHSV(c, h)
        h[0] = (h[0] + dh + 360f) % 360f
        return Color.HSVToColor(h)
    }

    private fun kindColor(kind: String): Int = when (kind) {
        "çıkarım" -> shift(accent, 35f)
        "yorum" -> shift(accent, -35f)
        "tasarım" -> lighten(accent, 0.25f)
        "kanun" -> Color.WHITE
        else -> accent
    }

    private fun resizeScreenBufs() {
        val m = au.size + nodes.size
        if (sx.size != m) { sx = FloatArray(m); sy = FloatArray(m) }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        land = w >= h * 1.15f
        rad = if (land) min(h * 0.43f, w * 0.30f) else min(w * 0.47f, h * 0.29f)
        cx = w / 2f
        cy = if (land) h * 0.5f else h * 0.38f
        val rc = rad * 0.46f
        val n = ((2 * rc / d) * (2 * rc / d) / 700f).toInt().coerceIn(30, 80)
        val r = Random(42)
        au = FloatArray(n) { r.nextFloat() }
        av = FloatArray(n) { r.nextFloat() }
        avu = FloatArray(n) { (r.nextFloat() - 0.5f) * 0.06f }
        avv = FloatArray(n) { (r.nextFloat() - 0.5f) * 0.06f }
        asz = FloatArray(n) { 0.8f + r.nextFloat() * 1.4f }
        aph = FloatArray(n) { r.nextFloat() * 6.28f }
        resizeScreenBufs()
        // cetvel çizgileri (dönmeden): 120 çentik
        val tb = FloatArray(120 * 4)
        for (k in 0 until 120) {
            val a = (k * 3.0 * PI / 180.0).toFloat()
            val r1 = rad * (if (k % 10 == 0) 0.915f else 0.93f)
            val r2 = rad * 0.95f
            tb[k * 4] = r1 * cos(a); tb[k * 4 + 1] = r1 * sin(a)
            tb[k * 4 + 2] = r2 * cos(a); tb[k * 4 + 3] = r2 * sin(a)
        }
        tickBuf = tb
        bandDash = DashPathEffect(floatArrayOf(rad * 0.05f, rad * 0.03f), 0f)
        rebuild()
    }

    private fun rebuild() {
        if (rad <= 1f) return
        haze = RadialGradient(
            cx, cy, rad * 1.6f,
            intArrayOf(Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.argb(22, Color.red(accent), Color.green(accent), Color.blue(accent)), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        hazeP.shader = haze
    }

    // ---------------- çizim ----------------

    override fun onDraw(c: Canvas) {
        c.drawColor(bgColor)
        if (width == 0 || height == 0 || rad <= 1f) return

        val now = SystemClock.uptimeMillis()
        var dt = (now - last) / 1000f
        last = now
        if (dt > 0.05f || dt < 0f) dt = 0.016f
        val t = now / 1000f
        energy += ((if (active) 1f else 0f) - energy) * 0.06f
        val sec = now / 1000
        if (sec != lastSec) {
            lastSec = sec
            val dtm = Date()
            timeStr = timeFmt.format(dtm)
            dateStr = dateFmt.format(dtm)
        }

        c.drawCircle(cx, cy, rad * 1.6f, hazeP)
        drawNetwork(c, dt, t)
        drawReactor(c, t)
        drawMenuRing(c, t, now)
        drawOuter(c, t)
        drawHudText(c)
        drawWave(c, t)

        val el = (now - rippleStart) / 1500f
        if (el in 0f..1f) {
            stroke.color = accent
            stroke.strokeWidth = 2f * d
            stroke.alpha = ((1f - el) * 200).toInt()
            c.drawCircle(cx, cy, rad * 1.05f * el, stroke)
        }
        postInvalidateOnAnimation()
    }

    private fun move(u: FloatArray, v: FloatArray, vu: FloatArray, vv: FloatArray, dt: Float) {
        for (i in u.indices) {
            u[i] += vu[i] * dt
            v[i] += vv[i] * dt
            if (u[i] < 0f) { u[i] = 0f; vu[i] = abs(vu[i]) } else if (u[i] > 1f) { u[i] = 1f; vu[i] = -abs(vu[i]) }
            if (v[i] < 0f) { v[i] = 0f; vv[i] = abs(vv[i]) } else if (v[i] > 1f) { v[i] = 1f; vv[i] = -abs(vv[i]) }
        }
    }

    /** Reaktörün ortasında, daireye kırpılmış şeffaf plexus ağı. */
    private fun drawNetwork(c: Canvas, dt: Float, t: Float) {
        val rc = rad * 0.46f
        move(au, av, avu, avv, dt * (1f + 2.2f * energy))
        move(nu, nv, nvu, nvv, dt * (1f + 1.5f * energy))
        val x0 = cx - rc
        val y0 = cy - rc
        val sz = 2 * rc
        val a = au.size
        for (i in 0 until a) { sx[i] = x0 + au[i] * sz; sy[i] = y0 + av[i] * sz }
        for (i in nodes.indices) { sx[a + i] = x0 + nu[i] * sz; sy[a + i] = y0 + nv[i] * sz }

        clip.reset()
        clip.addCircle(cx, cy, rc, Path.Direction.CW)
        c.save()
        c.clipPath(clip)

        // içte hafif mavi sis (zemin siyah kalır, ağ şeffaf görünür)
        fillP.color = accent
        fillP.alpha = 14
        c.drawCircle(cx, cy, rc, fillP)

        for (b in 0 until 4) bucketN[b] = 0
        val la = 0.55f * rc
        val ln = 0.85f * rc
        val m = a + nodes.size
        for (i in 0 until m) {
            val ni = i >= a
            for (j in i + 1 until m) {
                val thr = if (ni || j >= a) ln else la
                val dx = sx[i] - sx[j]
                if (dx > thr || dx < -thr) continue
                val dy = sy[i] - sy[j]
                if (dy > thr || dy < -thr) continue
                val dist = hypot(dx, dy)
                if (dist >= thr) continue
                val lvl = ((1f - dist / thr) * 4f).toInt().coerceIn(0, 3)
                val n = bucketN[lvl]
                if (n + 4 > maxLinks * 4) continue
                val bk = bucket[lvl]
                bk[n] = sx[i]; bk[n + 1] = sy[i]; bk[n + 2] = sx[j]; bk[n + 3] = sy[j]
                bucketN[lvl] = n + 4
            }
        }
        linkP.color = lighten(accent, 0.2f)
        for (b in 0 until 4) {
            linkP.alpha = ((40 + 52 * b) * (0.8f + 0.5f * energy)).toInt().coerceAtMost(255)
            c.drawLines(bucket[b], 0, bucketN[b], linkP)
        }

        for (i in 0 until a) {
            val tw = 0.6f + 0.4f * sin(t * 1.3f + aph[i])
            fillP.color = lighten(accent, 0.35f)
            fillP.alpha = (70 * tw).toInt()
            c.drawCircle(sx[i], sy[i], asz[i] * 2.2f * d, fillP)
            fillP.alpha = (210 * tw).toInt()
            c.drawCircle(sx[i], sy[i], asz[i] * d, fillP)
        }

        // kütüphane ilişkileri
        var q = 0
        for (e in edges) {
            edgeBuf[q++] = sx[a + e[0]]; edgeBuf[q++] = sy[a + e[0]]
            edgeBuf[q++] = sx[a + e[1]]; edgeBuf[q++] = sy[a + e[1]]
        }
        glowP.color = accent
        glowP.alpha = (28 + 50 * energy).toInt()
        c.drawLines(edgeBuf, 0, q, glowP)
        linkP.color = accent
        linkP.alpha = (150 + 100 * energy).toInt().coerceAtMost(255)
        c.drawLines(edgeBuf, 0, q, linkP)
        fillP.color = Color.WHITE
        val flow = 0.3f + 0.9f * energy
        for ((idx, e) in edges.withIndex()) {
            val f = (t * flow + idx * 0.173f) % 1f
            val x = sx[a + e[0]] + (sx[a + e[1]] - sx[a + e[0]]) * f
            val y = sy[a + e[0]] + (sy[a + e[1]] - sy[a + e[0]]) * f
            fillP.alpha = (160 + 90 * energy).toInt().coerceAtMost(255)
            c.drawCircle(x, y, 1.8f * d, fillP)
        }

        val small = nodes.size > 25
        for (i in nodes.indices) {
            val col = kindColor(nodes[i].kind)
            val big = if (nodes[i].kind == "kanun") 1.4f else 1f
            val x = sx[a + i]
            val y = sy[a + i]
            fillP.color = col
            fillP.alpha = 45 + (40 * energy).toInt()
            c.drawCircle(x, y, 8f * d * big, fillP)
            fillP.alpha = 255
            c.drawCircle(x, y, (if (small) 2.4f else 3.2f) * d * big, fillP)
            if (!small) {
                textP.color = col
                textP.alpha = 170
                textP.textSize = 8f * d
                textP.textAlign = Paint.Align.CENTER
                c.drawText(nodes[i].label, x, y + 15f * d, textP)
            }
        }
        c.restore()
    }

    /** Parlayan mavi reaktör halkası ve dönen çizgili şerit. */
    private fun drawReactor(c: Canvas, t: Float) {
        val e = energy
        // ağın etrafında ince halka
        stroke.color = accent
        stroke.strokeWidth = 1.2f * d
        stroke.alpha = 200
        c.drawCircle(cx, cy, rad * 0.475f, stroke)

        // dönen çizgili şerit
        c.save()
        c.rotate(-t * (12f + 40f * e), cx, cy)
        stroke.pathEffect = bandDash
        stroke.color = lighten(accent, 0.65f)
        stroke.strokeWidth = rad * 0.04f
        stroke.alpha = 230
        c.drawCircle(cx, cy, rad * 0.525f, stroke)
        stroke.pathEffect = null
        c.restore()

        // ışıltılı kalın halka
        val glowW = floatArrayOf(0.13f, 0.09f, 0.058f, 0.028f)
        val glowA = intArrayOf(20, 42, 95, 235)
        val boost = 1f + 0.45f * e
        for (k in 0 until 4) {
            stroke.color = if (k == 3) lighten(accent, 0.45f) else accent
            stroke.strokeWidth = rad * glowW[k]
            stroke.alpha = (glowA[k] * boost).toInt().coerceAtMost(255)
            c.drawCircle(cx, cy, rad * 0.60f, stroke)
        }
        stroke.color = accent
        stroke.strokeWidth = 1.1f * d
        stroke.alpha = 170
        c.drawCircle(cx, cy, rad * 0.645f, stroke)
    }

    /** 12 menü düğmesi ve iki ince halka. */
    private fun drawMenuRing(c: Canvas, t: Float, now: Long) {
        stroke.color = accent
        stroke.strokeWidth = 1f * d
        stroke.alpha = 90
        c.drawCircle(cx, cy, rad * 0.685f, stroke)
        c.drawCircle(cx, cy, rad * 0.885f, stroke)

        val bw = rad * 0.31f
        val bh = rad * 0.115f
        val r = rad * 0.785f
        textP.textSize = max(8f * d, rad * 0.05f)
        textP.textAlign = Paint.Align.CENTER
        for (i in MENU.indices) {
            val deg = -90f + 30f * i
            c.save()
            c.rotate(30f * i, cx, cy)
            rect.set(cx - bw / 2, cy - r - bh / 2, cx + bw / 2, cy - r + bh / 2)
            val pressed = i == pressIdx && now - pressTime < 350
            fillP.color = accent
            fillP.alpha = if (pressed) 120 else 22
            c.drawRoundRect(rect, 3f * d, 3f * d, fillP)
            stroke.color = accent
            stroke.strokeWidth = 1.1f * d
            stroke.alpha = if (pressed) 255 else 150
            c.drawRoundRect(rect, 3f * d, 3f * d, stroke)
            c.restore()
            val a = (deg * PI / 180.0).toFloat()
            textP.color = lighten(accent, if (pressed) 0.9f else 0.55f)
            textP.alpha = 255
            c.drawText(MENU[i], cx + r * cos(a), cy + r * sin(a) + textP.textSize * 0.35f, textP)
        }
    }

    /** Dış cetvel, dönen parçalı yaylar ve ince çember. */
    private fun drawOuter(c: Canvas, t: Float) {
        stroke.color = accent
        stroke.strokeWidth = 1f * d
        stroke.alpha = 110
        c.drawCircle(cx, cy, rad * 1.0f, stroke)

        c.save()
        c.translate(cx, cy)
        c.rotate(t * 3f)
        stroke.alpha = 150
        c.drawLines(tickBuf, 0, tickBuf.size, stroke)
        c.restore()

        rect.set(cx - rad * 0.975f, cy - rad * 0.975f, cx + rad * 0.975f, cy + rad * 0.975f)
        stroke.strokeWidth = rad * 0.014f
        for (k in 0 until 3) {
            val start = t * (10f + 30f * energy) * (if (k % 2 == 0) 1f else -0.6f) + k * 120f
            stroke.alpha = 200
            c.drawArc(rect, start, 62f, false, stroke)
        }
        stroke.strokeWidth = 1f * d
    }

    // ---------------- yan bilgiler ----------------

    private fun ell(s: String, maxW: Float): String {
        if (maxW <= 0f) return ""
        val n = textP.breakText(s, true, maxW, null)
        return if (n < s.length) s.substring(0, max(0, n - 1)) + "…" else s
    }

    /** Çerçeveli bilgi kutusu; sığmayan satırlar "+N" ile özetlenir. Yeni y konumunu döndürür. */
    private fun block(c: Canvas, x: Float, y0: Float, w: Float, b: HudBlock, maxY: Float): Float {
        val pad = 8f * d
        val th = 16f * d
        val rh = 15f * d
        val avail = ((maxY - y0 - th - 2 * pad) / rh).toInt()
        if (avail < 1 || w < 60f * d) return y0
        val rows = if (b.rows.isEmpty()) listOf("(boş)" to "") else b.rows
        val more = rows.size - avail
        val shown = if (more > 0) rows.take(max(1, avail - 1)) else rows
        val lines = shown.size + (if (more > 0) 1 else 0)
        val total = th + lines * rh + 2 * pad

        fillP.color = accent
        fillP.alpha = 16
        rect.set(x, y0, x + w, y0 + total)
        c.drawRect(rect, fillP)
        stroke.color = accent
        stroke.strokeWidth = 1.3f * d
        stroke.alpha = 200
        val k = 9f * d
        c.drawLine(x, y0, x + k, y0, stroke); c.drawLine(x, y0, x, y0 + k, stroke)
        c.drawLine(x + w, y0, x + w - k, y0, stroke); c.drawLine(x + w, y0, x + w, y0 + k, stroke)
        c.drawLine(x, y0 + total, x + k, y0 + total, stroke); c.drawLine(x, y0 + total, x, y0 + total - k, stroke)
        c.drawLine(x + w, y0 + total, x + w - k, y0 + total, stroke); c.drawLine(x + w, y0 + total, x + w, y0 + total - k, stroke)

        textP.textAlign = Paint.Align.LEFT
        textP.textSize = 10f * d
        textP.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textP.color = accent
        textP.alpha = 255
        c.drawText(b.title.uppercase(Locale("tr", "TR")), x + pad, y0 + pad + 9f * d, textP)
        textP.typeface = Typeface.MONOSPACE

        textP.textSize = 11f * d
        for ((i, row) in shown.withIndex()) {
            val by = y0 + pad + th + i * rh + 10f * d
            textP.textAlign = Paint.Align.RIGHT
            textP.color = if (row.second == "✗") Color.rgb(255, 90, 90) else accent
            textP.alpha = 255
            c.drawText(row.second, x + w - pad, by, textP)
            val rw = textP.measureText(row.second)
            textP.textAlign = Paint.Align.LEFT
            textP.color = lighten(accent, 0.55f)
            c.drawText(ell("• " + row.first, w - 2 * pad - rw - 6f * d), x + pad, by, textP)
        }
        if (more > 0) {
            textP.textAlign = Paint.Align.LEFT
            textP.color = lighten(accent, 0.35f)
            c.drawText("+${rows.size - shown.size} satır daha", x + pad, y0 + pad + th + shown.size * rh + 10f * d, textP)
        }
        return y0 + total + 8f * d
    }

    private fun drawHudText(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 0.025f * w
        textP.typeface = Typeface.MONOSPACE
        textP.textAlign = Paint.Align.LEFT
        textP.color = accent
        textP.alpha = 255
        textP.textSize = 12f * d
        textP.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        c.drawText("A1 · " + data.topLeft, m, 20f * d, textP)
        textP.typeface = Typeface.MONOSPACE
        textP.textSize = 10f * d
        textP.color = lighten(accent, 0.5f)
        c.drawText(data.topLeft2, m, 35f * d, textP)

        textP.textAlign = Paint.Align.RIGHT
        textP.color = accent
        textP.textSize = (if (land) 22f else 16f) * d
        c.drawText(timeStr, w - m, (if (land) 28f else 22f) * d, textP)
        textP.textSize = 10f * d
        textP.color = lighten(accent, 0.5f)
        c.drawText(dateStr, w - m, (if (land) 44f else 36f) * d, textP)

        val maxY = h - 8f * d
        if (land) {
            val lx = m
            val lw = (cx - rad * 1.1f) - lx - 0.01f * w
            var y = 56f * d
            for (b in data.left) y = block(c, lx, y, lw, b, maxY)
            val rx = cx + rad * 1.1f + 0.01f * w
            val rw = w - rx - m
            y = 56f * d
            for (b in data.right) y = block(c, rx, y, rw, b, maxY)
        } else {
            val top = cy + rad * 1.06f
            val colW = w * 0.46f
            var y = top
            for (b in data.left) y = block(c, w * 0.03f, y, colW, b, maxY)
            y = top
            for (b in data.right) y = block(c, w * 0.51f, y, colW, b, maxY)
        }
    }

    /** Altta konuşma/dinleme çubukları. */
    private fun drawWave(c: Canvas, t: Float) {
        val n = 28
        val bw = rad * 0.5f
        val step = bw / n
        val baseY = if (land) height - 16f * d else cy + rad * 1.06f - 12f * d
        val maxH = 18f * d
        stroke.color = accent
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeWidth = max(1.5f * d, step * 0.5f)
        val lv = level
        for (i in 0 until n) {
            val env = 0.35f + 0.65f * abs(sin(i * 0.55f + t * 3f)) * (0.5f + 0.5f * sin(i * 0.23f - t * 1.7f))
            val bh = maxH * (0.12f + 0.88f * lv * env)
            val x = cx - bw / 2 + step * (i + 0.5f)
            stroke.alpha = (90 + 160 * lv).toInt().coerceAtMost(255)
            c.drawLine(x, baseY - bh / 2, x, baseY + bh / 2, stroke)
        }
        stroke.strokeCap = Paint.Cap.BUTT
        stroke.strokeWidth = 1f * d
    }

    // ---------------- dokunma ----------------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y }
            MotionEvent.ACTION_UP -> {
                if (abs(e.x - downX) < 18f * d && abs(e.y - downY) < 18f * d) {
                    val dx = e.x - cx
                    val dy = e.y - cy
                    val r = hypot(dx, dy)
                    if (r in rad * 0.685f..rad * 0.885f) {
                        val deg = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
                        val idx = ((((deg + 90f + 15f) % 360f) + 360f) % 360f / 30f).toInt() % MENU.size
                        pressIdx = idx
                        pressTime = SystemClock.uptimeMillis()
                        onMenu?.invoke(idx)
                    } else if (r < rad * 0.5f) {
                        var best = -1
                        var bestD = 28f * d
                        val a = au.size
                        for (i in nodes.indices) {
                            val dist = hypot(e.x - sx[a + i], e.y - sy[a + i])
                            if (dist < bestD) { bestD = dist; best = i }
                        }
                        if (best >= 0) onNodeTap?.invoke("[" + nodes[best].kind + "] " + nodes[best].text) else pulse()
                    }
                }
            }
        }
        return true
    }
}
