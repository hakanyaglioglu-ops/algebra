package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A.L.P.H.A. ekranı: tek bir halka ve içindeki daire. Başka hiçbir şey çizilmez.
 *
 * Dairenin içi 3 durum arasında dönüşür; daireye her dokunuşta bir sonrakine geçer:
 *   0 = "A.L.P.H.A." yazısı, 1 = noktalı dönen dünya, 2 = hareketli bağlantı ağı (kütüphane notları).
 * Daire dışına kısa dokunuş = dinle (onOutsideTap), uzun basış = ayarlar (onLongPress).
 */
class BrainView(ctx: Context) : View(ctx) {

    class GNode(val label: String, val text: String, val kind: String)

    companion object {
        const val MODE_TEXT = 0
        const val MODE_GLOBE = 1
        const val MODE_NET = 2
        private const val FADE_MS = 450L
        private const val GLOBE_N = 5000
    }

    /** Daireye dokunulunca (veya sesle) durum değiştiğinde. */
    var onModeChange: ((Int) -> Unit)? = null
    var onOutsideTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null

    /** Konuşma/dinleme seviyesi 0..1: halka hızlanır, yazı parlar. */
    @Volatile var level = 0f

    var mode = MODE_TEXT
        private set

    private var fromMode = MODE_TEXT
    private var fadeStart = -100000L

    // ---- renkler ----
    private var textColor = Color.WHITE
    private var accent = Color.parseColor("#3CC8F0")
    private var bgColor = Color.BLACK

    // ---- yerleşim ----
    private var cx = 0f
    private var cy = 0f
    private var rad = 1f
    private var rc = 1f
    private val d = ctx.resources.displayMetrics.density
    private val rect = RectF()
    private val clip = Path()
    private var tickBuf = FloatArray(0)
    private var dashA: DashPathEffect? = null
    private var dashB: DashPathEffect? = null
    private var dashC: DashPathEffect? = null

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val linkP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 0.9f * d }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val hazeP = Paint()
    private val titleP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.07f
        textScaleX = 1.18f
    }
    private val title = "A.L.P.H.A."

    // ---- durum ----
    private var active = false
    private var energy = 0f
    private var rippleStart = -100000L
    private var last = 0L
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var longFired = false
    private val longRun = Runnable { longFired = true; onLongPress?.invoke() }

    // ---- dünya ----
    private val gx = FloatArray(GLOBE_N)
    private val gy = FloatArray(GLOBE_N)
    private val gz = FloatArray(GLOBE_N)
    private val gLand = BooleanArray(GLOBE_N)
    private val buckets = Array(6) { FloatArray(GLOBE_N * 2) } // 0..2 deniz, 3..5 kara (derinliğe göre)
    private val bucketN = IntArray(6)

    // ---- ağ (0..1 birim kare, daireye kırpılır) ----
    private var nodes: List<GNode> = emptyList()
    private var edges: List<IntArray> = emptyList()
    private var nu = FloatArray(0); private var nv = FloatArray(0)
    private var nvu = FloatArray(0); private var nvv = FloatArray(0)
    private var au = FloatArray(0); private var av = FloatArray(0)
    private var avu = FloatArray(0); private var avv = FloatArray(0)
    private var asz = FloatArray(0); private var aph = FloatArray(0)
    private var sx = FloatArray(0); private var sy = FloatArray(0)
    private val maxLinks = 1800
    private val bucket = Array(4) { FloatArray(maxLinks * 4) }
    private val netN = IntArray(4)
    private var edgeBuf = FloatArray(0)

    init {
        // Fibonacci küresi: eşit aralıklı noktalar; kara/deniz bilgisi kara maskesinden
        val golden = PI * (3.0 - sqrt(5.0))
        for (i in 0 until GLOBE_N) {
            val y = 1.0 - 2.0 * (i + 0.5) / GLOBE_N
            val r = sqrt(1.0 - y * y)
            val phi = golden * i
            val x = cos(phi) * r
            val z = sin(phi) * r
            gx[i] = x.toFloat(); gy[i] = y.toFloat(); gz[i] = z.toFloat()
            val lat = Math.toDegrees(asin(y))
            val lon = Math.toDegrees(atan2(x, z))
            gLand[i] = EarthMask.isLand(lat, lon)
        }
    }

    // ---------------- dış API ----------------

    /** Yazı, halka ve arka plan renkleri. */
    fun setColors(text: Int, ring: Int, bg: Int) {
        textColor = text
        accent = ring
        bgColor = bg
        rebuild()
        invalidate()
    }

    fun setGraph(n: List<GNode>, e: List<IntArray>) {
        val oldU = nu; val oldV = nv; val oldVu = nvu; val oldVv = nvv
        val cnt = min(n.size, 40)
        nodes = n.take(cnt)
        edges = e.filter { it[0] < cnt && it[1] < cnt }
        nu = FloatArray(cnt); nv = FloatArray(cnt); nvu = FloatArray(cnt); nvv = FloatArray(cnt)
        for (i in 0 until cnt) {
            if (i < oldU.size) {
                nu[i] = oldU[i]; nv[i] = oldV[i]; nvu[i] = oldVu[i]; nvv[i] = oldVv[i]
            } else {
                val r = Random(i * 7919L + 13)
                nu[i] = 0.15f + r.nextFloat() * 0.7f
                nv[i] = 0.15f + r.nextFloat() * 0.7f
                nvu[i] = (r.nextFloat() - 0.5f) * 0.04f
                nvv[i] = (r.nextFloat() - 0.5f) * 0.04f
            }
        }
        edgeBuf = FloatArray(edges.size * 4)
        resizeScreenBufs()
        invalidate()
    }

    fun setActive(a: Boolean) { active = a; invalidate() }

    fun pulse() { rippleStart = SystemClock.uptimeMillis(); invalidate() }

    /** Sesli komutla veya dokunuşla durum değiştirir (0 yazı, 1 dünya, 2 ağ). */
    fun setMode(m: Int) {
        val nm = ((m % 3) + 3) % 3
        if (nm == mode) return
        fromMode = mode
        mode = nm
        fadeStart = SystemClock.uptimeMillis()
        pulse()
        onModeChange?.invoke(nm)
    }

    // ---------------- renk yardımcıları ----------------

    private fun mixC(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) * k + Color.red(b) * (1 - k)).toInt(),
        (Color.green(a) * k + Color.green(b) * (1 - k)).toInt(),
        (Color.blue(a) * k + Color.blue(b) * (1 - k)).toInt()
    )

    private fun lighten(c: Int, k: Float) = mixC(Color.WHITE, c, k)

    private fun shift(c: Int, dh: Float): Int {
        val h = FloatArray(3)
        Color.colorToHSV(c, h)
        h[0] = (h[0] + dh + 360f) % 360f
        return Color.HSVToColor(h)
    }

    private fun kindColor(kind: String): Int = when (kind) {
        "çıkarım" -> shift(accent, 35f)
        "yorum" -> shift(accent, -35f)
        "tasarım" -> lighten(accent, 0.25f)
        "kanun" -> Color.WHITE
        else -> accent
    }

    // ---------------- yerleşim ----------------

    private fun resizeScreenBufs() {
        val m = au.size + nodes.size
        if (sx.size != m) { sx = FloatArray(m); sy = FloatArray(m) }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        // dikey de yatay da: halka ekranın tam ortasında, kısa kenara sığar
        rad = min(w, h) * 0.46f
        rc = rad * 0.60f
        cx = w / 2f
        cy = h / 2f
        clip.reset()
        clip.addCircle(cx, cy, rc, Path.Direction.CW)

        val n = ((2 * rc / d) * (2 * rc / d) / 700f).toInt().coerceIn(30, 80)
        val r = Random(42)
        au = FloatArray(n) { r.nextFloat() }
        av = FloatArray(n) { r.nextFloat() }
        avu = FloatArray(n) { (r.nextFloat() - 0.5f) * 0.06f }
        avv = FloatArray(n) { (r.nextFloat() - 0.5f) * 0.06f }
        asz = FloatArray(n) { 0.8f + r.nextFloat() * 1.4f }
        aph = FloatArray(n) { r.nextFloat() * 6.28f }
        resizeScreenBufs()

        // dış cetvel: 180 çentik, her 5.si uzun
        val tb = FloatArray(180 * 4)
        for (k in 0 until 180) {
            val a = (k * 2.0 * PI / 180.0).toFloat()
            val r1 = rad * (if (k % 5 == 0) 0.905f else 0.93f)
            val r2 = rad * 0.96f
            tb[k * 4] = r1 * cos(a); tb[k * 4 + 1] = r1 * sin(a)
            tb[k * 4 + 2] = r2 * cos(a); tb[k * 4 + 3] = r2 * sin(a)
        }
        tickBuf = tb
        dashA = DashPathEffect(floatArrayOf(rad * 0.055f, rad * 0.018f), 0f)
        dashB = DashPathEffect(floatArrayOf(rad * 0.012f, rad * 0.014f), 0f)
        dashC = DashPathEffect(floatArrayOf(rad * 0.03f, rad * 0.03f), 0f)

        // yazı: dairenin içine sığacak şekilde ölçekle
        titleP.textSize = rad * 0.2f
        val wanted = rc * 2f * 0.84f
        val have = titleP.measureText(title)
        if (have > 0f) titleP.textSize = titleP.textSize * wanted / have
        rebuild()
    }

    private fun rebuild() {
        if (rad <= 1f) return
        hazeP.shader = RadialGradient(
            cx, cy, rad * 1.25f,
            intArrayOf(
                Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.argb(18, Color.red(accent), Color.green(accent), Color.blue(accent)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
    }

    // ---------------- çizim ----------------

    override fun onDraw(c: Canvas) {
        c.drawColor(bgColor)
        if (width == 0 || height == 0 || rad <= 1f) return

        val now = SystemClock.uptimeMillis()
        var dt = (now - last) / 1000f
        last = now
        if (dt > 0.05f || dt < 0f) dt = 0.016f
        val t = now / 1000f
        energy += ((if (active) 1f else 0f) - energy) * 0.06f

        c.drawCircle(cx, cy, rad * 1.25f, hazeP)
        drawRing(c, t)

        // dairenin içi: eski durumdan yenisine yumuşak geçiş
        val f = ((now - fadeStart) / FADE_MS.toFloat()).coerceIn(0f, 1f)
        if (f < 1f) {
            drawContent(c, fromMode, 1f - f, dt, t)
            drawContent(c, mode, f, dt, t)
        } else {
            drawContent(c, mode, 1f, dt, t)
        }

        val el = (now - rippleStart) / 1500f
        if (el in 0f..1f) {
            stroke.color = accent
            stroke.strokeWidth = 2f * d
            stroke.alpha = ((1f - el) * 200).toInt()
            c.drawCircle(cx, cy, rc + (rad * 1.05f - rc) * el, stroke)
        }
        postInvalidateOnAnimation()
    }

    private fun drawContent(c: Canvas, m: Int, alpha: Float, dt: Float, t: Float) {
        if (alpha <= 0.01f) return
        c.save()
        c.clipPath(clip)
        c.saveLayerAlpha(cx - rc, cy - rc, cx + rc, cy + rc, (alpha * 255).toInt().coerceIn(0, 255))
        when (m) {
            MODE_GLOBE -> drawGlobe(c, t)
            MODE_NET -> drawNetwork(c, dt, t)
            else -> drawTitle(c)
        }
        c.restore()
        c.restore()
    }

    /** Dışarıdan içeriye: ışık, cetvel, parçalı bantlar, ince halkalar, iç daire. */
    private fun drawRing(c: Canvas, t: Float) {
        val e = energy
        val lv = level.coerceIn(0f, 1f)
        val spin = 1f + 2.5f * e + 1.5f * lv

        // dış ince çember + dönen cetvel
        stroke.color = accent
        stroke.strokeWidth = 1f * d
        stroke.alpha = 120
        c.drawCircle(cx, cy, rad, stroke)
        c.save()
        c.translate(cx, cy)
        c.rotate(t * 2.5f * spin)
        stroke.alpha = 170
        c.drawLines(tickBuf, 0, tickBuf.size, stroke)
        c.restore()

        // kalın parçalı bant (ışıltılı)
        rect.set(cx - rad * 0.835f, cy - rad * 0.835f, cx + rad * 0.835f, cy + rad * 0.835f)
        val startA = -t * 7f * spin
        val glowW = floatArrayOf(0.16f, 0.11f, 0.075f)
        val glowA = intArrayOf(22, 45, 235)
        stroke.pathEffect = null
        for (k in 0 until 3) {
            stroke.color = if (k == 2) lighten(accent, 0.35f) else accent
            stroke.strokeWidth = rad * glowW[k]
            stroke.alpha = (glowA[k] * (1f + 0.4f * lv)).toInt().coerceAtMost(255)
            if (k == 2) stroke.pathEffect = dashA
            c.drawArc(rect, startA, 215f, false, stroke)
        }
        stroke.pathEffect = null
        stroke.color = accent
        stroke.strokeWidth = rad * 0.075f
        stroke.alpha = 60
        c.drawArc(rect, startA + 235f, 95f, false, stroke)

        // ikinci bant: ince noktalı, ters yönde
        rect.set(cx - rad * 0.755f, cy - rad * 0.755f, cx + rad * 0.755f, cy + rad * 0.755f)
        stroke.pathEffect = dashB
        stroke.color = lighten(accent, 0.5f)
        stroke.strokeWidth = rad * 0.03f
        stroke.alpha = 210
        c.drawArc(rect, t * 11f * spin, 285f, false, stroke)
        stroke.pathEffect = null

        // ince bütün halka ve üzerinde dolaşan parlak yay
        stroke.color = accent
        stroke.strokeWidth = 1f * d
        stroke.alpha = 150
        c.drawCircle(cx, cy, rad * 0.70f, stroke)
        rect.set(cx - rad * 0.70f, cy - rad * 0.70f, cx + rad * 0.70f, cy + rad * 0.70f)
        stroke.color = lighten(accent, 0.7f)
        stroke.strokeWidth = rad * 0.014f
        stroke.alpha = 255
        c.drawArc(rect, t * 38f * spin, 42f, false, stroke)

        // iç halka: noktalı çizgi
        stroke.color = accent
        stroke.pathEffect = dashC
        stroke.strokeWidth = rad * 0.012f
        stroke.alpha = 200
        c.drawCircle(cx, cy, rad * 0.655f, stroke)
        stroke.pathEffect = null

        // iç daire: zemin biraz koyulaşır, kenarı parlar
        fillP.color = Color.BLACK
        fillP.alpha = 150
        c.drawCircle(cx, cy, rc, fillP)
        fillP.color = accent
        fillP.alpha = 16
        c.drawCircle(cx, cy, rc, fillP)
        stroke.color = accent
        stroke.strokeWidth = 1.4f * d
        stroke.alpha = 230
        c.drawCircle(cx, cy, rc, stroke)
        stroke.strokeWidth = 1f * d
    }

    // ---------------- durum 0: A.L.P.H.A. ----------------

    private fun drawTitle(c: Canvas) {
        val lv = level.coerceIn(0f, 1f)
        titleP.color = textColor
        titleP.setShadowLayer(rad * (0.025f + 0.05f * lv), 0f, 0f,
            Color.argb(170, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
        val fm = titleP.fontMetrics
        c.drawText(title, cx, cy - (fm.ascent + fm.descent) / 2f, titleP)
        titleP.clearShadowLayer()
    }

    // ---------------- durum 1: noktalı dönen dünya ----------------

    private fun drawGlobe(c: Canvas, t: Float) {
        val big = rc * 0.88f
        val a = t * 0.35f
        val ca = cos(a); val sa = sin(a)
        val tilt = 0.40f
        val ct = cos(tilt); val st = sin(tilt)

        for (b in 0 until 6) bucketN[b] = 0
        for (i in 0 until GLOBE_N) {
            val x1 = gx[i] * ca + gz[i] * sa
            val z1 = -gx[i] * sa + gz[i] * ca
            val y2 = gy[i] * ct - z1 * st
            val z2 = gy[i] * st + z1 * ct
            if (z2 <= 0f) continue
            val depth = if (z2 < 0.33f) 0 else if (z2 < 0.66f) 1 else 2
            val bi = depth + (if (gLand[i]) 3 else 0)
            val n = bucketN[bi]
            val buf = buckets[bi]
            buf[n] = cx + x1 * big
            buf[n + 1] = cy - y2 * big
            bucketN[bi] = n + 2
        }

        // kenar: dünyanın ince noktalı çerçevesi
        fillP.color = accent
        for (k in 0 until 96) {
            val an = (k * 2.0 * PI / 96.0).toFloat()
            fillP.alpha = 90
            c.drawCircle(cx + big * 1.0f * cos(an), cy + big * 1.0f * sin(an), 0.9f * d, fillP)
        }

        val oceanA = intArrayOf(40, 70, 110)
        val landA = intArrayOf(120, 190, 255)
        val oceanS = floatArrayOf(1.0f, 1.2f, 1.4f)
        val landS = floatArrayOf(1.5f, 1.9f, 2.3f)
        for (b in 0 until 6) {
            val land = b >= 3
            val dep = b % 3
            dotP.color = if (land) lighten(accent, 0.45f) else accent
            dotP.alpha = if (land) landA[dep] else oceanA[dep]
            dotP.strokeWidth = (if (land) landS[dep] else oceanS[dep]) * d
            c.drawPoints(buckets[b], 0, bucketN[b], dotP)
        }
    }

    // ---------------- durum 2: hareketli ağ ----------------

    private fun move(u: FloatArray, v: FloatArray, vu: FloatArray, vv: FloatArray, dt: Float) {
        for (i in u.indices) {
            u[i] += vu[i] * dt
            v[i] += vv[i] * dt
            if (u[i] < 0f) { u[i] = 0f; vu[i] = abs(vu[i]) } else if (u[i] > 1f) { u[i] = 1f; vu[i] = -abs(vu[i]) }
            if (v[i] < 0f) { v[i] = 0f; vv[i] = abs(vv[i]) } else if (v[i] > 1f) { v[i] = 1f; vv[i] = -abs(vv[i]) }
        }
    }

    private fun drawNetwork(c: Canvas, dt: Float, t: Float) {
        move(au, av, avu, avv, dt * (1f + 2.2f * energy))
        move(nu, nv, nvu, nvv, dt * (1f + 1.5f * energy))
        val x0 = cx - rc
        val y0 = cy - rc
        val sz = 2 * rc
        val a = au.size
        if (sx.size < a + nodes.size) resizeScreenBufs()
        for (i in 0 until a) { sx[i] = x0 + au[i] * sz; sy[i] = y0 + av[i] * sz }
        for (i in nodes.indices) { sx[a + i] = x0 + nu[i] * sz; sy[a + i] = y0 + nv[i] * sz }

        for (b in 0 until 4) netN[b] = 0
        val la = 0.55f * rc
        val ln = 0.85f * rc
        val m = a + nodes.size
        for (i in 0 until m) {
            val ni = i >= a
            for (j in i + 1 until m) {
                val thr = if (ni || j >= a) ln else la
                val dx = sx[i] - sx[j]
                if (dx > thr || dx < -thr) continue
                val dy = sy[i] - sy[j]
                if (dy > thr || dy < -thr) continue
                val dist = hypot(dx, dy)
                if (dist >= thr) continue
                val lvl = ((1f - dist / thr) * 4f).toInt().coerceIn(0, 3)
                val n = netN[lvl]
                if (n + 4 > maxLinks * 4) continue
                val bk = bucket[lvl]
                bk[n] = sx[i]; bk[n + 1] = sy[i]; bk[n + 2] = sx[j]; bk[n + 3] = sy[j]
                netN[lvl] = n + 4
            }
        }
        linkP.color = lighten(accent, 0.2f)
        for (b in 0 until 4) {
            linkP.alpha = ((40 + 52 * b) * (0.8f + 0.5f * energy)).toInt().coerceAtMost(255)
            c.drawLines(bucket[b], 0, netN[b], linkP)
        }

        for (i in 0 until a) {
            val tw = 0.6f + 0.4f * sin(t * 1.3f + aph[i])
            fillP.color = lighten(accent, 0.35f)
            fillP.alpha = (70 * tw).toInt()
            c.drawCircle(sx[i], sy[i], asz[i] * 2.2f * d, fillP)
            fillP.alpha = (210 * tw).toInt()
            c.drawCircle(sx[i], sy[i], asz[i] * d, fillP)
        }

        // kütüphane ilişkileri
        var q = 0
        for (e in edges) {
            edgeBuf[q++] = sx[a + e[0]]; edgeBuf[q++] = sy[a + e[0]]
            edgeBuf[q++] = sx[a + e[1]]; edgeBuf[q++] = sy[a + e[1]]
        }
        glowP.color = accent
        glowP.alpha = (28 + 50 * energy).toInt()
        c.drawLines(edgeBuf, 0, q, glowP)
        linkP.color = accent
        linkP.alpha = (150 + 100 * energy).toInt().coerceAtMost(255)
        c.drawLines(edgeBuf, 0, q, linkP)
        fillP.color = Color.WHITE
        val flow = 0.3f + 0.9f * energy
        for ((idx, e) in edges.withIndex()) {
            val f = (t * flow + idx * 0.173f) % 1f
            val x = sx[a + e[0]] + (sx[a + e[1]] - sx[a + e[0]]) * f
            val y = sy[a + e[0]] + (sy[a + e[1]] - sy[a + e[0]]) * f
            fillP.alpha = (160 + 90 * energy).toInt().coerceAtMost(255)
            c.drawCircle(x, y, 1.8f * d, fillP)
        }

        for (i in nodes.indices) {
            val col = kindColor(nodes[i].kind)
            val big = if (nodes[i].kind == "kanun") 1.4f else 1f
            val x = sx[a + i]
            val y = sy[a + i]
            fillP.color = col
            fillP.alpha = 45 + (40 * energy).toInt()
            c.drawCircle(x, y, 8f * d * big, fillP)
            fillP.alpha = 255
            c.drawCircle(x, y, (if (nodes.size > 25) 2.4f else 3.2f) * d * big, fillP)
        }
    }

    // ---------------- dokunma ----------------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                moved = false; longFired = false
                postDelayed(longRun, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(e.x - downX, e.y - downY) > 24f * d) {
                    moved = true
                    removeCallbacks(longRun)
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (!moved && !longFired) {
                    if (hypot(e.x - cx, e.y - cy) <= rad * 1.02f) setMode(mode + 1) else onOutsideTap?.invoke()
                }
            }
        }
        return true
    }
}
